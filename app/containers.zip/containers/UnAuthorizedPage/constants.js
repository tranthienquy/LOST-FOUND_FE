/*
 *
 * UnAuthorizedPage constants
 *
 */

export const DEFAULT_ACTION = 'app/UnAuthorizedPage/DEFAULT_ACTION';
export const END_OF_ACTION = 'app/UnAuthorizedPage/END_OF_ACTION';
