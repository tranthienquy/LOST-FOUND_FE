/**
 *
 * Asynchronously loads the component for CandidateJobRequestPage
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
