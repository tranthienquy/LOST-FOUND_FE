import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the candidateJobRequestPage state domain
 */

const selectCandidateJobRequestPageDomain = state =>
  state.candidateJobRequestPage || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by CandidateJobRequestPage
 */

const makeSelectCandidateJobRequestPage = () =>
  createSelector(
    selectCandidateJobRequestPageDomain,
    substate => substate,
  );

export default makeSelectCandidateJobRequestPage;
export { selectCandidateJobRequestPageDomain };
