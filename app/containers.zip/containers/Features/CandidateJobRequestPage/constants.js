/*
 *
 * CandidateJobRequestPage constants
 *
 */

export const DEFAULT_ACTION = 'app/CandidateJobRequestPage/DEFAULT_ACTION';
export const END_OF_ACTION = 'app/CandidateJobRequestPage/END_OF_ACTION';
