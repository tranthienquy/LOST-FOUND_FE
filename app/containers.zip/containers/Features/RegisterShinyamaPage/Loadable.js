/**
 *
 * Asynchronously loads the component for RegisterShinyamaPage
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
