import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the registerShinyamaPage state domain
 */

const selectRegisterShinyamaPageDomain = state => state.registerShinyamaPage || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by RegisterShinyamaPage
 */

const makeSelectRegisterShinyamaPage = () =>
  createSelector(
    selectRegisterShinyamaPageDomain,
    substate => substate,
  );

export default makeSelectRegisterShinyamaPage;
export { selectRegisterShinyamaPageDomain };
