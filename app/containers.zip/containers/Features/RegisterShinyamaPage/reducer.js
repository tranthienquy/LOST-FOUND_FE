/*
 *
 * RegisterShinyamaPage reducer
 *
 */
import produce from 'immer';
import { DEFAULT_ACTION, REGISTER, REGISTER_FAILED, REGISTER_SUCCESS } from './constants';

export const initialState = {
  loading:false,
  error:null
};

/* eslint-disable default-case, no-param-reassign */
const registerShinyamaPageReducer = (state = initialState, action) =>
  produce(state,  draft => {
    switch (action.type) {
      case DEFAULT_ACTION:
        break;
        case REGISTER:
          draft.loading= true;
          draft.error= null;
          break;
        case REGISTER_SUCCESS:
          draft.loading= false;
       
          break;
        case REGISTER_FAILED:
          draft.loading= false;
          draft.error = action.error;
         
          break;
    }
  });

export default registerShinyamaPageReducer;
