/*
 *
 * RegisterShinyamaPage constants
 *
 */

export const DEFAULT_ACTION = 'app/RegisterShinyamaPage/DEFAULT_ACTION';
export const REGISTER = 'app/RegisterShinyamaPage/REGISTER';
export const REGISTER_SUCCESS = 'app/RegisterShinyamaPage/REGISTER_SUCCESS';
export const REGISTER_FAILED = 'app/RegisterShinyamaPage/REGISTER_FAILED';
