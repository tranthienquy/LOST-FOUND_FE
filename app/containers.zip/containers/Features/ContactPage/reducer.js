/*
 *
 * ContactPage reducer
 *
 */
import produce from 'immer';
import * as types from './constants';

export const initialState = {
  loading: true,
  content: true
};

/* eslint-disable default-case, no-param-reassign */
const contactPageReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case types.DEFAULT_ACTION:
        break;
      case types.END_OF_ACTION:
        for (var element in draft) {
          draft[element] = initialState[element];
        }
        break;

        case types.GET_CONTENT:
          draft.loading = true;
          break;
        case types.GET_CONTENT_SUCCESS:
          draft.content = action.payload.data;
          break;
    }
  });

export default contactPageReducer;
