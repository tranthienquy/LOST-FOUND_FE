/*
 *
 * ContactPage actions
 *
 */

import { DEFAULT_ACTION, END_OF_ACTION, GET_CONTENT, GET_CONTENT_FAILED, GET_CONTENT_SUCCESS } from './constants';

export function defaultAction() {
  return {
    type: DEFAULT_ACTION,
  };
}
export const endOfAction = () => {
  return {
    type: END_OF_ACTION,
  };
};

export const getContent = () => {
  return {
    type: GET_CONTENT,
    
  };
};
export const getContentSuccess = data => {
  return {
    type: GET_CONTENT_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getContentFailed = () => {
  return {
    type: GET_CONTENT_FAILED,
  };
};