/**
 *
 * ContactPage
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import makeSelectContactPage from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import * as actions from './actions';
import './styles.scss';
import { Splide, SplideSlide } from '@splidejs/react-splide';
import AuthContext from '../../../utils/auth';
import { Button, Typography } from 'antd';
import { getValidRole } from '../../../utils/permissionUtil';
import { USER_ROLE } from '../../../utils/constants';
import { Link } from 'react-router-dom';


class ContactPage extends React.Component {
  componentWillUnmount() {
    this.props.onEndOfAction();
  }

  componentWillMount(){
    this.props.onGetContent();
  }

  render() {
    const { content, loading } = this.props.contactPage;

    return (
      <div className='contact-container'>
         {getValidRole(this.context.user, [USER_ROLE.ADMIN]) && (
            <Link to={`/contact-edit`}>
              {' '}
              <Button className="text-center d-flex align-items-center  mt-3">
                <i className="icon-Edit-outline mr-2" />{' '}
                <b className="w-100 text-center"> CHỈNH SỬA</b>
              </Button>
            </Link>
          )}
        {content && (
         <>
          <Splide
              aria-label="My Favorite Images"
              className="splide-banner mt-3"
              options={{
                perMove: 1,
                perPage: 1,
                autoplay: true,
                autoHeight: true,
                gap: '5rem',
                padding: '0rem',
              }}
            >
              {content.Banner &&
               JSON.parse(content.Banner).map(item => (
                  <SplideSlide>
                    <div className="splide-banner-item" >
                      <img src={`${this.context.prefixLink}/${item}`} width="100%" height={'400px'} style={{objectFit:"cover", borderRadius:10}}/>
                      </div>
                  </SplideSlide>
                ))}
            </Splide>
     
            <div className='d-flex flex-column  justify-content-end mt-5 w-100'>
                <Typography className='text-app-primary h2 font-weight-bold mt-5'>Về chúng tôi</Typography>
                <Typography.Text className='mt-3 w-50'>{content.AboutCompany}</Typography.Text>
            </div>
            <div className='d-flex flex-column  justify-content-end mt-5 w-100'>
                <Typography className='text-app-primary h2 font-weight-bold mt-5'>Văn phòng tại Việt Nam</Typography>
                <Typography.Text className='mt-3 w-50'>{content.VietnamOffice}</Typography.Text>
            </div>
            <div className='d-flex flex-column  justify-content-end mt-5 w-100'>
                <Typography className='text-app-primary h2 font-weight-bold mt-5'>Văn phòng tại Nhật Bản</Typography>
                <Typography.Text className='mt-3 w-50'>{content.JapanOffice}</Typography.Text>
            </div>
            <div className='d-flex flex-column  justify-content-end mt-5 w-100'>
                <Typography className='text-app-primary h2 font-weight-bold mt-5'>Thông tin liên lạc</Typography>
                <Typography.Text className='mt-3 w-50'>{content.ContactInfomation}</Typography.Text>
            </div>
         </>
        )}
      </div>
    );
  }
}

ContactPage.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  contactPage: makeSelectContactPage(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    onEndOfAction: () => {
      dispatch(actions.endOfAction());
    },
    onGetContent: content => {
      dispatch(actions.getContent(content));
    },
  };
}
ContactPage.contextType= AuthContext;
const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);
const withReducer = injectReducer({ key: 'contactPage', reducer });
const withSaga = injectSaga({ key: 'contactPage', saga });
export default compose(
  withConnect,
  withReducer,
  withSaga,
)(ContactPage);
