/*
 *
 * ContactPage constants
 *
 */

export const DEFAULT_ACTION = 'app/ContactPage/DEFAULT_ACTION';
export const END_OF_ACTION = 'app/ContactPage/END_OF_ACTION';

export const GET_CONTENT = 'app/ContactPage/GET_CONTENT';
export const GET_CONTENT_SUCCESS = 'app/ContactPage/GET_CONTENT_SUCCESS';
export const GET_CONTENT_FAILED = 'app/ContactPage/GET_CONTENT_FAILED';
