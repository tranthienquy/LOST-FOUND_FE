import { take, call, put, select, takeLatest, delay, fork, takeEvery } from 'redux-saga/effects';
import * as types from './constants';
import * as actions from './actions';
import * as api from 'utils/api';
import { KEY_VALUE } from '../../../utils/api/constants';


// Individual exports for testing

function* getContent() {
  
 
  const resp = yield call(
    api.get,
    `v1/ShinyamaContents/get-content`,{}
  );
  const { data, status } = resp;
  if (status == 200) {
    yield delay(500);
    yield put(actions.getContentSuccess(data));
  } else {
    yield put(actions.getContentFailed());
  }
}
export default function* contactPageSaga() {
  // See example in containers/HomePage/saga.js
  yield takeLatest(types.GET_CONTENT, getContent);

}
