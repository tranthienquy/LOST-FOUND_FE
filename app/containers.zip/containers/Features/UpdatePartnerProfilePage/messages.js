/*
 * UpdatePartnerProfilePage Messages
 *
 * This contains all the text for the UpdatePartnerProfilePage container.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.containers.UpdatePartnerProfilePage';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'This is the UpdatePartnerProfilePage container!',
  },
});
