/**
 *
 * Asynchronously loads the component for UpdatePartnerProfilePage
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
