import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the updatePartnerProfilePage state domain
 */

const selectUpdatePartnerProfilePageDomain = state =>
  state.updatePartnerProfilePage || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by UpdatePartnerProfilePage
 */

const makeSelectUpdatePartnerProfilePage = () =>
  createSelector(
    selectUpdatePartnerProfilePageDomain,
    substate => substate,
  );

export default makeSelectUpdatePartnerProfilePage;
export { selectUpdatePartnerProfilePageDomain };
