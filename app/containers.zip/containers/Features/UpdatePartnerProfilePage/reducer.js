/*
 *
 * UpdatePartnerProfilePage reducer
 *
 */
import produce from 'immer';
import * as types from './constants';

export const initialState = {
  loading: {
    content: true,
    submit: false,
  },
  content: {},
  error:null
};

/* eslint-disable default-case, no-param-reassign */
const updatePartnerProfilePageReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case types.DEFAULT_ACTION:
        break;
      case types.END_OF_ACTION:
        for (var element in draft) {
          draft[element] = initialState[element];
        }
        break;
        case types.GET_CONTENT:
          draft.loading.content = true;  
          break;
          case types.GET_CONTENT_SUCCESS:
            draft.loading.content = false;  
            const {FirstName, LastName, Phone, Position}= action.payload.data.value[0]
            draft.content= {FirstName, LastName, Phone, Position};
          break;
          case types.GET_CONTENT_FAILED:break;
          case types.SUBMIT_CONTENT:
            
            draft.loading.submit = true;  
            break;
          case types.SUBMIT_CONTENT_SUCCESS:
            draft.loading.submit = true;  
            
          break;
          case types.SUBMIT_CONTENT_FAILED:
            draft.loading.submit = false;  
            
          break;
    }
  });

export default updatePartnerProfilePageReducer;
