/**
 *
 * UpdatePartnerProfilePage
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import makeSelectUpdatePartnerProfilePage from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import * as actions from './actions';
import AuthContext from '../../../utils/auth';
import { Card, Typography, Input, Button, Form, Spin, Skeleton } from 'antd';
import { Animated } from 'react-animated-css';
import { LinearProgress } from '@mui/material';
import './styles.scss';

class UpdatePartnerProfilePage extends React.Component {
  componentWillUnmount() {
    this.props.onEndOfAction();
  }
  componentWillMount() {
 
    this.props.onGetContent(this.context.user.Id);
  
}

onSubmitSearch = value => {
  this.props.onSubmitContent(value);
  // this.props.onChangePassword({...value, email:this.context.user.email});
};
onFinishFailed = errorInfo =>{

}

  render() {
    const {loading,error,content}= this.props.updatePartnerProfilePage;

    return (
      <div className="update-recruiter-container">
      <Animated className="d-flex justify-content-center align-items-center w-100 h-100"
      animationIn="fadeInUp"
                animationOut=""
                isVisible={true}
                animationInDuration={500}
                animationInDelay={0}>
        <Card className="login-card">
          <div
                
                 className="d-flex flex-column justify-content-center"
              >
            <Typography className="text-center head-title font-weight-bold mt-2 mb-5">
              CẬP NHẬT HỒ SƠ CÁ NHÂN CỦA ĐỐI TÁC TUYỂN DỤNG
            </Typography>
{loading.content && <> <Skeleton active/> <Skeleton active/></>}

{(!loading.content && content) &&
  <Form
          name="basic"
          onFinish={this.onSubmitSearch}
          autoComplete="off"
          layout='vertical'
          onFinishFailed={this.onFinishFailed}
          initialValues={content}
        >
          
          <div className="row">
            
          <div className="col-xs-12 col-sm-12 col-md-12 col-lg-6">
          <Form.Item
        label="Họ"
        name="FirstName"
        rules={[{ required: true, message: 'Vui lòng nhập Họ' }]}
      >
        <Input />
      </Form.Item>
            </div>
          <div className="col-xs-12 col-sm-12 col-md-12 col-lg-6">
          <Form.Item
        label="Tên"
        name="LastName"
        rules={[{ required: true, message: 'Vui lòng nhập Tên ' }]}
      >
        <Input />
      </Form.Item>
            </div>
          <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
         
            <Form.Item
        label="Số điện thoại người liên hệ"
        name="Phone"
        rules={[{ required: true, message: 'Vui lòng nhập Số điện thoại liên hệ' }]}
      >
        <Input />
      </Form.Item>
            <Form.Item
            
        label="Chức vụ"
        name="Position"
      >
        <Input  />
      </Form.Item>
            </div>
          </div>
         
          <Form.Item className='mb-0'>
            <Button disabled={loading.submit}  size="large" type="primary"  htmlType="submit" className="text-center w-100 mt-3">
              <b className="w-100 text-center"> CẬP NHẬT</b>
            </Button>
            </Form.Item>
            <div style={{height:'10px'}}>
             {loading.submit ?  <LinearProgress color='success' />:""}
                 </div>
            
             </Form>
}
            
             {error && <Typography className='text-center' style={{color:'red'}}>{error}</Typography>}   

         </div>
        </Card>
      </Animated>
    </div>
    );
  }
}

UpdatePartnerProfilePage.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  updatePartnerProfilePage: makeSelectUpdatePartnerProfilePage(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    onEndOfAction: () => {
      dispatch(actions.endOfAction());
    },
    onGetContent: id => {
      dispatch(actions.getContent(id));
    },
    onSubmitContent: content => {
      dispatch(actions.submitContent(content));
    },
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

const withReducer = injectReducer({ key: 'updatePartnerProfilePage', reducer });
const withSaga = injectSaga({ key: 'updatePartnerProfilePage', saga });

UpdatePartnerProfilePage.contextType = AuthContext;

export default compose(
  withConnect,
  withReducer,
  withSaga,
)(UpdatePartnerProfilePage);
