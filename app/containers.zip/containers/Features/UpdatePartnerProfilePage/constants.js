/*
 *
 * UpdatePartnerProfilePage constants
 *
 */

export const DEFAULT_ACTION = 'app/UpdatePartnerProfilePage/DEFAULT_ACTION';
export const END_OF_ACTION = 'app/UpdatePartnerProfilePage/END_OF_ACTION';
export const GET_CONTENT = 'app/UpdatePartnerProfilePage/GET_CONTENT';
export const GET_CONTENT_SUCCESS = 'app/UpdatePartnerProfilePage/GET_CONTENT_SUCCESS';
export const GET_CONTENT_FAILED = 'app/UpdatePartnerProfilePage/GET_CONTENT_FAILED';
export const SUBMIT_CONTENT = 'app/UpdatePartnerProfilePage/SUBMIT_CONTENT';
export const SUBMIT_CONTENT_SUCCESS = 'app/UpdatePartnerProfilePage/SUBMIT_CONTENT_SUCCESS';
export const SUBMIT_CONTENT_FAILED = 'app/UpdatePartnerProfilePage/SUBMIT_CONTENT_FAILED';
