/**
 *
 * RecruitmentRequestRecruiterPage
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import makeSelectRecruitmentRequestRecruiterPage from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import * as actions from './actions';
import './styles.scss';
import {
  Input,
  Table,
  Typography,
  Form,
  Button,
  DatePicker,
  Tabs,
  Select,
  Tag,
} from 'antd';
import { Link } from 'react-router-dom';
import moment from 'moment';

class RecruitmentRequestRecruiterPage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      valueSearch: null, 
     
    };
  }
  formRef = React.createRef();
  
  componentWillUnmount() {
    this.props.onEndOfAction();
  }
  searchProfession = value => {
    this.props.onGetProfessionList(value);
  };
  searchSkill = value => {
    this.props.onGetSkillList(value);
  };

  componentWillMount(){
    this.props.onGetContentList();
  }
  onSubmit = value => {
    console.log(value);
    this.setState({ valueSearch: value });

    this.props.onGetContentList(value);
  };
  onSubmitFailed = errorInfo => {};
  onSelectChange = ()=>{
    this.props.onGetContentList(this.formRef.current.getFieldsValue())
  }
  handleTableChange = (newPagination, filters, sorter)=>{
    console.log(newPagination, filters, sorter );
    this.props.onPagination(newPagination.current, newPagination.pageSize)
    this.props.onGetContentList({...this.state.valueSearch});

} 
onSelectChange = ()=>{
  this.props.onGetContentList(this.formRef.current.getFieldsValue())
}

  dataSource = [
    {
      ID: '1',
      Titlesad: (
        <Form.Item name="Title">
          <Input name="Title" />
        </Form.Item>
      ),
    },
  ];
  onSubmit = value => {
    console.log(value);
    this.setState({ valueSearch: value });
    this.props.onGetContentList(value);

  };
  onSubmitFailed = errorInfo => {};
  onChangeTab = key => {
    console.log(key);
  };
  columns = [
    {
      title: 'ID',
     children: [{ key: 'Id',
     dataIndex: 'Id',
     width:70,
     render: (value)=><Link to={`/recruitment-request-recruiter/edit/${value}`}>{value}</Link>}]
    }, 

    {
      title: 'Yêu cầu tuyển dụng',
      children: [
        {
          title: (
            <Form.Item name="Title">
              <Input />
            </Form.Item>
          ),
          key: 'Title',
          dataIndex: 'Title',
        },
      ],
    },
    {
      title: 'Tag',
      children: [
        {
          title: ()=> (
            <Form.Item name="Tag">
              <Input />
            </Form.Item>
          ),
          key: 'Tag',
          dataIndex: 'Tag',
        },
      ],
    },
    {
      title: 'Ngành nghề',
      children: [
        {
          title: ()=> (
            <Form.Item name="Professions">
              <Select
                className="w-100"
                placeholder="Ngành nghề"
                suffixIcon={''}
                showSearch
                onSearch={this.searchProfession}
                filterOption={false}
                onChange={this.onSelectChange}
                loading={
                  this.props.recruitmentRequestRecruiterPage.loading
                    .professionList
                }
                allowClear={true}
                notFoundContent={''}
              >
                {console.log(
                  this.props.recruitmentRequestRecruiterPage.professionList,
                )}
                {this.props.recruitmentRequestRecruiterPage.professionList &&
                  this.props.recruitmentRequestRecruiterPage.professionList.map(
                    item => (
                      <Select.Option
                        value={item.TKey}
                        key={`options-profession-${item.Id}`}
                      >
                        {item.TValue}
                      </Select.Option>
                    ),
                  )}
                    {this.props.recruitmentRequestRecruiterPage.loading.professionList && (
                <Select.Option disabled>Đang tải...</Select.Option>
              )}
              </Select>
            </Form.Item>
          ),
          key: 'Professions',
          dataIndex: 'Professions',
        },
      ],
    },
    {
      title: 'Kỹ năng',
      children: [
        {
          title: ()=> (
            <Form.Item name="Skill">
            <Select
              className="w-100"
              placeholder="Kỹ năng"
              onChange={this.onSelectChange}

              suffixIcon={''}
              showSearch
              onSearch={this.searchSkill}
              filterOption={false}
              loading={this.props.recruitmentRequestRecruiterPage.loading.skillList}
              allowClear={true}
              notFoundContent={''}
            >
              {this.props.recruitmentRequestRecruiterPage.skillList &&
                this.props.recruitmentRequestRecruiterPage.skillList.map(item => (
                  <Select.Option
                    value={item.TKey}
                    key={`options-profession-${item.Id}`}
                  >
                    {item.TValue}
                  </Select.Option>
                ))}
                  {this.props.recruitmentRequestRecruiterPage.loading.skillList && (
                <Select.Option disabled>Đang tải...</Select.Option>
              )}
            </Select>
          </Form.Item>
          ),
          key: 'ListSkill',
          dataIndex: 'ListSkill',
          render: record => record.map(el=><Tag>{el} </Tag>)
        },
      ],
    },
    {
      title: 'Số lượng',
     children: [{ key: 'Quantity',
     dataIndex: 'Quantity',}]
    },
    {
      title: 'Ngày yêu cầu',
      children: [
        {
          title:()=> (
            <Form.Item name="CreateAt">
              <DatePicker
                onChange={this.onSelectChange}
                />
            </Form.Item>
          ),
          key: 'CreateAt',
          dataIndex: 'CreateAt',
          render: (value)=><span>   {moment(value).format('DD/MM/YYYY')}</span>
        },
      ],
    },
    {
      title: 'Ngày hết hạn',
      children: [
        {
          title: ()=> (
            <Form.Item name="DueDate">
                            <DatePicker 
                onChange={this.onSelectChange}
                />

            </Form.Item>
          ),
          key: 'DueDate',
          dataIndex: 'DueDate',
          render: (value)=><span>   {moment(value).format('DD/MM/YYYY')}</span>
        },
      ],
    },
    {
      title: 'Người phụ trách',
      children: [
        {
          title: ()=> (
            <Form.Item name="Email">
              <Input/>
            </Form.Item>
          ),
          key: 'Email',
          dataIndex: 'Email',
        },
      ],
    },
    {
      title: 'Số CV đã gửi',
     children: [{ key: 'QuantityCv',
     dataIndex: 'QuantityCv',}]
    },
    {
      title: 'Số CV thiếu',
      children: [{   key: 'QuantityLess',
      dataIndex: 'QuantityLess',}],
   
    },
    {
      title: 'Số CV chấp nhận',
      children: [{    key: 'QuanityAcceptedCv',
      dataIndex: 'QuanityAcceptedCv',}],

  
    },
    {
      title: 'Đã phỏng vấn',
      children: [{    key: 'QuantityInterviewCv',
      dataIndex: 'QuantityInterviewCv',}],

  
    },
    {
      title: 'Đã đi làm',
      children: [{      key: 'QuantityWorkedCv',
      dataIndex: 'QuantityWorkedCv',}],


    },
    {
      title: 'Ngày cập nhật cuối',
      children: [
        {
          title: ()=> (
            <Form.Item name="UpdateDate">
             <DatePicker 
                onChange={this.onSelectChange}
                />
            </Form.Item>
          ),
          key: 'UpdateDate',
          dataIndex: 'UpdateDate',
          render: (value)=><span>   {moment(value).format('DD/MM/YYYY')}</span>
        },
      ],
    },
    {
      title: 'Xem CV',
      children: [{      key: 'xxx',
      dataIndex: 'xxx',}],
    },
  ];
  render() {
    const {
      loading,
      professionList,
      skillList,
      requestList, total, current, pageSize
    } = this.props.recruitmentRequestRecruiterPage;
    return (
    
        <Form
          name="basic"
          onFinish={this.onSubmit}
          autoComplete="off"
          layout="vertical"
          initialValues={{}}
          onFinishFailed={this.onSubmitFailed}
          className="ant-general-form"
       ref={this.formRef} 

        >
          <Button htmlType='submit'></Button>

          <Table
            className="mt-5"
            size='small'
            columns={this.columns}
            scroll={{ x: 3000, y: 1000 }}
            dataSource={requestList}
            loading={loading.getContent}
         pagination={{total,current, pageSize}}
         onChange={this.handleTableChange}

            
          >
          </Table>
        </Form>
    );
  }
}

RecruitmentRequestRecruiterPage.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  recruitmentRequestRecruiterPage: makeSelectRecruitmentRequestRecruiterPage(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    onEndOfAction: () => {
      dispatch(actions.endOfAction());
    },
    onGetProfessionList: content => {
      dispatch(actions.getProfessionList(content));
    },
    onGetSkillList: content => {
      dispatch(actions.getSkillList(content));
    },
    onGetContentList: content => {
      dispatch(actions.getContentList(content));
    },
    onPagination: (current, pageSize) => {
      dispatch(actions.pagination(current, pageSize));
    },
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

const withReducer = injectReducer({
  key: 'recruitmentRequestRecruiterPage',
  reducer,
});
const withSaga = injectSaga({ key: 'recruitmentRequestRecruiterPage', saga });
export default compose(
  withConnect,
  withReducer,
  withSaga,
)(RecruitmentRequestRecruiterPage);
