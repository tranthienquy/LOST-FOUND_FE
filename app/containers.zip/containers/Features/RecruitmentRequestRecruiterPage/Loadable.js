/**
 *
 * Asynchronously loads the component for RecruitmentRequestRecruiterPage
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
