/*
 *
 * RecruitmentRequestRecruiterPage constants
 *
 */

export const DEFAULT_ACTION =
  'app/RecruitmentRequestRecruiterPage/DEFAULT_ACTION';
export const END_OF_ACTION =
  'app/RecruitmentRequestRecruiterPage/END_OF_ACTION';

  export const GET_PROFESSION = 'app/RecruitmentRequestRecruiterPage/GET_PROFESSION';
  export const GET_PROFESSION_SUCCESS = 'app/RecruitmentRequestRecruiterPage/GET_PROFESSION_SUCCESS';
  export const GET_PROFESSION_FAILED = 'app/RecruitmentRequestRecruiterPage/GET_PROFESSION_FAILED';
  
export const GET_SKILL = 'app/RecruitmentRequestRecruiterPage/GET_SKILL';
export const GET_SKILL_SUCCESS = 'app/RecruitmentRequestRecruiterPage/GET_SKILL_SUCCESS';
export const GET_SKILL_FAILED = 'app/RecruitmentRequestRecruiterPage/GET_SKILL_FAILED';
export const GET_CONTENT = 'app/RecruitmentRequestRecruiterPage/GET_CONTENT';
export const GET_CONTENT_SUCCESS = 'app/RecruitmentRequestRecruiterPage/GET_CONTENT_SUCCESS';
export const GET_CONTENT_FAILED = 'app/RecruitmentRequestRecruiterPage/GET_CONTENT_FAILED';
export const PAGINATION = 'app/RecruitmentRequestRecruiterPage/PAGINATION';