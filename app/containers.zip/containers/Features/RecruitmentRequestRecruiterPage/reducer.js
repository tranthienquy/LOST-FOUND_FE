/*
 *
 * RecruitmentRequestRecruiterPage reducer
 *
 */
import produce from 'immer';
import * as types from './constants';

export const initialState = {

  professionList: [],
  skillList: [],
  requestList: [],
  loading: {
skillList: false,
professionList: false,
getContent: true
  },
  current: 1,
  pageSize: 10,
  total: 0,
};

/* eslint-disable default-case, no-param-reassign */
const recruitmentRequestRecruiterPageReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case types.DEFAULT_ACTION:
        break;
      case types.END_OF_ACTION:
        for (var element in draft) {
          draft[element] = initialState[element];
        }
        break;

        case types.GET_PROFESSION:
          draft.loading.professionList = action.content ? true : false;
          if (!action.content) {
            draft.professionList = [];
          }
          break;
        case types.GET_PROFESSION_SUCCESS:
          draft.loading.professionList = false;
          draft.professionList = action.payload.data.value;
          break;
        case types.GET_PROFESSION_FAILED:
          break;
  
        case types.GET_SKILL:
          draft.loading.skillList = action.content ? true : false;
          if (!action.content) {
            draft.skillList = [];
          }
          break;
        case types.GET_SKILL_SUCCESS:
          draft.loading.skillList = false;
          draft.skillList = action.payload.data.value;
          break;
        case types.GET_SKILL_FAILED:
          break;
          case types.PAGINATION:
            draft.current = action.current;
            draft.pageSize = action.pageSize;
            break;
  
            case types.GET_CONTENT:
              draft.loading.getContent = true;
              break;
            case types.GET_CONTENT_SUCCESS:
              draft.loading.getContent = false;
              draft.total = action.payload.data.totalPage;
              draft.requestList = action.payload.data.results;
              break;
            case types.GET_CONTENT_FAILED:
              draft.loading.getContent = false;
              break;
  
    }
  });

export default recruitmentRequestRecruiterPageReducer;
