import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the recruitmentRequestRecruiterPage state domain
 */

const selectRecruitmentRequestRecruiterPageDomain = state =>
  state.recruitmentRequestRecruiterPage || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by RecruitmentRequestRecruiterPage
 */

const makeSelectRecruitmentRequestRecruiterPage = () =>
  createSelector(
    selectRecruitmentRequestRecruiterPageDomain,
    substate => substate,
  );

export default makeSelectRecruitmentRequestRecruiterPage;
export { selectRecruitmentRequestRecruiterPageDomain };
