import { take, call, put, select, takeLatest, delay, fork, takeEvery } from 'redux-saga/effects';
import * as types from './constants';
import * as actions from './actions';
import * as api from 'utils/api';
import { KEY_VALUE } from '../../../utils/api/constants';
// Individual exports for testing

function* getProfessionList({content}){
  if (content){
    yield delay(500);

  const resp = yield call(
    api.postPagination,
    `v1/KeyValues`,
    null,
    null,
    `TGroup eq ${KEY_VALUE.PROFESSION} and contains(tolower(TValue),tolower('${encodeURIComponent(content)}'))`,
    null
  );
  const { data, status } = resp;
  if (status == 200) {
    yield put(actions.getProfessionListSuccess(data));
  } else {
    yield put(actions.getProfessionListFailed());
  }
}
}


function* getSkillList({content}){

  if (content){
    yield delay(500);

  const resp = yield call(
    api.postPagination,
    `v1/KeyValues`,
    null,
    null,
    `TGroup eq ${KEY_VALUE.SKILL} and contains(tolower(TValue),tolower('${encodeURIComponent(content)}'))`,
    null
  );
  const { data, status } = resp;
  if (status == 200) {
    yield put(actions.getSkillListSuccess(data));
  } else {
    yield put(actions.getSkillListFailed());
  }
}
}

function* getRequestList({content}) {
  const { current, pageSize } = yield select(state => state.recruitmentRequestRecruiterPage);
  let filter = '' ;
  

  const resp = yield call(
    api.post,
    `v1/Requests/get-request`,{},
    {...content, NumPage:current, PerPage: pageSize},
  );
  const { data, status } = resp;
  if (status == 200) {
    yield delay(500);
    yield put(actions.getContentListSuccess(data));
  } else {
    yield put(actions.getContentListFailed());
  }
}
export default function* recruitmentRequestRecruiterPageSaga() {
  // See example in containers/HomePage/saga.js
  yield takeLatest(types.GET_PROFESSION, getProfessionList)
  yield takeLatest(types.GET_SKILL, getSkillList);
  yield takeLatest(types.GET_CONTENT, getRequestList);

}
