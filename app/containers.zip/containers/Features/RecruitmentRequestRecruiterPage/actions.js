/*
 *
 * RecruitmentRequestRecruiterPage actions
 *
 */

import {
  DEFAULT_ACTION,
  END_OF_ACTION,
  GET_PROFESSION,
  GET_PROFESSION_FAILED,
  GET_PROFESSION_SUCCESS,
  GET_SKILL,
  GET_SKILL_SUCCESS,
  GET_SKILL_FAILED,
  GET_CONTENT, GET_CONTENT_FAILED, GET_CONTENT_SUCCESS, PAGINATION, 
} from './constants';

export function defaultAction() {
  return {
    type: DEFAULT_ACTION,
  };
}
export const endOfAction = () => {
  return {
    type: END_OF_ACTION,
  };
};

export const getProfessionList = (content = '') => {
  return {
    type: GET_PROFESSION,
    content,
  };
};
export const getProfessionListSuccess = data => {
  return {
    type: GET_PROFESSION_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getProfessionListFailed = () => {
  return {
    type: GET_PROFESSION_FAILED,
  };
};

export const getSkillList = (content = '') => {
  return {
    type: GET_SKILL,
    content,
  };
};
export const getSkillListSuccess = data => {
  return {
    type: GET_SKILL_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getSkillListFailed = () => {
  return {
    type: GET_SKILL_FAILED,
  };
};

export const getContentList = (content = null) => {
  return {
    type: GET_CONTENT,
    content,
  };
};
export const getContentListSuccess = data => {
  return {
    type: GET_CONTENT_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getContentListFailed = () => {
  return {
    type: GET_CONTENT_FAILED,
  };
};
export const pagination = (current, pageSize) => {
  return {
    type: PAGINATION,
    current,
    pageSize,
  };
};
