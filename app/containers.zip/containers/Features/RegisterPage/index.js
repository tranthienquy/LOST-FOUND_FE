/**
 *
 * RegisterPage
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import makeSelectRegisterPage from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import './styles.scss';
import * as actions from './actions';

import { Card, Typography, Input, Button, Form, Spin } from 'antd';
import { Link, Redirect } from 'react-router-dom';
import { Animated } from 'react-animated-css';
import { LinearProgress } from '@mui/material';


class RegisterPage extends React.Component {
  onSubmitSearch = value => {
    this.props.onRegister(value);
  };
  onFinishFailed = errorInfo =>{

  }
  repeatPassword= (_, value,sss)=>{
    console.log(_, value)
    return Promise.reject(new Error('abcd'));
  }
  render(){

    const {loading, error}= this.props.registerPage;

     return (
      <div className="register-container">
      <Animated className="d-flex justify-content-center align-items-center w-100 h-100"
      animationIn="fadeInUp"
                animationOut=""
                isVisible={true}
                animationInDuration={500}
                animationInDelay={0}>
        <Card className="login-card">
          <div
                
                 className="d-flex flex-column justify-content-center"
              >
            <Typography className="text-center head-title font-weight-bold mt-2 mb-5">
              ĐĂNG KÝ TÀI KHOẢN
            </Typography>
            <Form
          name="basic"
          onFinish={this.onSubmitSearch}
          autoComplete="off"
          layout='vertical'
          onFinishFailed={this.onFinishFailed}
        >
          
          <div className="row">
            <div className="col-xs-12 col-sm-12 col-md-12 col-lg-6">
            <Form.Item
        label="Tên"
        name="LastName"
        rules={[{ required: true, message: 'Vui lòng nhập Tên' }]}
      >
        <Input />
      </Form.Item>
            </div>
            <div className="col-xs-12 col-sm-12 col-md-12 col-lg-6">
            <Form.Item
        label="Họ"
        name="FirstName"
        rules={[{ required: true, message: 'Vui lòng nhập Họ' }]}
      >
        <Input />
      </Form.Item>
            </div>
            <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <Form.Item
        label="Email"
        name="Email"
        rules={[{ required: true, message: 'Vui lòng nhập Email' }, {
          type: 'email',
          message: 'Email không đúng định dạng',
        },]}
      >
        <Input   prefix={<i className="icon-Envelope h5 login-icon" />}/>
      </Form.Item>
            </div>
            <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <Form.Item
        label="Mật khẩu"
        name="Password"
        rules={[{ required: true, message: 'Vui lòng nhập Mật khẩu' }]}
      >
        <Input type={'password'}  prefix={<i className="icon-Key h5 login-icon" />}/>
      </Form.Item>
            <Form.Item
            
        label="Nhập lại mật khẩu"
        name="RePassword"
        rules={[{ required: true, message: 'Vui lòng nhập lại mật khẩu' },
        ({ getFieldValue }) => ({
          validator(_, value) {
            if (!value || getFieldValue('Password') === value) {
              return Promise.resolve();
            }
            return Promise.reject(new Error('Mật khẩu không trùng khớp'));
          },
        }),
      ]}
      >
        <Input type={'password'}  prefix={<i className="icon-Key h5 login-icon" />}/>
      </Form.Item>
            </div>
          </div>
         
          <Form.Item className='mb-0'>
            <Button disabled={loading}  size="large" type="primary"  htmlType="submit" className="text-center w-100 mt-3">
              <b className="w-100 text-center"> ĐĂNG KÝ</b>
            </Button>
            </Form.Item>
            <div style={{height:'10px'}}>
             {loading ?  <LinearProgress color='success' />:""}
                 </div>
            
             </Form>
             {(error && error=="Email exited") && <Typography className='text-center' style={{color:'red'}}>
             Email đã được đăng ký. Nếu bạn quên mật khẩu, <Link to="/forgot-password" className='font-weight-bold'> click vào đây</Link>
              </Typography>}   

            <Typography className='mt-1'>Bạn đã có tài khoản?<Link to={'login'} className="pl-2 link-text-on-click font-weight-bold">Đăng nhập ngay!</Link></Typography>
         </div>
        </Card>
      </Animated>
    </div>
  );
  }
 

 
}

RegisterPage.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  registerPage: makeSelectRegisterPage(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    onRegister: value=>{
      dispatch(actions.register(value));
    }
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);


const withReducer=  injectReducer({ key: 'registerPage', reducer });
const withSaga=  injectSaga({ key: 'registerPage', saga });
export default compose(withConnect, withReducer, withSaga)(RegisterPage);
