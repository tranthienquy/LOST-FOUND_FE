import { take, call, put, select, takeLatest, delay } from 'redux-saga/effects';
import { push } from 'react-router-redux';
import * as types from './constants';
import * as actions from './actions';
import * as api from 'utils/api';
import { notification } from 'antd';

function* register({value}){
  console.log(value)
delete value.RePassword;
  const resp = yield call(
    api.post,
    `v1/Accounts/create-account`, {}, value
  );
  const { data, status } = resp;

  if (status == 200 ) {
    yield delay(2000);
    yield put(actions.registerSuccess(data));
    yield notification.open({
      message:"Đăng ký thành công. Vui lòng đăng nhập!"
    })
    yield put(push('/login'));
  } else {
    yield put(actions.registerFailed(data.message));
  }
}

// Individual exports for testing
export default function* registerPageSaga() {
  // See example in containers/HomePage/saga.js
  yield takeLatest(types.REGISTER, register);
  
}
