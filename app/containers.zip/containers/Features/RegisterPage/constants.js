/*
 *
 * RegisterPage constants
 *
 */

export const DEFAULT_ACTION = 'app/RegisterPage/DEFAULT_ACTION';
export const REGISTER = 'app/RegisterPage/REGISTER';
export const REGISTER_SUCCESS = 'app/RegisterPage/REGISTER_SUCCESS';
export const REGISTER_FAILED = 'app/RegisterPage/REGISTER_FAILED';
