/**
 *
 * JobRequestPage
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import makeSelectJobRequestPage from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import './styles.scss';
import * as actions from './actions';
import { Form, Input, Button, Select, Typography, Pagination, DatePicker } from 'antd';
import { Helmet } from 'react-helmet';
import JobRequestListComponent from '../../../components/JobRequestListComponent';
import * as api from 'utils/api';
import { KEY_VALUE } from '../../../utils/api/constants';
import AuthContext from '../../../utils/auth';

class JobRequestPage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      valueSearch: null,
      professionSuggestList: [],
      professionSearch:''
    };
  }
  onSubmitSearch = value => {
    this.setState({ valueSearch: value });
    this.props.onPagination(1, this.props.jobRequestPage.pageSize);
    this.props.onGetJobRequestList({...value, partnerID : this.context.user.Id});
  };
  componentWillMount() {
    api.postPagination( `v1/KeyValues`, 1, 4, `TGroup eq ${KEY_VALUE.PROFESSION} `, null ).then(res=>{
      this.setState ({professionSuggestList: res.data.value})
    })
    
    this.props.onGetJobRequestList({partnerID : this.context.user.Id});
    this.props.onGetLocationList();

  }
  formRef = React.createRef();

  onChangePagination = (page, pageSize) => {
    this.props.onPagination(page, pageSize);
    this.props.onGetJobRequestList({...this.state.valueSearch, partnerID : this.context.user.Id});
  };
  onChangePageSize = value => {
    this.onChangePagination(this.props.jobRequestPage.current, value);
  };

  componentWillUnmount() {
    this.props.onEndOfAction();
  }

  searchCompany = value => {
    console.log(value);
    this.props.onGetCompanyList(value);
  };
  searchProfession = value => {
    this.setState({professionSearch:value})
    this.props.onGetProfessionList(value);
  };
  searchSkill = value => {
    console.log(value);
    this.props.onGetSkillList(value);
  };

  onFillSuggestProfession = value =>{
    this.formRef.current.setFieldsValue({
      Professions: value.TKey
    })
  }

  render() {
    const {
      jobRequestList,
      loading,
      current,
      pageSize,
      total,
      companyList,
      companyLoading,
      locationList,
      skillList,
      professionLoading,
      professionList,
      skillLoading,
    } = this.props.jobRequestPage;
    console.log(companyList);
    const { professionSearch, professionSuggestList} = this.state;

    return (
      <div className="job-request-container">
        <Helmet>
          <title>Yêu cầu việc làm</title>
        </Helmet>
        <Form name="basic" onFinish={this.onSubmitSearch} autoComplete="off"  ref={this.formRef} >
          <div className="row">
            <div className="col-xs-12 col-sm-12 col-md-6 col-lg-4 pl-4 pr-4 mt-2">
              <div className="ant-form-item-control-input-content select-input">
                <span className="ant-input-affix-wrapper d-flex align-items-center">
                  <span className="ant-input-prefix">
                    <i className="icon-Box-outline h5 feature-icon" />
                  </span>
                  <Form.Item name="Professions">
                    <Select
                      className="w-100"
                      placeholder="Ngành nghề"
                      bordered={false}
                      suffixIcon={''}
                      showSearch
                      onSearch={this.searchProfession}
                      filterOption={false}
                      loading={professionLoading}
                      allowClear={true}
                      notFoundContent={''}
                   
                    >
                     {professionList &&
                        professionList.map(item => (
                          <Select.Option
                            value={item.TKey}
                            key={`options-profession-${item.Id}`}
                          >
                           
                            {item.TValue}
                          </Select.Option>
                        ))}
                         {professionList.length==0 && !professionLoading && !professionSearch && professionSuggestList &&
                       <>
                        <Select.Option disabled><i className='text-app-primary'>Gợi ý dành cho bạn</i></Select.Option>
                     {  professionSuggestList.map(item => (
                          <Select.Option
                            value={item.TKey}
                            key={`options-company-${item.TKey}`}
                          >
                          
                            {item.TValue}
                          </Select.Option>
                        ))}
                        </>
                        }
                      {professionLoading && (
                        <Select.Option disabled>Đang tải...</Select.Option>
                      )}
                    </Select>
                  </Form.Item>

                </span>
                {professionSuggestList && professionSuggestList.map(el => 
                       <span onClick={()=>this.onFillSuggestProfession(el)} className="link-text-on-click small-size-hint mr-2 ">
                       {el.TValue}
                     </span>
                      )}
              </div>
            </div>

         
          
            <div className="col-xs-12 col-sm-12 col-md-6 col-lg-4 pl-4 pr-4 mt-2">
              <div className="ant-form-item-control-input-content select-input">
                <span className="ant-input-affix-wrapper d-flex align-items-center search-field">
                  <span className="ant-input-prefix">
                    <i className="icon-Cursor-outline h5 feature-icon" />
                  </span>
                  <Form.Item name="Location">
                    <Select
                      className="w-100"
                      placeholder="Địa điểm"
                      bordered={false}
                      suffixIcon={<i className="icon-Caret-down h3" />}
                      allowClear={true}
                      filterOption={(input, option) =>
                        option.children
                          .toLowerCase()
                          .includes(input.toLowerCase())
                      }
                      showSearch
                      mode="multiple"
                      maxTagCount='responsive'
                    >
                      {locationList.map(item => (
                        <Select.Option key={`options-location-${item.TKey}`} value={item.TKey}>
                          {item.TValue}
                        </Select.Option>
                      ))}
                
                    </Select>
                  </Form.Item>
                </span>
              </div>
            </div>
          
            <div className="col-xs-12 col-sm-12 col-md-6 col-lg-4 pl-4 pr-4 mt-2">
              <div className="ant-form-item-control-input-content select-input">
                <span className="ant-input-affix-wrapper d-flex align-items-center search-field">
                  <span className="ant-input-prefix">
                    <i className="icon-Bag-outline h5 feature-icon" />
                  </span>
                  <Form.Item name="Status">
                    <Select
                      className="w-100"
                      placeholder="Trạng thái"
                      bordered={false}
                      suffixIcon={<i className="icon-Caret-down h3" />}
                      allowClear={true}
                    
                      mode="multiple"
                      maxTagCount='responsive'
                    >
                        <Select.Option key={`options-status`} value={1}>
                          Đăng xử lýa
                        </Select.Option>
                        <Select.Option key={`options-status`} value={11}>
                          Đăng xử lý
                        </Select.Option>
                        <Select.Option key={`options-status`} value={1}>
                          Đăng xử lý
                        </Select.Option>
                        <Select.Option key={`options-status`} value={1}>
                          Đăng xử lý
                        </Select.Option>
                
                    </Select>
                  </Form.Item>
                </span>
              </div>
            </div>
           

            <div className="col-xs-12 col-sm-12 col-md-6 col-lg-4 pl-4 pr-4 mt-2">
              <Form.Item name="Title" initialValue={''}>
                <Input
                  placeholder="Yêu cầu tuyển dụng"
                  prefix={
                    <i className="icon-Document-outline h5 feature-icon" />
                  }
                />
              </Form.Item>
            </div>

            <div className="col-xs-12 col-sm-12 col-md-6 col-lg-4 pl-4 pr-4 mt-2">
              <Form.Item name="date" initialValue={''}>
                <DatePicker.RangePicker
                className='w-100'
                placeholder={['Ngày hết hạn']}
                  prefix={
                    <i className="icon-Document-outline h5 feature-icon" />
                  }
                />
              </Form.Item>
            </div>
            <div className="col-xs-12 col-sm-12 col-md-6 col-lg-4 pl-4 pr-4 mt-2">
              <Form.Item>
                <Button
                  type="primary"
                  htmlType="submit"
                  className="w-100 button-submit"
                >
                  <span className="w-100 text-center d-flex justify-content-center">
                    {' '}
                    <i className="icon-Search mr-1" /> TÌM KIẾM
                  </span>
                </Button>
              </Form.Item>
            </div>
          </div>
        </Form>
        <div />
        <JobRequestListComponent loading={loading} value={jobRequestList} />
        <div className="pagination-foot w-100 mt-5 d-flex flex-row flex-wrap justify-content-between">
          <div className="d-flex flex-row align-items-center mb-2">
            <Typography className="mr-1">Kết quả mỗi trang</Typography>
            <Select
              className="select-number-page"
              value={pageSize}
              onChange={this.onChangePageSize}
              suffixIcon={
                <i className="icon-Caret-down h3 text-app-primary pr-3" />
              }
            >
              <Option value="10">10</Option>
              <Option value="20">20</Option>
              <Option value="30">30</Option>
              <Option value="50">50</Option>
              <Option value="100">100</Option>
            </Select>
          </div>

          <Pagination
            current={current}
            total={total}
            pageSize={pageSize}
            onChange={this.onChangePagination}
            showTotal={(total, range) =>
              `Hiển thị ${range[0]}-${range[1]} của ${total}`
            }
          />
        </div>
      </div>
    );
  }
}

JobRequestPage.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  jobRequestPage: makeSelectJobRequestPage(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    onEndOfAction: () => {
      dispatch(actions.endOfAction());
    },
    onGetJobRequestList: content => {
      dispatch(actions.getJobRequestList(content));
    },
    onGetCompanyList: content => {
      dispatch(actions.getCompanyList(content));
    },
    onGetKeyValueList: name => {
      dispatch(actions.getKeyValueList(name));
    },
    onPagination: (current, pageSize) => {
      dispatch(actions.pagination(current, pageSize));
    },
    onGetLocationList: () => {
      dispatch(actions.getLocationList());
    },
    onGetProfessionList: content => {
      dispatch(actions.getProfessionList(content));
    },
    onGetSkillList: content => {
      dispatch(actions.getSkillList(content));
    },
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

const withReducer = injectReducer({ key: 'jobRequestPage', reducer });
const withSaga = injectSaga({ key: 'jobRequestPage', saga });
JobRequestPage.contextType = AuthContext;

export default compose(
  withConnect,
  withReducer,
  withSaga,
)(JobRequestPage);
