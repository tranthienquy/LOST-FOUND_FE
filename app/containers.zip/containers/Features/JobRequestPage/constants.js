/*
 *
 * JobRequestPage constants
 *
 */

export const DEFAULT_ACTION = 'app/JobRequestPage/DEFAULT_ACTION';
export const END_OF_ACTION = 'app/JobRequestPage/END_OF_ACTION';
export const GET_CONTENT = 'app/JobRequestPage/GET_CONTENT';
export const GET_CONTENT_SUCCESS = 'app/JobRequestPage/GET_CONTENT_SUCCESS';
export const GET_CONTENT_FAILED = 'app/JobRequestPage/GET_CONTENT_FAILED';
export const PAGINATION = 'app/JobRequestPage/PAGINATION';

export const GET_COMPANY = 'app/JobRequestPage/GET_COMPANY';
export const GET_COMPANY_SUCCESS = 'app/JobRequestPage/GET_COMPANY_SUCCESS';
export const GET_COMPANY_FAILED = 'app/JobRequestPage/GET_COMPANY_FAILED';

export const GET_KEY_VALUE = 'app/JobRequestPage/GET_KEY_VALUE';
export const GET_KEY_VALUE_SUCCESS = 'app/JobRequestPage/GET_KEY_VALUE_SUCCESS';
export const GET_KEY_VALUE_FAILED = 'app/JobRequestPage/GET_KEY_VALUE_FAILED';

export const GET_LOCATION = 'app/JobRequestPage/GET_LOCATION';
export const GET_LOCATION_SUCCESS = 'app/JobRequestPage/GET_LOCATION_SUCCESS';
export const GET_LOCATION_FAILED = 'app/JobRequestPage/GET_LOCATION_FAILED';

export const GET_PROFESSION = 'app/JobRequestPage/GET_PROFESSION';
export const GET_PROFESSION_SUCCESS = 'app/JobRequestPage/GET_PROFESSION_SUCCESS';
export const GET_PROFESSION_FAILED = 'app/JobRequestPage/GET_PROFESSION_FAILED';

export const GET_SKILL = 'app/JobRequestPage/GET_SKILL';
export const GET_SKILL_SUCCESS = 'app/JobRequestPage/GET_SKILL_SUCCESS';
export const GET_SKILL_FAILED = 'app/JobRequestPage/GET_SKILL_FAILED';

