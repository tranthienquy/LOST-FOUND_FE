import { take, call, put, select, takeLatest, delay, fork, takeEvery } from 'redux-saga/effects';
import * as types from './constants';
import * as actions from './actions';
import * as api from 'utils/api';
import { KEY_VALUE } from '../../../utils/api/constants';

function* getJobRequestList({content}) {
  const { current, pageSize } = yield select(state => state.jobRequestPage);
  console.log(content);
  let filter = '' ;
  if (content){
    let cityFilter='';
    if(content.Location && content.Location.length >0) {
      cityFilter += yield "("
      yield content.Location.forEach(el=>{
        cityFilter += `contains(tolower(City),tolower('${encodeURIComponent(el)}')) or `
      })
      cityFilter = yield cityFilter.slice(0, -3);
      cityFilter += yield ") and"
    }
    filter=
    (content.Title ? `contains(tolower(Title),tolower('${encodeURIComponent(content.Title)}')) and ` :'')
   + (content.Professions ? `contains(Profession,'${encodeURIComponent(content.Professions)}') and ` :'')
  //  + (content.Location ? `City eq '${content.Location}' and `: '')
   + (content.partnerID  ? `RequestAssignments/Any(c:c/ProfileID eq ${content.partnerID})  and `: '')
   +( content.CompanyID ? `CompanyID eq ${content.CompanyID.value} and `:'') + cityFilter;

}
if (filter){
  filter= filter.slice(0, -4);
}
console.log(filter);
  const resp = yield call(
    api.postPagination,
    `v1/Requests`,
    current,
    pageSize,
    filter,
    {CreateByNavigation:{expand: `Company(select=Id,Name,Avatar);select=Company),RequestAssignments(filter=ProfileId eq ${content.partnerID}`}}
  );
  const { data, status } = resp;
  if (status == 200) {
    yield delay(2000);
    yield put(actions.getJobRequestListSuccess(data));
  } else {
    yield put(actions.getJobRequestListFailed());
  }
}

function* getCompany({content}){
  if (content){
     yield delay(500);
  const resp = yield call(
    api.postPagination,
    `v1/Companies`,
    1,
    10,
    content ? `contains(tolower(Name),tolower('${encodeURIComponent(content)}'))`: null,
    null
  );
  const { data, status } = resp;
  if (status == 200) {
    yield put(actions.getCompanyListSuccess(data));
  } else {
    yield put(actions.getCompanyListFailed());
  }
  }
 
}


function* getProfessionList({content}){
  if (content){
    yield delay(500);

  const resp = yield call(
    api.postPagination,
    `v1/KeyValues`,
    null,
    null,
    `TGroup eq ${KEY_VALUE.PROFESSION} and contains(tolower(TValue),tolower('${encodeURIComponent(content)}'))`,
    null
  );
  const { data, status } = resp;
  if (status == 200) {
    yield put(actions.getProfessionListSuccess(data));
  } else {
    yield put(actions.getProfessionListFailed());
  }
}
}


function* getSkillList({content}){

  if (content){
    yield delay(500);

  const resp = yield call(
    api.postPagination,
    `v1/KeyValues`,
    null,
    null,
    `TGroup eq ${KEY_VALUE.SKILL} and contains(tolower(TValue),tolower('${encodeURIComponent(content)}'))`,
    null
  );
  const { data, status } = resp;
  if (status == 200) {
    yield put(actions.getSkillListSuccess(data));
  } else {
    yield put(actions.getSkillListFailed());
  }
}
}

function* getLocationList(){
  const resp = yield call(
    api.postPagination,
    `v1/KeyValues`,
    null,
    null,
    `TGroup eq ${KEY_VALUE.LOCATION}`,
    null
  );
  const { data, status } = resp;
  if (status == 200) {
    yield put(actions.getLocationListSuccess(data));
  } else {
    yield put(actions.getLocationListFailed());
  }
}
// Individual exports for testing
export default function* jobRequestPageSaga() {
  // See example in containers/HomePage/saga.js
  yield takeLatest(types.GET_CONTENT, getJobRequestList);
  yield takeLatest(types.GET_COMPANY, getCompany);
  yield takeLatest(types.GET_LOCATION, getLocationList)
  yield takeLatest(types.GET_PROFESSION, getProfessionList)
  yield takeLatest(types.GET_SKILL, getSkillList)

}
