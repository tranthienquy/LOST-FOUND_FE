import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the jobRequestPage state domain
 */

const selectJobRequestPageDomain = state => state.jobRequestPage || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by JobRequestPage
 */

const makeSelectJobRequestPage = () =>
  createSelector(
    selectJobRequestPageDomain,
    substate => substate,
  );

export default makeSelectJobRequestPage;
export { selectJobRequestPageDomain };
