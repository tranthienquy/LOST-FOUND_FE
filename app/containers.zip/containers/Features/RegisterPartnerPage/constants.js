/*
 *
 * RegisterPartnerPage constants
 *
 */

export const DEFAULT_ACTION = 'app/RegisterPartnerPage/DEFAULT_ACTION';
export const REGISTER = 'app/RegisterPartnerPage/REGISTER';
export const REGISTER_SUCCESS = 'app/RegisterPartnerPage/REGISTER_SUCCESS';
export const REGISTER_FAILED = 'app/RegisterPartnerPage/REGISTER_FAILED';
