/*
 *
 * RegisterPartnerPage actions
 *
 */

import { DEFAULT_ACTION, REGISTER, REGISTER_FAILED, REGISTER_SUCCESS } from './constants';

export function defaultAction() {
  return {
    type: DEFAULT_ACTION,
  };
}

export const register = (value) => {
  return {
    type: REGISTER,
    value
  };
};
export const registerSuccess = data => {
  return {
    type: REGISTER_SUCCESS,
    payload: {
      data,
    },
  };
};
export const registerFailed = (error) => {
  return {
    type: REGISTER_FAILED,
    error
  };
};