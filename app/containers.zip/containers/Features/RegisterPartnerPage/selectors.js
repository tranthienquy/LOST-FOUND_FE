import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the registerPartnerPage state domain
 */

const selectRegisterPartnerPageDomain = state => state.registerPartnerPage || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by RegisterPartnerPage
 */

const makeSelectRegisterPartnerPage = () =>
  createSelector(
    selectRegisterPartnerPageDomain,
    substate => substate,
  );

export default makeSelectRegisterPartnerPage;
export { selectRegisterPartnerPageDomain };
