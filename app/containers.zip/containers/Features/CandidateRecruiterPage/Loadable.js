/**
 *
 * Asynchronously loads the component for CandidateRecruiterPage
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
