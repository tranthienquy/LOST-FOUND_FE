/*
 *
 * CandidateRecruiterPage constants
 *
 */

export const DEFAULT_ACTION = 'app/CandidateRecruiterPage/DEFAULT_ACTION';
export const END_OF_ACTION = 'app/CandidateRecruiterPage/END_OF_ACTION';

export const SHOW_STATUS_MODAL = 'app/CandidateRecruiterPage/SHOW_STATUS_MODAL';
export const SHOW_CV_MODAL = 'app/CandidateRecruiterPage/SHOW_CV_MODAL';
export const GET_CONTENT = 'app/CandidateRecruiterPage/GET_CONTENT';
export const GET_CONTENT_SUCCESS = 'app/CandidateRecruiterPage/GET_CONTENT_SUCCESS';
export const GET_CONTENT_FAILED = 'app/CandidateRecruiterPage/GET_CONTENT_FAILED';
export const PAGINATION = 'app/CandidateRecruiterPage/PAGINATION';
export const OPEN_PREVIEW_MODAL = 'app/CandidateRecruiterPage/OPEN_PREVIEW_MODAL';
