/*
 *
 * CandidateRecruitmentStatusModal constants
 *
 */

export const DEFAULT_ACTION =
  'app/CandidateRecruitmentStatusModal/DEFAULT_ACTION';
export const END_OF_ACTION =
  'app/CandidateRecruitmentStatusModal/END_OF_ACTION';
  export const LOAD_CONTENT = 'app/CandidateRecruitmentStatusModal/LOAD_CONTENT';
  export const LOAD_CONTENT_SUCCESS = 'app/CandidateRecruitmentStatusModal/LOAD_CONTENT_SUCCESS';
  export const LOAD_CONTENT_FAILED = 'app/CandidateRecruitmentStatusModal/LOAD_CONTENT_FAILED';
  
  
export const SUBMIT_CONTENT = 'app/CandidateRecruitmentStatusModal/SUBMIT_CONTENT';
export const SUBMIT_CONTENT_SUCCESS = 'app/CandidateRecruitmentStatusModal/SUBMIT_CONTENT_SUCCESS';
export const SUBMIT_CONTENT_FAILED = 'app/CandidateRecruitmentStatusModal/SUBMIT_CONTENT_FAILED';


export const GET_ACTION = 'app/CandidateRecruitmentStatusModal/GET_ACTION';
export const GET_ACTION_SUCCESS = 'app/CandidateRecruitmentStatusModal/GET_ACTION_SUCCESS';
export const GET_ACTION_FAILED = 'app/CandidateRecruitmentStatusModal/GET_ACTION_FAILED';


export const GET_RESULT = 'app/CandidateRecruitmentStatusModal/GET_RESULT';
export const GET_RESULT_SUCCESS = 'app/CandidateRecruitmentStatusModal/GET_RESULT_SUCCESS';
export const GET_RESULT_FAILED = 'app/CandidateRecruitmentStatusModal/GET_RESULT_FAILED';
export const CHANGE_ACTION_RESULT = 'app/CandidateRecruitmentStatusModal/CHANGE_ACTION_RESULT';
