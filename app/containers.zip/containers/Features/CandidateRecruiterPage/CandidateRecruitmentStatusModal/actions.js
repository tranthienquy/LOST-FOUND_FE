/*
 *
 * CandidateRecruitmentStatusModal actions
 *
 */

import { DEFAULT_ACTION, END_OF_ACTION,   LOAD_CONTENT,
  LOAD_CONTENT_FAILED,
  LOAD_CONTENT_SUCCESS,
  SUBMIT_CONTENT,
  SUBMIT_CONTENT_FAILED,
  SUBMIT_CONTENT_SUCCESS,
GET_ACTION,
GET_ACTION_FAILED,
GET_ACTION_SUCCESS,
GET_RESULT,
GET_RESULT_FAILED,GET_RESULT_SUCCESS, CHANGE_ACTION_RESULT  } from './constants';

export function defaultAction() {
  return {
    type: DEFAULT_ACTION,
  };
}
export const endOfAction = () => {
  return {
    type: END_OF_ACTION,
  };
};

export const loadContent = id => {
  return {
    type: LOAD_CONTENT,
    id,
  };
};
export const loadContentSuccess = data => {
  return {
    type: LOAD_CONTENT_SUCCESS,
    payload: {
      data,
    },
  };
};
export const loadContentFailed = error => {
  return {
    type: LOAD_CONTENT_FAILED,
    error,
  };
};

export const submitContent = value => {
  return {
    type: SUBMIT_CONTENT,
    value,
  };
};
export const submitContentSuccess = data => {
  return {
    type: SUBMIT_CONTENT_SUCCESS,
    payload: {
      data,
    },
  };
};
export const submitContentFailed = error => {
  return {
    type: SUBMIT_CONTENT_FAILED,
    error,
  };
};
export const getActionList = () => {
  return {
    type: GET_ACTION,
  };
};
export const getActionListSuccess = data => {
  return {
    type: GET_ACTION_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getActionListFailed = () => {
  return {
    type: GET_ACTION_FAILED,
  };
};
export const getResultList = () => {
  return {
    type: GET_RESULT,
  };
};
export const getResultListSuccess = data => {
  return {
    type: GET_RESULT_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getResultListFailed = () => {
  return {
    type: GET_RESULT_FAILED,
  };
};
export const changeActionResult = (value, id) => {
  return {
    type: CHANGE_ACTION_RESULT,
    value, id
  };
};