/*
 *
 * CandidateRecruitmentStatusModal reducer
 *
 */
import produce from 'immer';
import * as types from './constants';

export const initialState = {
  id: '',
  content: {},
  loading: {
    getContent: true,
    submit: false,
  },
  actionList: [],
  resultList: [],
  resultFilterList: {},
};

/* eslint-disable default-case, no-param-reassign */
const candidateRecruitmentStatusModalReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case types.DEFAULT_ACTION:
        break;
      case types.END_OF_ACTION:
        for (var element in draft) {
          draft[element] = initialState[element];
        }
        break;

      case types.LOAD_CONTENT:
        draft.loading.getContent = true;
        draft.id = action.id;
        break;
      case types.LOAD_CONTENT_SUCCESS:
        draft.loading.getContent = false;
        if (action.payload.data) {
          draft.content = action.payload.data;
        }
        break;
      case types.SUBMIT_CONTENT:
        draft.loading.submit = true;
        break;
      case types.SUBMIT_CONTENT_SUCCESS:
        draft.loading.submit = false;

        break;
      case types.SUBMIT_CONTENT_FAILED:
        draft.loading.submit = false;

      case types.GET_ACTION:
        draft.actionList = [];
        break;
      case types.GET_ACTION_SUCCESS:
        draft.actionList = action.payload.data.value;
        break;
      case types.GET_ACTION_FAILED:
        break;

      case types.GET_RESULT:
        draft.resultList = [];
        break;
      case types.GET_RESULT_SUCCESS:
        draft.resultList = action.payload.data.value;
        break;
      case types.GET_RESULT_FAILED:
        break;
        case types.CHANGE_ACTION_RESULT:
          draft.resultFilterList = {...draft.resultFilterList, [action.id]: []}
          draft.resultFilterList[action.id]= draft.resultList.filter(item=>item.Relation==action.value);
break;
    }
  });

export default candidateRecruitmentStatusModalReducer;
