import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the candidateRecruitmentStatusModal state domain
 */

const selectCandidateRecruitmentStatusModalDomain = state =>
  state.candidateRecruitmentStatusModal || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by CandidateRecruitmentStatusModal
 */

const makeSelectCandidateRecruitmentStatusModal = () =>
  createSelector(
    selectCandidateRecruitmentStatusModalDomain,
    substate => substate,
  );

export default makeSelectCandidateRecruitmentStatusModal;
export { selectCandidateRecruitmentStatusModalDomain };
