/**
 *
 * CandidateRecruitmentStatusModal
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import makeSelectCandidateRecruitmentStatusModal from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import * as actions from './actions';
import './styles.scss';

import {
  Button,
  Card,
  Typography,
  Tag,
  Modal,
  Form,
  Input,
  Select,
  Skeleton,
  Radio,
  DatePicker,
} from 'antd';

import {
  Paper,
  TableContainer,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  LinearProgress,
} from '@mui/material';
import { withRouter } from 'react-router-dom';

class CandidateRecruitmentStatusModal extends React.Component {
  constructor(props) {
    super(props);
    this.state = {

    };
  }
  componentWillUnmount() {
    this.props.onEndOfAction();
  }
  componentWillMount=async ()=> {
    // if (this.props.value) 
    console.log('ss');
    
    // this.getValue(this.props.value )
   
    this.props.onGetActionList()
    this.props.onGetResultList()
  }


  componentWillReceiveProps= async (nextProps)=>{
console.log(this.props, nextProps);
    if (nextProps.value !== this.props.value) {
      console.log(nextProps.value);
          this.formRef.current.setFieldsValue({
            ListInfoStatusApplicants: nextProps.value.ListInforApplicantResponses
    })
    }
    if(nextProps.candidateRecruitmentStatusModal.resultList !== this.props.candidateRecruitmentStatusModal.resultList){
      console.log(nextProps.candidateRecruitmentStatusModal.resultList);
      this.props.value.ListInforApplicantResponses.forEach((item,index)=>{
        this.onChangeActionResultValue(item.Action, index)
      })
    }
  }
  onChangeActionResultValue = (value,id)=>{

    this.props.onChangeActionResult(value, id);
    //    this.formRef.current.setFieldsValue({
    //   requests:[...requests, requests[requests.length-1]]
    // })
  }

  formRef = React.createRef();

  onSubmit = value => {
    console.log(value);
    this.props.onSubmitContent({item:this.props.value,value});
  };
  onSubmitFailed = errorInfo => {};
  
  render() {
    const {actionList, resultList, resultFilterList, loading} = this.props.candidateRecruitmentStatusModal;
    return (
      <div className=" d-flex flex-column pt-5">
        <Form
          name="basic"
          onFinish={this.onSubmit}
          autoComplete="off"
          layout="vertical"
          initialValues={{ListInfoStatusApplicants:this.props.value.ListInforApplicantResponses,Status: this.props.value.Info}}
          onFinishFailed={this.onSubmitFailed}
          className="ant-general-form"
          ref={this.formRef}
        >
         

          {/* <Form.List name="users"> */}

          <TableContainer component={Paper}>
            <Table sx={{ minWidth: 650 }} aria-label="simple table">
              <TableHead>
                <TableRow>
                  <TableCell>Hành động</TableCell>
                  <TableCell>Kết quả</TableCell>
                  <TableCell>Ghi chú</TableCell>
                  <TableCell>Ngày cập nhật</TableCell>
                 
                </TableRow>
              </TableHead>
              <TableBody>
                <Form.List name="ListInfoStatusApplicants">
                  {(fields, { add, remove }) => (
                    <>
                      {fields.map(({ key, name, ...restField }) => (
                        <TableRow
                          sx={{
                            '&:last-child td, &:last-child th': { border: 0 },
                          }}
                        >
                          <TableCell component="th" scope="row">
                          <Form.Item
                              {...restField}
                              name={[name, 'Action']}
                              rules={[
                                {
                                  required: true,
                                  message: 'Vui lòng chọn Hành động',
                                },
                              ]}
                            >
                          <Select
                            suffixIcon={<i className="icon-Caret-down h3" />}
                            onChange={(value)=>this.onChangeActionResultValue(value,key)}
                          >
                               {actionList.map(item => (
                        <Select.Option key={`options-action-${item.TKey}`} value={item.TKey}>
                          {item.TValue}
                        </Select.Option>
                      ))}
                          </Select>

                          </Form.Item>
                          </TableCell>
                          <TableCell >
                          <Form.Item
                              {...restField}
                              name={[name, 'Result']}
                              rules={[
                                {
                                  required: true,
                                  message: 'Vui lòng chọn Kết quả',
                                },
                              ]}
                            >
                          <Select
                            suffixIcon={<i className="icon-Caret-down h3" />}
                          >
                               {resultFilterList[key] && resultFilterList[key].map(item => (
                        <Select.Option key={`options-action-${item.TKey}`} value={item.TKey}>
                          {item.TValue}
                        </Select.Option>
                      ))}
                            
                          </Select>

                          </Form.Item>
                          </TableCell>
                          <TableCell >
                          <Form.Item
                              {...restField}
                              name={[name, 'Note']}
                            >
                        <Input/>
                          </Form.Item>
                          </TableCell>
                          <TableCell >
                          <Form.Item
                              {...restField}
                              name={[name, 'UpdateAt']}
                             
                            >
                        <Input disabled bordered={false} />
                          </Form.Item>
                      

                          </TableCell>
                        </TableRow>
                      ))}
                      <Form.Item className='ml-3 mt-2'>
                        <Button type="dashed" onClick={() => add()} block>
                          Thêm dòng
                        </Button>
                      </Form.Item>
                    </>
                  )}
                </Form.List>
              </TableBody>
            </Table>
          </TableContainer>
          <div className='mt-1 d-flex flex-row align-items-center'>
        <Typography className='mr-3'> Kết luận</Typography> 
          <Form.Item className="mb-0" name={'Status'}>
          <Radio.Group>
      <Radio value={'Accept'}>Đạt</Radio>
      <Radio value={'Not_accept'}>Không Đạt</Radio>
      <Radio value={'Cancel'}>Hủy</Radio>
    </Radio.Group>
            </Form.Item></div>
          <Form.Item className="mb-0">
            <Button
              size="large"
              type="primary"
              htmlType="submit"
              className="text-center w-100 mt-3"
            >
              <b className="w-100 text-center">LƯU</b>
            </Button>
          </Form.Item>
          {loading.submit ?  <LinearProgress color='success' />:""}
        </Form>
      </div>
    );
  }
}

CandidateRecruitmentStatusModal.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  candidateRecruitmentStatusModal: makeSelectCandidateRecruitmentStatusModal(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    onEndOfAction: () => {
      dispatch(actions.endOfAction());
    },
    onLoadContent: id => {
      dispatch(actions.loadContent(id));
    },
    onSubmitContent: content => {
      dispatch(actions.submitContent(content));
    },
    onGetActionList: () => {
      dispatch(actions.getActionList());
    },
    onGetResultList: () => {
      dispatch(actions.getResultList());
    },
    onChangeActionResult: (value, id) => {
      dispatch(actions.changeActionResult(value, id));
    },
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

const withReducer = injectReducer({
  key: 'candidateRecruitmentStatusModal',
  reducer,
});
const withSaga = injectSaga({ key: 'candidateRecruitmentStatusModal', saga });
export default compose(
  withConnect,
  withReducer,
  withSaga,
  withRouter
)(CandidateRecruitmentStatusModal);
