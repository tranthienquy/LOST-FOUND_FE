/**
 *
 * Asynchronously loads the component for CandidateRecruitmentStatusModal
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
