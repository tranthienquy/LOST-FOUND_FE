/*
 *
 * CandidateRecruiterPage reducer
 *
 */
import produce from 'immer';
import * as types from './constants';

export const initialState = {
  showStatusModal: false,
  showCVModal: false,
  cv: null,
  statusItem: null,
  loading: false,
  candidateList: [],
  current: 1,
  pageSize: 10,
  total: 0,

  previewModal: false,
  previewItem: null,
};

/* eslint-disable default-case, no-param-reassign */
const candidateRecruiterPageReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case types.DEFAULT_ACTION:
        break;
      case types.END_OF_ACTION:
        for (var element in draft) {
          draft[element] = initialState[element];
        }
        break;
        case types.SHOW_STATUS_MODAL:
        draft.showStatusModal = action.isShowing;  
        draft.statusItem = action.item;  
        break;
        case types.SHOW_CV_MODAL:
        draft.showCVModal = action.isShowing;  
        draft.statusId = action.item;  
        break;
        case types.GET_CONTENT:
          draft.loading = true;
          draft.candidateList = [];
          break;
        case types.GET_CONTENT_SUCCESS:
          draft.loading = false;
          draft.total = action.payload.data.total;
          draft.candidateList = action.payload.data.results;
          break;
        case types.GET_CONTENT_FAILED:
          draft.loading = false;
          break;
          case types.OPEN_PREVIEW_MODAL:
            draft.previewModal = action.isShowing
            draft.previewItem = action.item
            break;
            case types.PAGINATION:
              draft.current = action.current;
              draft.pageSize = action.pageSize;
              break;
    }
  });

export default candidateRecruiterPageReducer;
