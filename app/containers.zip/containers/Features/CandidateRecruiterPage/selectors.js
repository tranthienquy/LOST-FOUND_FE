import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the candidateRecruiterPage state domain
 */

const selectCandidateRecruiterPageDomain = state =>
  state.candidateRecruiterPage || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by CandidateRecruiterPage
 */

const makeSelectCandidateRecruiterPage = () =>
  createSelector(
    selectCandidateRecruiterPageDomain,
    substate => substate,
  );

export default makeSelectCandidateRecruiterPage;
export { selectCandidateRecruiterPageDomain };
