/*
 *
 * CompanyDetailPage reducer
 *
 */
import produce from 'immer';
import {
  DEFAULT_ACTION,
  END_OF_ACTION,
  LOAD_CONTENT,
  LOAD_CONTENT_SUCCESS,
  GET_CONTENT, GET_CONTENT_SUCCESS, GET_CONTENT_FAILED
} from './constants';

export const initialState = {
  id: '',
  content: {},
  jobList: [],
  total: 0,
  current: 0,
  pageSize: 4,
  loading: {
    getContent: false,
    getJobList: true,
  },
};

/* eslint-disable default-case, no-param-reassign */
const companyDetailPageReducer = (state = initialState, action) =>
  produce(state,  draft  => {
    switch (action.type) {
      case DEFAULT_ACTION:
        break;
      case END_OF_ACTION:
        for (var element in draft) {
          draft[element] = initialState[element];
        }
        break;
      case LOAD_CONTENT:
        draft.loading.getContent = true;
        draft.id = action.id;
        break;
      case LOAD_CONTENT_SUCCESS:
        draft.loading.getContent = false;
        if (action.payload.data) {
          draft.content = action.payload.data.value[0];
        }
        break;

        case GET_CONTENT:
          draft.loading.getJobList = true;
          draft.current = draft.current+1;
          break;
        case GET_CONTENT_SUCCESS:
          draft.loading.getJobList = false;
          draft.total = action.payload.data['@odata.count'];
          draft.jobList.push( ...action.payload.data.value);
          break;
        case GET_CONTENT_FAILED:
          draft.loading.getJobList = false;
          break;
    }
  });

export default companyDetailPageReducer;
