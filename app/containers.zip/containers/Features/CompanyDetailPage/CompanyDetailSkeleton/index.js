/**
 *
 * CompanyDetailSkeleton
 *
 */

import React from 'react';
// import PropTypes from 'prop-types';
// import styled from 'styled-components';

class CompanyDetailSkeleton extends React.Component {
  render(){
     return <div />;
} 
  }


CompanyDetailSkeleton.propTypes = {};

export default CompanyDetailSkeleton;
