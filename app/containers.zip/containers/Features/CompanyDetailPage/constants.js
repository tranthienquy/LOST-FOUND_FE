/*
 *
 * CompanyDetailPage constants
 *
 */

export const DEFAULT_ACTION = 'app/CompanyDetailPage/DEFAULT_ACTION';
export const END_OF_ACTION = 'app/CompanyDetailPage/END_OF_ACTION';
export const LOAD_CONTENT = 'app/CompanyDetailPage/LOAD_CONTENT';
export const LOAD_CONTENT_SUCCESS = 'app/CompanyDetailPage/LOAD_CONTENT_SUCCESS';
export const LOAD_CONTENT_FAILED = 'app/CompanyDetailPage/LOAD_CONTENT_FAILED';


export const GET_CONTENT = 'app/CompanyDetailPage/GET_CONTENT';
export const GET_CONTENT_SUCCESS = 'app/CompanyDetailPage/GET_CONTENT_SUCCESS';
export const GET_CONTENT_FAILED = 'app/CompanyDetailPage/GET_CONTENT_FAILED';