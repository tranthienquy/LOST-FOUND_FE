import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the companyDetailPage state domain
 */

const selectCompanyDetailPageDomain = state =>
  state.companyDetailPage || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by CompanyDetailPage
 */

const makeSelectCompanyDetailPage = () =>
  createSelector(
    selectCompanyDetailPageDomain,
    substate => substate,
  );

export default makeSelectCompanyDetailPage;
export { selectCompanyDetailPageDomain };
