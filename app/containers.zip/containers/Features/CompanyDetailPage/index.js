/**
 *
 * CompanyDetailPage
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import makeSelectCompanyDetailPage from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import './styles.scss';

import { withRouter } from 'react-router-dom';
import { Button, Card, Skeleton, Typography } from 'antd';
import { Splide, SplideSlide } from '@splidejs/react-splide';
import { Helmet } from 'react-helmet';
import * as actions from './actions';
import JobListComponent from '../../../components/JobListComponent';
import { LinearProgress } from '@mui/material';
import AuthContext from '../../../utils/auth';

class CompanyDetailPage extends React.Component {
  componentWillMount() {
    const { id } = this.props.match.params;
    if (id) {
      this.props.onLoadContent(id);
      this.props.onGetJobList();
    }
  }
  componentWillReceiveProps(nextProps) {
    const { id } = nextProps.match.params;
    if (nextProps.match.params !== this.props.match.params) {
      if (id) {
        this.props.onLoadContent(id);
      }
    }
  }
  componentWillUnmount() {
    this.props.onEndOfAction();
  }
  render() {
    const { content, loading , jobList, total} = this.props.companyDetailPage;

    return (
      <div className="company-detail-container d-flex flex-column pt-5">
        <Helmet>
          <title>Công ty</title>
        </Helmet>

        <Typography.Text
          className="link-text-on-click"
          type="secondary"
          onClick={() => this.props.history.goBack()}
        >
          <i className="icon-Caret-left" /> Quay lại
        </Typography.Text>
        {loading.getContent ? (
          <>
            {' '}
            <Skeleton active />
            <Skeleton active />
            <Skeleton active />
            <Skeleton active />{' '}
          </>
        ) : (
          <React.Fragment>
            {' '}
            <div className="d-flex flex-row mt-2">
              <img className="logo-company"src={content.Avatar ? (content.Avatar.startsWith('http')? content.Avatar: `${this.context.prefixLink}/${content.Avatar}`): require('../../../images/logo/logo-shinyama-grayscale.png') } />
              <div className="ml-3">
                <Typography className="font-weight-bold h4">
                  {content.Name}
                </Typography>
                <Typography
                  style={{ fontSize: '16px' }}
                  className="mt-2 d-flex align-items-center"
                >
                  <i
                    style={{ fontSize: '25px' }}
                    className=" text-app-primary mr-2 icon-Location-outline"
                  />
                  {content.Location}
                </Typography>
                <Typography
                  style={{ fontSize: '16px' }}
                  className="mt-2 d-flex align-items-center"
                >
                  <i
                    style={{ fontSize: '25px' }}
                    className=" text-app-primary mr-2 icon-Contacts-outline"
                  />
                  {content.Size} người
                </Typography>
              </div>
            </div>
            {content.Slide &&
                JSON.parse(content.Slide).length>0 &&
            <Splide
              aria-label="My Favorite Images"
              className="splide-banner mt-3"
              options={{
                perMove: 1,
                perPage: 1,
                autoplay: true,
                autoHeight: true,
                gap: '5rem',
                padding: '0rem',
              }}
            >
              {content.Slide &&
                JSON.parse(content.Slide).map(item => (
                  <SplideSlide>
                    <div className="splide-banner-item" >
                      <img src={item} width="100%" height={'400px'} style={{objectFit:"cover", borderRadius:10}}/>
                      </div>
                  </SplideSlide>
                ))}
            </Splide>}
            <Card
              size="small"
              className="card-description mt-4"
              title={
                <Typography
                  style={{ fontSize: '24px' }}
                  className=" text-app-primary font-weight-bold mt-2 d-flex align-items-center"
                >
                  <i
                    style={{ fontSize: '29px' }}
                    className=" mr-2 icon-History-outline"
                  />
                  LỊCH SỬ
                </Typography>
              }
            >
              <Typography.Text style={{whiteSpace:'pre-wrap'}}>{content.History}</Typography.Text>
            </Card>
            <Card
              size="small"
              className="card-description mt-4"
              title={
                <Typography
                  style={{ fontSize: '24px' }}
                  className=" text-app-primary font-weight-bold mt-2 d-flex align-items-center"
                >
                  <i
                    style={{ fontSize: '29px' }}
                    className=" mr-2 icon-Book-open-outline"
                  />
                  TẦM NHÌN
                </Typography>
              }
            >
              <Typography.Text style={{whiteSpace:'pre-wrap'}}>{content.Vision}</Typography.Text>
            </Card>
            <Card
              size="small"
              className="card-description mt-4"
              title={
                <Typography
                  style={{ fontSize: '24px' }}
                  className=" text-app-primary font-weight-bold mt-2 d-flex align-items-center"
                >
                  <i
                    style={{ fontSize: '29px' }}
                    className=" mr-2 icon-Play-outline"
                  />
                  CHIẾN LƯỢC
                </Typography>
              }
            >
              <Typography.Text style={{whiteSpace:'pre-wrap'}}>{content.Strategy}</Typography.Text>
            </Card>
            <Typography.Text className='mt-5 h4 font-weight-bold text-center text-app-primary'>  Công việc mới nhất của công ty </Typography.Text>
            <JobListComponent loading={false} value={jobList} />
            {loading.getJobList && <LinearProgress color='success' />}
            {total > jobList.length &&
            <Button 
            
            onClick={()=> this.props.onGetJobList()}
            className='link-text-on-click mt-5 text-center font-weight-bold text-app-primary d-flex align-items-center justify-content-center cursor-pointer'>Xem thêm <i className='icon-Caret-down'></i>  </Button>
            }
            </React.Fragment> 
        )}
      </div>
    );
  }
}

CompanyDetailPage.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  companyDetailPage: makeSelectCompanyDetailPage(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    onLoadContent: id => {
      dispatch(actions.loadContent(id));
    },
    onEndOfAction: () => {
      dispatch(actions.endOfAction());
    },
    onGetJobList: content => {
      dispatch(actions.getJobList(content));
    },
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);
const withReducer = injectReducer({ key: 'companyDetailPage', reducer });
const withSaga = injectSaga({ key: 'companyDetailPage', saga });
CompanyDetailPage.contextType = AuthContext;

export default compose(
  withConnect,
  withReducer,
  withSaga,
  withRouter,
)(CompanyDetailPage);
