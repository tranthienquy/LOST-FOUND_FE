/*
 *
 * CompanyDetailPage actions
 *
 */

import { DEFAULT_ACTION,END_OF_ACTION,LOAD_CONTENT, LOAD_CONTENT_FAILED, LOAD_CONTENT_SUCCESS,
  GET_CONTENT, GET_CONTENT_SUCCESS, GET_CONTENT_FAILED } from './constants';

export function defaultAction() {
  return {
    type: DEFAULT_ACTION,
  };
}
export const endOfAction = () => {
  return {
    type: END_OF_ACTION,
  };
};

export const loadContent = id => {
  return {
    type: LOAD_CONTENT,
    id,
  };
};
export const loadContentSuccess = data => {
  return {
    type: LOAD_CONTENT_SUCCESS,
    payload: {
      data,
    },
  };
};
export const loadContentFailed = error => {
  return {
    type: LOAD_CONTENT_FAILED,
     error
  };
};

export const getJobList = (content = null) => {
  return {
    type: GET_CONTENT,
    content,
  };
};
export const getJobListSuccess = data => {
  return {
    type: GET_CONTENT_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getJobListFailed = () => {
  return {
    type: GET_CONTENT_FAILED,
  };
};