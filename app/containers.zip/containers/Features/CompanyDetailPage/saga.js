import { take, call, put, select, takeLatest, delay } from 'redux-saga/effects';
import * as types from './constants';
import * as actions from './actions';
import * as api from 'utils/api';

// Individual exports for testing
function* loadContent({ id }) {
  const resp = yield call(
    api.get,
    `v1/Companies(${id})`,
  );
  const { data, status } = resp;

  if (status == 200 ) {
    yield delay(2000);
    yield put(actions.loadContentSuccess(data));
  } else {
    yield put(actions.loadContentFailed());
  }

}

function* getJobList({content}) {
  const { current, pageSize, id } = yield select(state => state.companyDetailPage);
  let filter = '' ;
    filter=( id ? `CompanyID eq ${id}`:'')
  const resp = yield call(
    api.postPagination,
    `v1/Jobs`,
    current,
    pageSize,
    filter,
    { Company: { $select: 'Id,Name,Avatar' } ,
    CreateByNavigation: { $select: 'Id' } 
  },
  );
  const { data, status } = resp;
  if (status == 200) {
    yield delay(300);
    yield put(actions.getJobListSuccess(data));
  } else {
    yield put(actions.getJobListFailed());
  }
}
// Individual exports for testing
export default function* companyDetailPageSaga() {
  // See example in containers/HomePage/saga.js
  yield takeLatest(types.LOAD_CONTENT, loadContent);
  yield takeLatest(types.GET_CONTENT, getJobList);


}
