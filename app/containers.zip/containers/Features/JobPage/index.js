/**
 *
 * JobPage
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import makeSelectJobPage from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import './styles.scss';
import * as actions from './actions';
import { Form, Input, Button, Select, Typography, Pagination } from 'antd';
import { Helmet } from 'react-helmet';
import JobListComponent from '../../../components/JobListComponent';
import { getValidRole } from '../../../utils/permissionUtil';
import { USER_ROLE } from '../../../utils/constants';
import AuthContext from '../../../utils/auth';
import { Link } from 'react-router-dom';
import * as api from 'utils/api';
import { KEY_VALUE } from '../../../utils/api/constants';

class JobPage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      valueSearch: null, 
      CompanyID:null,
      skillSuggestList: [],
      skillSearch:'',
      professionSuggestList: [],
      professionSearch:''
    };
  }
  formRef = React.createRef();

  onSubmitSearch = value => {
    this.setState({ valueSearch: value });
    this.props.onPagination(1, this.props.jobPage.pageSize);
    this.props.onGetJobList({CompanyID: this.state.CompanyID,...value});
  };
  componentWillMount =async()=> {
    api.postPagination( `v1/KeyValues`, 1, 4, `TGroup eq ${KEY_VALUE.SKILL} `, null ).then(res=>{
      this.setState ({skillSuggestList: res.data.value})
    })
    api.postPagination( `v1/KeyValues`, 1, 4, `TGroup eq ${KEY_VALUE.PROFESSION} `, null ).then(res=>{
      this.setState ({professionSuggestList: res.data.value})
    })
    if (this.context.user){
     await  this.setState({CompanyID:this.context.user.CompanyId})
    }
    await this.props.onGetJobList({CompanyID: this.state.CompanyID});
    await this.props.onGetLocationList();

  }

  onChangePagination = (page, pageSize) => {
    this.props.onPagination(page, pageSize);
    this.props.onGetJobList({CompanyID: this.state.CompanyID, ...this.state.valueSearch});
  };
  onChangePageSize = value => {
    this.onChangePagination(this.props.jobPage.current, value);
  };

  componentWillUnmount() {
    this.props.onEndOfAction();
  }

  searchCompany = value => {
    this.props.onGetCompanyList(value);
  };
  searchProfession = value => {
    this.setState({professionSearch:value})
    this.props.onGetProfessionList(value);
  };
  searchSkill = value => {
    this.setState({skillSearch:value})
    this.props.onGetSkillList(value);
  };

  onFillSuggestSkill = value =>{
    this.formRef.current.setFieldsValue({
      Skills: [value.TKey]
    })
  }
  onFillSuggestProfession = value =>{
    this.formRef.current.setFieldsValue({
      Professions: value.TKey
    })
  }





  render() {
    const {
      jobList,
      loading,
      current,
      pageSize,
      total,
      companyList,
      companyLoading,
      locationList,
      skillList,
      professionLoading,
      professionList,
      skillLoading,
      
    } = this.props.jobPage;
    const {skillSuggestList, skillSearch, professionSearch, professionSuggestList} = this.state;
    console.log(skillSearch);
    return (
      <div className="job-container">
        <Helmet>
          <title>Việc làm</title>
        </Helmet>
        <Form name="basic" onFinish={this.onSubmitSearch} autoComplete="off"
         ref={this.formRef} 
        >
          <div className="row">
            <div className="col-xs-12 col-sm-12 col-md-6 col-lg-4 pl-4 pr-4 mt-2">
              <div className="ant-form-item-control-input-content select-input">
                <span className="ant-input-affix-wrapper d-flex align-items-center">
                  <span className="ant-input-prefix">
                    <i className="icon-Box-outline h5 feature-icon" />
                  </span>
                  <Form.Item name="Professions">
                    <Select
                      className="w-100"
                      placeholder="Ngành nghề"
                      bordered={false}
                      suffixIcon={''}
                      showSearch
                      onSearch={this.searchProfession}
                      filterOption={false}
                      loading={professionLoading}
                      allowClear={true}
                      notFoundContent={''}
                   
                    >
                      {professionList &&
                        professionList.map(item => (
                          <Select.Option
                            value={item.TKey}
                            key={`options-profession-${item.Id}`}
                          >
                           
                            {item.TValue}
                          </Select.Option>
                        ))}
                         {professionList.length==0 && !professionLoading && !professionSearch && professionSuggestList &&
                       <>
                        <Select.Option disabled><i className='text-app-primary'>Gợi ý dành cho bạn</i></Select.Option>
                     {  professionSuggestList.map(item => (
                          <Select.Option
                            value={item.TKey}
                            key={`options-company-${item.TKey}`}
                          >
                          
                            {item.TValue}
                          </Select.Option>
                        ))}
                        </>
                        }
                      {professionLoading && (
                        <Select.Option disabled>Đang tải...</Select.Option>
                      )}
                    </Select>
                  </Form.Item>

                </span>

                {professionSuggestList && professionSuggestList.map(el => 
                       <span onClick={()=>this.onFillSuggestProfession(el)} className="link-text-on-click small-size-hint mr-2 ">
                       {el.TValue}
                     </span>
                      )}
              </div>
            </div>

         
            <div className="col-xs-12 col-sm-12 col-md-6 col-lg-4 pl-4 pr-4 mt-2">
              <div className="ant-form-item-control-input-content select-input">
                <span className="ant-input-affix-wrapper d-flex align-items-center search-field">
                  <span className="ant-input-prefix">
                    <i className="icon-Settings-outline h5 feature-icon" />
                  </span>
                  <Form.Item name="Skills">
                    <Select
                      className="w-100"
                      placeholder="Kỹ năng"
                      bordered={false}
                      suffixIcon={''}
                      showSearch
                      onSearch={this.searchSkill}
                      filterOption={false}
                      loading={skillLoading}
                      allowClear={true}
                      notFoundContent={''}
                      mode="multiple"
                    >
                      {skillList &&
                        skillList.map(item => (
                          <Select.Option
                            value={item.TKey}
                            key={`options-company-${item.TKey}`}
                          >
                          
                            {item.TValue}
                          </Select.Option>
                        ))}
                      {skillList.length==0 && !skillLoading && !skillSearch && skillSuggestList &&
                       <>
                        <Select.Option disabled><i className='text-app-primary'>Gợi ý dành cho bạn</i></Select.Option>
                     {  skillSuggestList.map(item => (
                          <Select.Option
                            value={item.TKey}
                            key={`options-company-${item.TKey}`}
                          >
                          
                            {item.TValue}
                          </Select.Option>
                        ))}
                        </>
                        }
                      {skillLoading && (
                        <Select.Option disabled>Đang tải...</Select.Option>
                      )}
                    </Select>
                  </Form.Item>

                </span>
                    {skillSuggestList && skillSuggestList.map(el => 
                       <span onClick={()=>this.onFillSuggestSkill(el)} className="link-text-on-click small-size-hint mr-2 ">
                       {el.TValue}
                     </span>
                      )}
              </div>
            </div>
            <div className="col-xs-12 col-sm-12 col-md-6 col-lg-4 pl-4 pr-4 mt-2">
              <div className="ant-form-item-control-input-content select-input">
                <span className="ant-input-affix-wrapper d-flex align-items-center search-field">
                  <span className="ant-input-prefix">
                    <i className="icon-Cursor-outline h5 feature-icon" />
                  </span>
                  <Form.Item name="City">
                    <Select
                      className="w-100"
                      placeholder="Địa điểm"
                      bordered={false}
                      suffixIcon={<i className="icon-Caret-down h3" />}
                      allowClear={true}
                      filterOption={(input, option) =>
                        option.children
                          .toLowerCase()
                          .includes(input.toLowerCase())
                      }
                      showSearch
                      mode="multiple"
                      maxTagCount='responsive'
                    >
                      {locationList.map(item => (
                        <Select.Option key={`options-location-${item.TKey}`} value={item.TKey}>
                          {item.TValue}
                        </Select.Option>
                      ))}
                
                    </Select>
                  </Form.Item>
                </span>
              </div>
            </div>
            {!getValidRole(this.context.user, [USER_ROLE.RECRUITER]) &&

<div className="col-xs-12 col-sm-12 col-md-6 col-lg-4 pl-4 pr-4 mt-2">
<div className="ant-form-item-control-input-content select-input">
  <span className="ant-input-affix-wrapper d-flex align-items-center">
    <span className="ant-input-prefix">
      <i className="icon-Home-outline h5 feature-icon" />
    </span>
    <Form.Item name="CompanyID">
      <Select
        className="w-100"
        placeholder="Tên công ty"
        bordered={false}
        suffixIcon={''}
        showSearch
        onSearch={this.searchCompany}
        filterOption={false}
        loading={companyLoading}
        allowClear={true}
        notFoundContent={''}
        disabled={getValidRole(this.context.user, [USER_ROLE.RECRUITER])}
      >
        {companyList &&
          companyList.map(item => (
            <Select.Option
              value={item.Id}
              key={`options-company-${item.Id}`}
            >
              <img
                src={item.Avatar ? (item.Avatar.startsWith('http')? item.Avatar: `${this.context.prefixLink}/${item.Avatar}`): require('../../../images/logo/logo-shinyama-grayscale.png')  }
                className="mr-2"
                style={{
                  width: '30px',
                  height: '30px',
                  objectFit: 'contain',
                }}
              />
              {item.Name}
            </Select.Option>
          ))}
        {companyLoading && (
          <Select.Option disabled>Đang tải...</Select.Option>
        )}
      </Select>
    </Form.Item>
  </span>
</div>
</div>
            }
          

            <div className="col-xs-12 col-sm-12 col-md-6 col-lg-4 pl-4 pr-4 mt-2">
              <Form.Item name="Title" initialValue={''}>
                <Input
                  placeholder="Tên công việc"
                  prefix={
                    <i className="icon-Document-outline h5 feature-icon" />
                  }
                />
              </Form.Item>
            </div>
            <div className="col-xs-12 col-sm-12 col-md-6 col-lg-4 pl-4 pr-4 mt-2">
              <Form.Item>
                <Button
                  type="primary"
                  htmlType="submit"
                  className="w-100 button-submit"
                >
                  <span className="w-100 text-center d-flex justify-content-center">
                    {' '}
                    <i className="icon-Search mr-1" /> TÌM KIẾM
                  </span>
                </Button>
              </Form.Item>
            </div>
          </div>
        </Form>
        <div />
        <div className='d-flex justify-content-end mr-2 mt-1'>{getValidRole(this.context.user, [USER_ROLE.RECRUITER]) && 
        <Link to={'/job-form/add'}>
        <Button
        
        >+ Tạo mới công việc</Button></Link>}</div>
        <JobListComponent loading={loading} value={jobList} />
        <div className="pagination-foot w-100 mt-5 d-flex flex-row flex-wrap justify-content-between">
          <div className="d-flex flex-row align-items-center mb-2">
            <Typography className="mr-1">Kết quả mỗi trang</Typography>
            <Select
              className="select-number-page"
              value={pageSize}
              onChange={this.onChangePageSize}
              suffixIcon={
                <i className="icon-Caret-down h3 text-app-primary pr-3" />
              }
            >
              <Option value="10">10</Option>
              <Option value="20">20</Option>
              <Option value="30">30</Option>
              <Option value="50">50</Option>
              <Option value="100">100</Option>
            </Select>
          </div>

          <Pagination
            current={current}
            total={total}
            pageSize={pageSize}
            showSizeChanger={false}
            onChange={this.onChangePagination}
            showTotal={(total, range) =>
              `Hiển thị ${range[0]}-${range[1]} của ${total}`
            }
          />
        </div>
      </div>
    );
  }
}

JobPage.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  jobPage: makeSelectJobPage(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    onEndOfAction: () => {
      dispatch(actions.endOfAction());
    },
    onGetJobList: content => {
      dispatch(actions.getJobList(content));
    },
    onGetCompanyList: content => {
      dispatch(actions.getCompanyList(content));
    },
    onGetKeyValueList: name => {
      dispatch(actions.getKeyValueList(name));
    },
    onPagination: (current, pageSize) => {
      dispatch(actions.pagination(current, pageSize));
    },
    onGetLocationList: () => {
      dispatch(actions.getLocationList());
    },
    onGetProfessionList: content => {
      dispatch(actions.getProfessionList(content));
    },
    onGetSkillList: content => {
      dispatch(actions.getSkillList(content));
    },
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);
JobPage.contextType = AuthContext;
const withReducer = injectReducer({ key: 'jobPage', reducer });
const withSaga = injectSaga({ key: 'jobPage', saga });
export default compose(
  withConnect,
  withReducer,
  withSaga,
)(JobPage);
