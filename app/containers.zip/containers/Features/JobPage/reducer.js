/*
 *
 * JobPage reducer
 *
 */
import produce from 'immer';
import { QUERY_TYPE } from '../../../utils/api/constants';
import {
  DEFAULT_ACTION,
  END_OF_ACTION,
  GET_COMPANY,
  GET_COMPANY_FAILED,
  GET_COMPANY_SUCCESS,
  GET_CONTENT,
  GET_CONTENT_FAILED,
  GET_CONTENT_SUCCESS,
  GET_KEY_VALUE,
  GET_KEY_VALUE_FAILED,
  GET_KEY_VALUE_SUCCESS,
  GET_LOCATION,
  GET_LOCATION_FAILED,
  GET_LOCATION_SUCCESS,
  GET_PROFESSION,
  GET_PROFESSION_FAILED,
  GET_PROFESSION_SUCCESS,
  GET_SKILL,
  GET_SKILL_FAILED,
  GET_SKILL_SUCCESS,
  PAGINATION,
} from './constants';

export const initialState = {
  jobList: [],
  companyList: [],
  locationList: [],
  professionList: [],
  skillList: [],
  loading: false,
  companyLoading: false,
  professionLoading: false,
  skillLoading: false,
  current: 1,
  pageSize: 10,
  total: 0,
  field: {
    Title: QUERY_TYPE.contain,
    Tag: QUERY_TYPE.contain,
    Location: QUERY_TYPE.equal,
    Professions: QUERY_TYPE.contain,
    CompanyID: QUERY_TYPE.equal,
  },
};

/* eslint-disable default-case, no-param-reassign */
const jobPageReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case DEFAULT_ACTION:
        break;
      case END_OF_ACTION:
        for (var element in draft) {
          draft[element] = initialState[element];
        }
        break;
      case GET_CONTENT:
        draft.loading = true;
        draft.jobList = [];
        break;
      case GET_CONTENT_SUCCESS:
        draft.loading = false;
        draft.total = action.payload.data['@odata.count'];
        draft.jobList = action.payload.data.value;
        break;
      case GET_CONTENT_FAILED:
        draft.loading = false;
        break;
      case GET_COMPANY:
        draft.companyLoading = action.content ? true : false;
        if (!action.content) {
          draft.companyList = [];
        }
        break;
      case GET_COMPANY_SUCCESS:
        draft.companyLoading = false;
        draft.companyList = action.payload.data.value;
        break;
      case GET_COMPANY_FAILED:
        break;
      case GET_PROFESSION:
        draft.professionLoading = action.content ? true : false;
        if (!action.content) {
          draft.professionList = [];
        }
        break;
      case GET_PROFESSION_SUCCESS:
        draft.professionLoading = false;
        draft.professionList = action.payload.data.value;
        break;
      case GET_PROFESSION_FAILED:
        break;

      case GET_SKILL:
        draft.skillLoading = action.content ? true : false;
        if (!action.content) {
          draft.skillList = [];
        }
        break;
      case GET_SKILL_SUCCESS:
        draft.skillLoading = false;
        draft.skillList = action.payload.data.value;
        break;
      case GET_SKILL_FAILED:
        break;

      case GET_KEY_VALUE:
        break;
      case GET_KEY_VALUE_SUCCESS:
        draft[action.payload.name] = action.payload.data.value;
        break;
      case GET_KEY_VALUE_FAILED:
        break;

        case GET_LOCATION:
          draft.locationList = []
        break;
    
        case GET_LOCATION_SUCCESS:
          draft.locationList = action.payload.data.value;
    
        break;
    
        case GET_LOCATION_FAILED:
        break;
    
  
      case PAGINATION:
        draft.current = action.current;
        draft.pageSize = action.pageSize;
        break;
    }
  });

export default jobPageReducer;
