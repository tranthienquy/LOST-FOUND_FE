import { take, call, put, select, takeLatest, delay, fork, takeEvery } from 'redux-saga/effects';
import * as types from './constants';
import * as actions from './actions';
import * as api from 'utils/api';
import { KEY_VALUE } from '../../../utils/api/constants';

function* getJobList({content}) {
  const { current, pageSize } = yield select(state => state.jobPage);
  let filter = '' ;
  console.log(content);
  if (content){
    let cityFilter='';
    let skillFilter='';
    if(content.City && content.City.length >0) {
      cityFilter += yield "("
      yield content.City.forEach(el=>{
        cityFilter += `contains(tolower(City),tolower('${encodeURIComponent(el)}')) or `
      })
      cityFilter = yield cityFilter.slice(0, -3);
      cityFilter += yield ") and"
    }
    if(content.Skills && content.Skills.length >0) {
      skillFilter += yield "("
      yield content.Skills.forEach(el=>{
        skillFilter += `contains(tolower(Skills),tolower('${encodeURIComponent(el)}')) or `
      })
      skillFilter = yield skillFilter.slice(0, -3);
      skillFilter += yield ") and"
    }
    yield console.log(cityFilter);
    filter=
    (content.Title ? `contains(tolower(Title),tolower('${encodeURIComponent(content.Title)}')) and ` :'')
   + (content.Professions ? `contains(Professions,'${encodeURIComponent(content.Professions)}') and ` :'')
   +( content.CompanyID ? `CompanyID eq ${content.CompanyID} and `:'')
   + cityFilter + skillFilter;
}
if (filter){
  filter= filter.slice(0, -4);
}
  const resp = yield call(
    api.postPagination,
    `v1/Jobs`,
    current,
    pageSize,
    filter,
    { Company: { $select: 'Id,Name,Avatar' } ,
    CreateByNavigation: { $select: 'Id' } 
  },
  );
  const { data, status } = resp;
  if (status == 200) {
    yield delay(2000);
    yield put(actions.getJobListSuccess(data));
  } else {
    yield put(actions.getJobListFailed());
  }
}

function* getCompany({content}){
  if (content){
     yield delay(500);
  const resp = yield call(
    api.postPagination,
    `v1/Companies`,
    1,
    10,
    content ? `contains(tolower(Name),tolower('${encodeURIComponent(content)}'))`: null,
    null
  );
  const { data, status } = resp;
  if (status == 200) {
    yield put(actions.getCompanyListSuccess(data));
  } else {
    yield put(actions.getCompanyListFailed());
  }
  }
 
}


function* getProfessionList({content}){
  if (content){
    yield delay(500);

  const resp = yield call(
    api.postPagination,
    `v1/KeyValues`,
    null,
    null,
    `TGroup eq ${KEY_VALUE.PROFESSION} and contains(tolower(TValue),tolower('${encodeURIComponent(content)}'))`,
    null
  );
  const { data, status } = resp;
  if (status == 200) {
    yield put(actions.getProfessionListSuccess(data));
  } else {
    yield put(actions.getProfessionListFailed());
  }
}
}


function* getSkillList({content}){

  if (content){
    yield delay(500);

  const resp = yield call(
    api.postPagination,
    `v1/KeyValues`,
    null,
    null,
    `TGroup eq ${KEY_VALUE.SKILL} and contains(tolower(TValue),tolower('${encodeURIComponent(content)}'))`,
    null
  );
  const { data, status } = resp;
  if (status == 200) {
    yield put(actions.getSkillListSuccess(data));
  } else {
    yield put(actions.getSkillListFailed());
  }
}
}

function* getLocationList(){
  const resp = yield call(
    api.postPagination,
    `v1/KeyValues`,
    null,
    null,
    `TGroup eq ${KEY_VALUE.LOCATION}`,
    null
  );
  const { data, status } = resp;
  if (status == 200) {
    yield put(actions.getLocationListSuccess(data));
  } else {
    yield put(actions.getLocationListFailed());
  }
}
// Individual exports for testing
export default function* jobPageSaga() {
  // See example in containers/HomePage/saga.js
  yield takeLatest(types.GET_CONTENT, getJobList);
  yield takeLatest(types.GET_COMPANY, getCompany);
  yield takeLatest(types.GET_LOCATION, getLocationList)
  yield takeLatest(types.GET_PROFESSION, getProfessionList)
  yield takeLatest(types.GET_SKILL, getSkillList)

}
