/*
 *
 * JobPage constants
 *
 */

export const DEFAULT_ACTION = 'app/JobPage/DEFAULT_ACTION';
export const END_OF_ACTION = 'app/JobPage/END_OF_ACTION';
export const GET_CONTENT = 'app/JobPage/GET_CONTENT';
export const GET_CONTENT_SUCCESS = 'app/JobPage/GET_CONTENT_SUCCESS';
export const GET_CONTENT_FAILED = 'app/JobPage/GET_CONTENT_FAILED';
export const PAGINATION = 'app/JobPage/PAGINATION';

export const GET_COMPANY = 'app/JobPage/GET_COMPANY';
export const GET_COMPANY_SUCCESS = 'app/JobPage/GET_COMPANY_SUCCESS';
export const GET_COMPANY_FAILED = 'app/JobPage/GET_COMPANY_FAILED';

export const GET_KEY_VALUE = 'app/JobPage/GET_KEY_VALUE';
export const GET_KEY_VALUE_SUCCESS = 'app/JobPage/GET_KEY_VALUE_SUCCESS';
export const GET_KEY_VALUE_FAILED = 'app/JobPage/GET_KEY_VALUE_FAILED';

export const GET_LOCATION = 'app/JobPage/GET_LOCATION';
export const GET_LOCATION_SUCCESS = 'app/JobPage/GET_LOCATION_SUCCESS';
export const GET_LOCATION_FAILED = 'app/JobPage/GET_LOCATION_FAILED';

export const GET_PROFESSION = 'app/JobPage/GET_PROFESSION';
export const GET_PROFESSION_SUCCESS = 'app/JobPage/GET_PROFESSION_SUCCESS';
export const GET_PROFESSION_FAILED = 'app/JobPage/GET_PROFESSION_FAILED';

export const GET_SKILL = 'app/JobPage/GET_SKILL';
export const GET_SKILL_SUCCESS = 'app/JobPage/GET_SKILL_SUCCESS';
export const GET_SKILL_FAILED = 'app/JobPage/GET_SKILL_FAILED';

