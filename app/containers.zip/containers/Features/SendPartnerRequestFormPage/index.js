/**
 *
 * SendPartnerRequestFormPage
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import makeSelectSendPartnerRequestFormPage from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import * as actions from './actions';
import './styles.scss';
import { Link } from 'react-router-dom';
import {
  Button,
  Card,
  Typography,
  Tag,
  Modal,
  Form,
  Input,
  Select,
  Skeleton,
  DatePicker,
  Table,
  Upload,
  Checkbox,
} from 'antd';
import moment from 'moment';

import { LinearProgress } from '@mui/material';
class SendPartnerRequestFormPage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      requestSelected: [],
      partnerSelected: [],
      showOnlyCheck: false,
    };
  }
  componentWillUnmount() {
    this.props.onEndOfAction();
  }
  formRef = React.createRef();
  formRef2 = React.createRef();
  componentWillMount() {
    this.props.onGetProfessionList();
    this.props.onGetLocationList();

    this.props.onGetContentList();
  }

  searchProfession = value => {
    // this.props.onGetProfessionList(value);
  };
  searchSkill = value => {
    this.props.onGetSkillList(value);
  };

  sendRequest = () => {
    if (this.state.requestSelected && this.state.requestSelected.length > 0) {
      this.props.onShowModal(true);
      this.props.onGetPartnerList(this.state.requestSelected);
    }
  };
  onSubmit = value => {
    this.props.onGetContentList(value);
  };
  onSubmitFailed = errorInfo => {};
  onSubmit2 = value => {
    this.setState({ partnerSelected: [] });
    this.props.onGetPartnerList(this.state.requestSelected, value);
  };
  onSubmitFailed2 = errorInfo => {};

  duplicateFields = () => {
    const { requests } = this.formRef.current.getFieldsValue();
    if (requests.length > 0) {
      this.formRef.current.setFieldsValue({
        requests: [...requests, requests[requests.length - 1]],
      });
    }
  };
  partnerColumn = [
    {
      title: 'Tên partner',
      children: [
        {
          title: (
            <Form.Item name="Name">
              <Input />
            </Form.Item>
          ),
          key: 'Name',
          dataIndex: 'Name',
        },
      ],
    },
    {
      title: 'Email',
      children: [
        {
          title: (
            <Form.Item name="Email">
              <Input />
            </Form.Item>
          ),
          key: 'Email',
          dataIndex: 'Email',
        },
      ],
    },
  ];
  columns = [
    {
      title: 'Nguồn công việc',
      children: [
        {
          title: (
            <Form.Item name="SourceOfWork">
              <Input />
            </Form.Item>
          ),
          key: 'SourceOfWork',
          dataIndex: 'SourceOfWork',
        },
      ],
    },
    {
      title: 'Id',
      children: [
        {
          title: () => (
            <Form.Item name="RequestId">
              <Input />
            </Form.Item>
          ),
          key: 'RequestId',
          dataIndex: 'RequestId',
        },
      ],
    },
    {
      title: 'Tên công việc',
      children: [
        {
          title: (
            <Form.Item name="RequestName">
              <Input />
            </Form.Item>
          ),
          key: 'RequestName',
          dataIndex: 'RequestName',
        },
      ],
    },
    {
      title: 'Nơi làm việc',
      children: [
        {
          title: (
            <Form.Item name="RequestLocation">
              <Input />
            </Form.Item>
          ),
          key: 'RequestLocation',
          dataIndex: 'RequestLocation',
        },
      ],
    },
    {
      title: 'Ngành nghề',
      children: [
        {
          title: () => (
            <Form.Item name="Professions">
              <Select
                className="w-100"
                placeholder="Ngành nghề"
                suffixIcon={''}
                showSearch
                onSearch={this.searchProfession}
                filterOption={false}
                onChange={this.onSelectChange}
                loading={
                  this.props.sendPartnerRequestFormPage.loading.professionList
                }
                allowClear={true}
                notFoundContent={''}
              >
                {this.props.sendPartnerRequestFormPage.professionList &&
                  this.props.sendPartnerRequestFormPage.professionList.map(
                    item => (
                      <Select.Option
                        value={item.TKey}
                        key={`options-profession-${item.Id}`}
                      >
                        {item.TValue}
                      </Select.Option>
                    ),
                  )}
                {this.props.sendPartnerRequestFormPage.loading
                  .professionList && (
                  <Select.Option disabled>Đang tải...</Select.Option>
                )}
              </Select>
            </Form.Item>
          ),
          key: 'Professions',
          dataIndex: 'Professions',
        },
      ],
    },
    {
      title: 'Kỹ năng',
      children: [
        {
          title: () => (
            <Form.Item name="Skill">
              <Select
                className="w-100"
                placeholder="Kỹ năng"
                onChange={this.onSelectChange}
                suffixIcon={''}
                showSearch
                onSearch={this.searchSkill}
                filterOption={false}
                loading={
                  this.props.sendPartnerRequestFormPage.loading.skillList
                }
                allowClear={true}
                notFoundContent={''}
              >
                {this.props.sendPartnerRequestFormPage.skillList &&
                  this.props.sendPartnerRequestFormPage.skillList.map(item => (
                    <Select.Option
                      value={item.TKey}
                      key={`options-profession-${item.Id}`}
                    >
                      {item.TValue}
                    </Select.Option>
                  ))}
                {this.props.sendPartnerRequestFormPage.loading.skillList && (
                  <Select.Option disabled>Đang tải...</Select.Option>
                )}
              </Select>
            </Form.Item>
          ),
          key: 'ListSkill',
          dataIndex: 'ListSkill',
          render: record => record.map(el => <Tag>{el} </Tag>),
        },
      ],
    },
    {
      title: 'Số năm kinh nghiệm',
      children: [{ key: 'WorkExperience', dataIndex: 'WorkExperience' }],
    },
    {
      title: 'Số lượng',
      children: [{ key: 'Quantity', dataIndex: 'Quantity' }],
    },
  ];
  handleTableChange = (newPagination, filters, sorter) => {
    console.log(newPagination, filters, sorter);
    this.props.onPagination(newPagination.current, newPagination.pageSize);
    this.props.onGetContentList({ ...this.state.valueSearch });
  };
  onSelectChange = () => {
    this.props.onGetContentList(this.formRef.current.getFieldsValue());
  };
  render() {
    const {
      professionList,
      skillList,
      loading,
      content,
      partnerList,
      partnerModal,
      locationList,
    } = this.props.sendPartnerRequestFormPage;
    return (
      <div className="recruitment-request-form-container d-flex flex-column pt-5">
        <Form
          name="basic"
          onFinish={this.onSubmit}
          autoComplete="off"
          layout="vertical"
          initialValues={{}}
          onFinishFailed={this.onSubmitFailed}
          className="ant-general-form"
          ref={this.formRef}
        >
          <Button htmlType="submit" />
          <div className="d-flex justify-content-between ">
            <Typography className="text-app-primary h4 font-weight-bold">
              GỬI YÊU CẦU TUYỂN DỤNG CHO PARTNER
            </Typography>
          </div>

          <Table
            className="mt-5"
            size="small"
            rowSelection={{
              type: 'checkbox',
              onChange: (selectedRowKeys, selectedRows) => {
                console.log(
                  `selectedRowKeys: ${selectedRowKeys}`,
                  'selectedRows: ',
                  selectedRows,
                );
                this.setState({ requestSelected: selectedRows });
              },
            }}
            columns={this.columns}
            scroll={{ x: 3000, y: 1000 }}
            dataSource={content}
            loading={loading.content}
            onChange={this.handleTableChange}
          />
          {/* <Form.List name="users"> */}

          <Button
            size="large"
            type="primary"
            className="text-center w-100 mt-3"
            onClick={this.sendRequest}
          >
            <b className="w-100 text-center">GỬI YÊU CẦU</b>
          </Button>
          {/* <div style={{ height: '10px' }}>
            {loading.submit ? <LinearProgress color="success" /> : ''}
          </div> */}
        </Form>

        <Modal
          title="Danh sách Partner"
          footer={
            <Button
            loading={loading.submit}
              onClick={() =>
               { if (this.state.partnerSelected.length>0){
                
              
                this.props.onSubmitContent({
                  ListRequestId: this.state.requestSelected.map(
                    el => el.RequestId,
                  ),
                  ListPartnerId: this.state.partnerSelected.map(
                    el => el.PartnerId,
                  ),
                })} }
              }
            >
              Xác nhận
            </Button>
          }
          visible={partnerModal}
          onCancel={() => this.props.onShowModal(false)}
        >
          <Form
            name="basic"
            onFinish={this.onSubmit2}
            autoComplete="off"
            layout="vertical"
            initialValues={{}}
            onFinishFailed={this.onSubmitFailed2}
            className="ant-general-form"
            ref={this.formRef2}
          >
            <Button htmlType="submit" />
            <Checkbox
              onChange={() => {
                this.setState({ showOnlyCheck: !this.state.showOnlyCheck });
              }}
              value={this.state.showOnlyCheck}
              className="ml-3 mt-3"
            >
              <Typography>Chỉ hiển thị partner đã chọn</Typography>
            </Checkbox>
            <Table
              className="mt-5"
              size="small"
              columns={this.partnerColumn}
              rowSelection={{
                type: 'checkbox',
                onChange: (selectedRowKeys, selectedRows) => {
                  console.log(
                    `selectedRowKeys: ${selectedRowKeys}`,
                    'selectedRows: ',
                    selectedRows,
                  );
                  this.setState({ partnerSelected: selectedRows });
                },
                getCheckboxProps: (record) => ({
                  disabled: record.IsSelect === false, // Column configuration not to be checked
                  // name: record.name,
                  
                }),
                selectedRowKeys:partnerList.filter(item=>item.isSelect).map(item=>item.key)
              }}
              // scroll={{ x: 3000, y: 1000 }}
              dataSource={
                !this.state.showOnlyCheck
                  ? partnerList
                  : partnerList.filter(el =>
                      this.state.partnerSelected.find(
                        item => item.PartnerId === el.PartnerId,
                      ),
                    )
              }
              loading={loading.partnerList}
            />
          </Form>
        </Modal>
      </div>
    );
  }
}

SendPartnerRequestFormPage.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  sendPartnerRequestFormPage: makeSelectSendPartnerRequestFormPage(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    onEndOfAction: () => {
      dispatch(actions.endOfAction());
    },
    onGetProfessionList: content => {
      dispatch(actions.getProfessionList(content));
    },
    onGetSkillList: content => {
      dispatch(actions.getSkillList(content));
    },
    onSubmitContent: content => {
      dispatch(actions.submitContent(content));
    },
    onGetLocationList: () => {
      dispatch(actions.getLocationList());
    },
    onGetPartnerList: (requestIds, content) => {
      dispatch(actions.getPartnerList(requestIds, content));
    },
    onGetContentList: () => {
      dispatch(actions.getContentList());
    },
    onShowModal: isShowing => {
      dispatch(actions.showModal(isShowing));
    },
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

const withReducer = injectReducer({
  key: 'sendPartnerRequestFormPage',
  reducer,
});
const withSaga = injectSaga({ key: 'sendPartnerRequestFormPage', saga });
export default compose(
  withConnect,
  withReducer,
  withSaga,
)(SendPartnerRequestFormPage);
