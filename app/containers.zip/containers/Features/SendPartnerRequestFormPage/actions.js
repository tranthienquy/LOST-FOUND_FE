/*
 *
 * SendPartnerRequestFormPage actions
 *
 */

import { DEFAULT_ACTION, END_OF_ACTION,  GET_PROFESSION,
  GET_PROFESSION_FAILED,
  GET_PROFESSION_SUCCESS,
  GET_SKILL,
  GET_SKILL_SUCCESS,
  GET_SKILL_FAILED,

  SUBMIT_CONTENT,
  SUBMIT_CONTENT_FAILED,
  SUBMIT_CONTENT_SUCCESS, 
  GET_LOCATION,
  GET_LOCATION_FAILED,
  GET_LOCATION_SUCCESS,
  GET_CONTENT,
  GET_CONTENT_FAILED,
  GET_CONTENT_SUCCESS,
  SHOW_MODAL,
  GET_PARTNER,
  GET_PARTNER_SUCCESS,
  GET_PARTNER_FAILED,} from './constants';

export function defaultAction() {
  return {
    type: DEFAULT_ACTION,
  };
}
export const endOfAction = () => {
  return {
    type: END_OF_ACTION,
  };
};

export const submitContent = value => {
  return {
    type: SUBMIT_CONTENT,
    value,
  };
};
export const submitContentSuccess = data => {
  return {
    type: SUBMIT_CONTENT_SUCCESS,
    payload: {
      data,
    },
  };
};
export const submitContentFailed = error => {
  return {
    type: SUBMIT_CONTENT_FAILED,
    error,
  };
};

export const getProfessionList = (content = '') => {
  return {
    type: GET_PROFESSION,
    content,
  };
};
export const getProfessionListSuccess = data => {
  return {
    type: GET_PROFESSION_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getProfessionListFailed = () => {
  return {
    type: GET_PROFESSION_FAILED,
  };
};

export const getSkillList = (content = '') => {
  return {
    type: GET_SKILL,
    content,
  };
};
export const getSkillListSuccess = data => {
  return {
    type: GET_SKILL_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getSkillListFailed = () => {
  return {
    type: GET_SKILL_FAILED,
  };
};
export const getLocationList = () => {
  return {
    type: GET_LOCATION,
  };
};
export const getLocationListSuccess = data => {
  return {
    type: GET_LOCATION_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getLocationListFailed = () => {
  return {
    type: GET_LOCATION_FAILED,
  };
};
export const getPartnerList = (requestIds, content) => {
  return {
    type: GET_PARTNER,
    requestIds,
    content
  };
};
export const getPartnerListSuccess = data => {
  return {
    type: GET_PARTNER_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getPartnerListFailed = () => {
  return {
    type: GET_PARTNER_FAILED,
  };
};
export const showModal = (isShowing, ) => {
  return {
    type: SHOW_MODAL,
    isShowing
  };
};
export const getContentList = () => {
  return {
    type: GET_CONTENT,
  };
};
export const getContentListSuccess = data => {
  return {
    type: GET_CONTENT_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getContentListFailed = () => {
  return {
    type: GET_CONTENT_FAILED,
  };
};
