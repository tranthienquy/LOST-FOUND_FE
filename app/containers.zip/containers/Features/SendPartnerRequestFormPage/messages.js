/*
 * SendPartnerRequestFormPage Messages
 *
 * This contains all the text for the SendPartnerRequestFormPage container.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.containers.SendPartnerRequestFormPage';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'This is the SendPartnerRequestFormPage container!',
  },
});
