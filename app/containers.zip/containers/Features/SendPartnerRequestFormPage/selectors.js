import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the sendPartnerRequestFormPage state domain
 */

const selectSendPartnerRequestFormPageDomain = state =>
  state.sendPartnerRequestFormPage || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by SendPartnerRequestFormPage
 */

const makeSelectSendPartnerRequestFormPage = () =>
  createSelector(
    selectSendPartnerRequestFormPageDomain,
    substate => substate,
  );

export default makeSelectSendPartnerRequestFormPage;
export { selectSendPartnerRequestFormPageDomain };
