/*
 *
 * SendPartnerRequestFormPage constants
 *
 */

export const DEFAULT_ACTION = 'app/SendPartnerRequestFormPage/DEFAULT_ACTION';
export const END_OF_ACTION = 'app/SendPartnerRequestFormPage/END_OF_ACTION';

export const GET_PROFESSION = 'app/SendPartnerRequestFormPage/GET_PROFESSION';
export const GET_PROFESSION_SUCCESS = 'app/SendPartnerRequestFormPage/GET_PROFESSION_SUCCESS';
export const GET_PROFESSION_FAILED = 'app/SendPartnerRequestFormPage/GET_PROFESSION_FAILED';

export const GET_SKILL = 'app/SendPartnerRequestFormPage/GET_SKILL';
export const GET_SKILL_SUCCESS = 'app/SendPartnerRequestFormPage/GET_SKILL_SUCCESS';
export const GET_SKILL_FAILED = 'app/SendPartnerRequestFormPage/GET_SKILL_FAILED';

export const SUBMIT_CONTENT = 'app/SendPartnerRequestFormPage/SUBMIT_CONTENT';
export const SUBMIT_CONTENT_SUCCESS = 'app/SendPartnerRequestFormPage/SUBMIT_CONTENT_SUCCESS';
export const SUBMIT_CONTENT_FAILED = 'app/SendPartnerRequestFormPage/SUBMIT_CONTENT_FAILED';

export const GET_LOCATION = 'app/SendPartnerRequestFormPage/GET_LOCATION';
export const GET_LOCATION_SUCCESS = 'app/SendPartnerRequestFormPage/GET_LOCATION_SUCCESS';
export const GET_LOCATION_FAILED = 'app/SendPartnerRequestFormPage/GET_LOCATION_FAILED';

export const GET_PARTNER = 'app/SendPartnerRequestFormPage/GET_PARTNER';
export const GET_PARTNER_SUCCESS = 'app/SendPartnerRequestFormPage/GET_PARTNER_SUCCESS';
export const GET_PARTNER_FAILED = 'app/SendPartnerRequestFormPage/GET_PARTNER_FAILED';

export const SHOW_MODAL = 'app/SendPartnerRequestFormPage/SHOW_MODAL';

export const GET_CONTENT = 'app/SendPartnerRequestFormPage/GET_CONTENT';
export const GET_CONTENT_SUCCESS = 'app/SendPartnerRequestFormPage/GET_CONTENT_SUCCESS';
export const GET_CONTENT_FAILED = 'app/SendPartnerRequestFormPage/GET_CONTENT_FAILED';