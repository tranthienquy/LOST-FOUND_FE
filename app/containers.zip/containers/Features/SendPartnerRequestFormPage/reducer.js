/*
 *
 * SendPartnerRequestFormPage reducer
 *
 */
import produce from 'immer';
import * as types from './constants';

export const initialState = {
  professionList: [],
  skillList: [],
  locationList: [],
  partnerList: [],
  content: [],
  loading: {
    skillList: false,
    professionList: false,
    submit: false,
    partnerList: false,
    getContent: false,
    content: true,
  },
  partnerModal: false,
};

/* eslint-disable default-case, no-param-reassign */
const sendPartnerRequestFormPageReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case types.DEFAULT_ACTION:
        break;
      case types.END_OF_ACTION:
        for (var element in draft) {
          draft[element] = initialState[element];
        }
        break;
      case types.GET_PROFESSION:
        draft.loading.professionList = action.content ? true : false;
        if (!action.content) {
          draft.professionList = [];
        }
        break;
      case types.GET_PROFESSION_SUCCESS:
        draft.loading.professionList = false;
        draft.professionList = action.payload.data.value;
        break;
      case types.GET_PROFESSION_FAILED:
        break;

      case types.GET_SKILL:
        draft.loading.skillList = action.content ? true : false;
        if (!action.content) {
          draft.skillList = [];
        }
        break;
      case types.GET_SKILL_SUCCESS:
        draft.loading.skillList = false;
        draft.skillList = action.payload.data.value;
        break;
      case types.GET_SKILL_FAILED:
        break;
      case types.SUBMIT_CONTENT:
        draft.loading.submit = true;
        break;
      case types.SUBMIT_CONTENT_SUCCESS:
        draft.loading.submit = false;

        break;
      case types.SUBMIT_CONTENT_FAILED:
        draft.loading.submit = false;
      case types.GET_LOCATION:
        draft.locationList = [];
        break;
      case types.GET_LOCATION_SUCCESS:
        draft.locationList = action.payload.data.value;
        break;
      case types.GET_LOCATION_FAILED:
        break;
      case types.GET_PARTNER:
        draft.partnerList = [];
        draft.loading.partnerList= true
        break;
      case types.GET_PARTNER_SUCCESS:
        draft.partnerList = action.payload.data.map(el=>({...el, key: el.PartnerId}));
        draft.loading.partnerList= false
        break;
      case types.GET_PARTNER_FAILED:
        break;
      case types.GET_CONTENT:
        draft.content = [];
        draft.loading.content= true
        break;
      case types.GET_CONTENT_SUCCESS:
        draft.content = action.payload.data.map(el=>({...el, key: el.RequestId}));
        draft.loading.content= false
        break;
      case types.GET_CONTENT_FAILED:
        break;
      case types.SHOW_MODAL:
        draft.partnerModal = action.isShowing;
        break;
    }
  });

export default sendPartnerRequestFormPageReducer;
