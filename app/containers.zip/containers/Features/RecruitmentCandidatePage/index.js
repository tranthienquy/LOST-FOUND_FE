/**
 *
 * RecruitmentCandidatePage
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import makeSelectRecruitmentCandidatePage from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import * as actions from './actions';
import './styles.scss';
import { Input, Table, Typography, Form, Button, DatePicker, Tabs } from 'antd';
import { Link } from 'react-router-dom';

class RecruitmentCandidatePage extends React.Component {
  componentWillUnmount() {
    this.props.onEndOfAction();
  }
  columns = [
    {
      title: 'ID',
      key: 'ID',
      dataIndex: 'ID',
    },

    {
      title: 'Tên khóa học',
      children: [
        {
          title: (
            <Form.Item name="Title">
              <Input name="Title" />
            </Form.Item>
          ),
          key: 'Title',
          dataIndex: 'Title',
        },
      ],
    },
    {
      title: 'Công ty cung cấp',
      children: [
        {
          title: (
            <Form.Item name="Title">
              <Input name="Title" />
            </Form.Item>
          ),
          key: 'Title',
          dataIndex: 'Title',
        },
      ],
    },
    {
      title: 'Hình thức',
      children: [
        {
          title: (
            <Form.Item name="Title">
              <Input name="Title" />
            </Form.Item>
          ),
          key: 'Title',
          dataIndex: 'Title',
        },
      ],
    },
    {
      title: 'Tên học viên',
      children: [
        {
          title: (
            <Form.Item name="Title">
              <Input name="Title" />
            </Form.Item>
          ),
          key: 'Title',
          dataIndex: 'Title',
        },
      ],
    },
  
    {
      title: 'Email',
      children: [
        {
          title: (
            <Form.Item name="Title">
              <Input name="Title" />
            </Form.Item>
          ),
          key: 'Title',
          dataIndex: 'Title',
        },
      ],
    },
    {
      title:'Đã đăng ký',
      key: 'Title',
      dataIndex: 'Title',
    },
    {
      title: 'Đã nộp tiền',
      children: [
        {
          title: (
            <Form.Item name="Title">
              <Input name="Title" />
            </Form.Item>
          ),
          key: 'Title',
          dataIndex: 'Title',
        },
      ],
    },
    {
      title: 'Đang học',
      children: [
        {
          title: (
            <Form.Item name="Title">
              <Input name="Title" />
            </Form.Item>
          ),
          key: 'Title',
          dataIndex: 'Title',
        },
      ],
    },
    {
      title: 'Hoàn thành',
      children: [
        {
          title: (
            <Form.Item name="Title">
              <Input name="Title" />
            </Form.Item>
          ),
          key: 'Title',
          dataIndex: 'Title',
        },
      ],
    },
   
    
  ];
  dataSource = [
    {
      ID: '1',
      Title: (
        <Form.Item name="Title">
          <Input name="Title" />
        </Form.Item>
      ),
    },
  ];
  onSubmit = value => {
    console.log(value);
  };
  onSubmitFailed = errorInfo => {};

  render() {
    return (
      <div className="course-candidate-request-container d-flex flex-column pt-5">
     
     <Form
       name="basic"
       onFinish={this.onSubmit}
       autoComplete="off"
       layout="vertical"
       initialValues={{}}
       onFinishFailed={this.onSubmitFailed}
       className="ant-general-form"
     >
       <div className="d-flex justify-content-between ">
         <Typography className="text-app-primary h4 font-weight-bold">
           DANH SÁCH KHÓA HỌC - HỌC VIÊN
         </Typography>
         {/* <Button> Xuất Excel </Button> */}
        
       </div>
      
       <Table
         className="mt-5"
         columns={this.columns}
         scroll={{ y: 1000 }}
         dataSource={this.dataSource}
       >
         <Table.Column title="Xem CV" />
       </Table>
     </Form>
   </div>
    );
  }
}

RecruitmentCandidatePage.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  recruitmentCandidatePage: makeSelectRecruitmentCandidatePage(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    onEndOfAction: () => {
      dispatch(actions.endOfAction());
    },
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

const withReducer = injectReducer({ key: 'recruitmentCandidatePage', reducer });
const withSaga = injectSaga({ key: 'recruitmentCandidatePage', saga });
export default compose(
  withConnect,
  withReducer,
  withSaga,
)(RecruitmentCandidatePage);
