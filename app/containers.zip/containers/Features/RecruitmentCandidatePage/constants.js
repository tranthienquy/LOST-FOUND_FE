/*
 *
 * RecruitmentCandidatePage constants
 *
 */

export const DEFAULT_ACTION = 'app/RecruitmentCandidatePage/DEFAULT_ACTION';
export const END_OF_ACTION = 'app/RecruitmentCandidatePage/END_OF_ACTION';

export const GET_CONTENT = 'app/RecruitmentCandidatePage/GET_CONTENT';
export const GET_CONTENT_SUCCESS = 'app/RecruitmentCandidatePage/GET_CONTENT_SUCCESS';
export const GET_CONTENT_FAILED = 'app/RecruitmentCandidatePage/GET_CONTENT_FAILED';