/*
 *
 * RecruitmentCandidatePage actions
 *
 */

import { DEFAULT_ACTION, END_OF_ACTION ,  GET_CONTENT,
  GET_CONTENT_FAILED,
  GET_CONTENT_SUCCESS,} from './constants';

export function defaultAction() {
  return {
    type: DEFAULT_ACTION,
  };
}
export const endOfAction = () => {
  return {
    type: END_OF_ACTION,
  };
};


export const getContentList = (content = null) => {
  return {
    type: GET_CONTENT,
    content,
  };
};
export const getContentListSuccess = data => {
  return {
    type: GET_CONTENT_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getContentListFailed = () => {
  return {
    type: GET_CONTENT_FAILED,
  };
};