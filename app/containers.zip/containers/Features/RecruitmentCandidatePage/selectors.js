import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the recruitmentCandidatePage state domain
 */

const selectRecruitmentCandidatePageDomain = state =>
  state.recruitmentCandidatePage || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by RecruitmentCandidatePage
 */

const makeSelectRecruitmentCandidatePage = () =>
  createSelector(
    selectRecruitmentCandidatePageDomain,
    substate => substate,
  );

export default makeSelectRecruitmentCandidatePage;
export { selectRecruitmentCandidatePageDomain };
