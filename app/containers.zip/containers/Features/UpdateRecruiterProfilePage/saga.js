import { take, call, put, select, takeLatest, delay } from 'redux-saga/effects';
import { push } from 'react-router-redux';
import * as types from './constants';
import * as actions from './actions';
import * as api from 'utils/api';
import { notification } from 'antd';


function* getContent({ id }) {
  yield delay(1000);
  const resp = yield call(
    api.get,
    `v1/UserProfiles(${id})`, 
  );
  const { data, status } = resp;

  if (status == 200 ) {
      yield put(actions.getContentSuccess({...data}));
   
  } else {
    yield put(actions.getContentFailed());
  }

}

function* submitContent({value}){
  const {content,id} = yield select(state => state.updateRecruiterProfilePage);
  const resp = yield call(
    api.post,
    `v1/UserProfiles/update-profile-recuiter`, {}, value
  );
  const { data, status } = resp;

  if (status == 200 ) {
    yield delay(2000);
    yield put(actions.submitContentSuccess(data));
    yield notification.open({
      message:"Cập nhật hồ sơ cá nhân thành công",
      type:"success"

    })
    yield put(actions.getContent(id));
    
  } else {
    yield put(actions.submitContentFailed('password-failed'));
  }
}
// Individual exports for testing
export default function* updateRecruiterProfilePageSaga() {
  // See example in containers/HomePage/saga.js
  yield takeLatest(types.SUBMIT_CONTENT, submitContent);
  yield takeLatest(types.GET_CONTENT, getContent);

}
