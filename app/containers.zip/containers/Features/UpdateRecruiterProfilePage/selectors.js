import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the updateRecruiterProfilePage state domain
 */

const selectUpdateRecruiterProfilePageDomain = state =>
  state.updateRecruiterProfilePage || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by UpdateRecruiterProfilePage
 */

const makeSelectUpdateRecruiterProfilePage = () =>
  createSelector(
    selectUpdateRecruiterProfilePageDomain,
    substate => substate,
  );

export default makeSelectUpdateRecruiterProfilePage;
export { selectUpdateRecruiterProfilePageDomain };
