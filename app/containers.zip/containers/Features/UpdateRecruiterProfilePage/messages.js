/*
 * UpdateRecruiterProfilePage Messages
 *
 * This contains all the text for the UpdateRecruiterProfilePage container.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.containers.UpdateRecruiterProfilePage';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'This is the UpdateRecruiterProfilePage container!',
  },
});
