/*
 *
 * UpdateRecruiterProfilePage reducer
 *
 */
import produce from 'immer';
import * as types from './constants';

export const initialState = {
id: null,
  loading: {
    content: true,
    submit: false,
  },
  content: {},
  error:null
};

/* eslint-disable default-case, no-param-reassign */
const updateRecruiterProfilePageReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case types.DEFAULT_ACTION:
        break;
      case types.END_OF_ACTION:
        for (var element in draft) {
          draft[element] = initialState[element];
        }
        case types.GET_CONTENT:
        draft.id=action.id;
        draft.loading.content = true;  
        
        break;
        case types.GET_CONTENT_SUCCESS:
          draft.loading.content = false;  
          const {RepresentativeName, Phone, Position}= action.payload.data.value[0]
          draft.content= {RepresentativeName, Phone, Position};
        break;
        case types.GET_CONTENT_FAILED:break;
        case types.SUBMIT_CONTENT:
          
          draft.loading.submit = true;  
          break;
        case types.SUBMIT_CONTENT_SUCCESS:
          draft.loading.submit = false;  
        break;
        case types.SUBMIT_CONTENT_FAILED:
          draft.loading.submit = false;  
          
        break;
    }
  });

export default updateRecruiterProfilePageReducer;
