/**
 *
 * Asynchronously loads the component for UpdateRecruiterProfilePage
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
