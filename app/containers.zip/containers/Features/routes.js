import React from 'react';
import { USER_ROLE } from '../../utils/constants';
import HomeMainPage from './HomeMainPage/Loadable';
import LoginPage from './LoginPage/Loadable';
import JobPage from './JobPage/Loadable';
import CoursePage from './CoursePage/Loadable';
import JobDetailPage from './JobDetailPage/Loadable';
import CourseDetailPage from './CourseDetailPage/Loadable';
import CompanyDetailPage from './CompanyDetailPage/Loadable';
import RegisterPage from './RegisterPage/Loadable';
import ForgetPasswordPage from './ForgetPasswordPage/Loadable';
import RegisterPartnerPage from './RegisterPartnerPage/Loadable';
import RegisterRecruiterPage from './RegisterRecruiterPage/Loadable';
import ChangePasswordPage from './ChangePasswordPage/Loadable';
import RegisterRecruiterAndPartnerPage from './RegisterRecruiterAndPartnerPage/Loadable';
import ProfilePage from './ProfilePage/Loadable';
import CandidatePage from './CandidatePage/Loadable';
import JobRequestPage from './JobRequestPage/Loadable';
import JobRequestDetailPage from './JobRequestDetailPage/Loadable';
import CandidateJobRequestPage from './CandidateJobRequestPage/Loadable';
import UpdateRecruiterProfilePage from './UpdateRecruiterProfilePage/Loadable';
import UpdateCompanyPage from './UpdateCompanyPage/Loadable';
import JobFormPage from './JobFormPage/Loadable';
import CourseFormPage from './CourseFormPage/Loadable';
import RecruitmentRequestRecruiterPage from './RecruitmentRequestRecruiterPage/Loadable';
import RecruitmentRequestFormPage from './RecruitmentRequestFormPage/Loadable';
import CandidateRecruiterPage from './CandidateRecruiterPage/Loadable';
import CourseCandidatePage from './CourseCandidatePage/Loadable';
import UpdatePartnerProfilePage from './UpdatePartnerProfilePage/Loadable';
import CandidateFormPage from './CandidateFormPage/Loadable';
import RecruitmentRequestDetailPage from './RecruitmentRequestDetailPage/Loadable';
import RecruitmentRequestEditPage from './RecruitmentRequestEditPage/Loadable';
import RecruitmentRequestShinyamaPage from './RecruitmentRequestShinyamaPage/Loadable';
import SendPartnerRequestFormPage from './SendPartnerRequestFormPage/Loadable';
import ContactPage from './ContactPage/Loadable';
import ContactEditPage from './ContactEditPage/Loadable';
import RecruitmentRequestPage from './RecruitmentRequestPage/Loadable';
import CandidateShinyamaPage from './CandidateShinyamaPage/Loadable';
import RegisterShinyamaPage from './RegisterShinyamaPage/Loadable';
import UserManagementPage from './UserManagementPage/Loadable';
import CategoryManagementPage from './CategoryManagementPage';


export const endpoint = '/';
export const routes = [
  {
    path: '/',
    exact: true,
    private: false,
    main: () => <HomeMainPage />,
  },
  {
    path: '/login',
    exact: true,
    private: false,
    main: () => <LoginPage />,
    type: 'unauthorized'
  },
  {
    path: '/register',
    exact: true,
    private: false,
    main: () => <RegisterPage />,
    type: 'unauthorized'

  },
  {
    path: '/register-partner',
    exact: true,
    private: false,
    main: () => <RegisterPartnerPage />,
    type: 'unauthorized',

  },
  {
    path: '/register-recruiter',
    exact: true,
    private: false,
    main: () => <RegisterRecruiterPage />,
    type: 'unauthorized',

  },
  {
    path: '/register-recruiter-and-partner',
    exact: true,
    private: false,
    main: () => <RegisterRecruiterAndPartnerPage />,
    type: 'unauthorized'
  },
  {
    path: '/register-shinyama',
    exact: true,
    private: false,
    main: () => <RegisterShinyamaPage />,
    role: [USER_ROLE.ADMIN]

  },
  {
    path: '/forgot-password',
    exact: true,
    private: false,
    main: () => <ForgetPasswordPage />,
  },
  {
    path: '/change-password',
    exact: true,
    private: false,
    main: () => <ChangePasswordPage />,
    role: [USER_ROLE.APPLICANT, USER_ROLE.RECRUITER, USER_ROLE.TOKUTEI,  USER_ROLE.PARTNER, USER_ROLE.SHINYAMA, USER_ROLE.SHINYAMA_MANAGER]
  },
  {
    path: '/profile',
    exact: true,
    private: false,
    main: () => <ProfilePage />,
    role: [USER_ROLE.APPLICANT, USER_ROLE.RECRUITER, USER_ROLE.TOKUTEI]
  },
  {
    path: '/candidate',
    exact: true,
    private: false,
    main: () => <CandidatePage />,
    role: [USER_ROLE.PARTNER, USER_ROLE.RECRUITER]
  },
  {
    path: '/candidate/edit/:id',
    exact: true,
    private: false,
    main: () => <CandidateFormPage />,
    role: [USER_ROLE.PARTNER, USER_ROLE.RECRUITER]
  },
  {
    path: '/candidate/add',
    exact: true,
    private: false,
    main: () => <CandidateFormPage />,
    role: [USER_ROLE.PARTNER, USER_ROLE.RECRUITER]
  },
  {
    path: '/job',
    exact: true,
    private: false,
    main: () => <JobPage />,
  },
  {
    path: '/job/:id',
    exact: true,
    private: false,
    main: () => <JobDetailPage />,
  },
  {
    path: '/job-form/add',
    exact: true,
    private: false,
    main: () => <JobFormPage />,
  },
  {
    path: '/job-form/edit/:id',
    exact: true,
    private: false,
    main: () => <JobFormPage />,
  },
  {
    path: '/contact',
    exact: true,
    private: false,
    main: () => <ContactPage />,
  },
  {
    path: '/contact-edit',
    exact: true,
    private: false,
    main: () => <ContactEditPage />,
    role: [USER_ROLE.ADMIN]
  },
  {
    path: '/user-management',
    exact: true,
    private: false,
    main: () => <UserManagementPage />,
    role: [USER_ROLE.ADMIN]
  },
  {
    path: '/category-management',
    exact: true,
    private: false,
    main: () => <CategoryManagementPage />,
    role: [USER_ROLE.ADMIN]
  },
  {
    path: '/course-form/add',
    exact: true,
    private: false,
    main: () => <CourseFormPage />,
    role: [USER_ROLE.SHINYAMA, USER_ROLE.SHINYAMA_MANAGER]

  },
  {
    path: '/course-form/edit/:id',
    exact: true,
    private: false,
    main: () => <CourseFormPage />,
    role: [USER_ROLE.SHINYAMA, USER_ROLE.SHINYAMA_MANAGER]

  },
  {
    path: '/course',
    exact: true,
    private: false,
    main: () => <CoursePage />,
  },
  
   {
    path: '/course/:id',
    exact: true,
    private: false,
    main: () => <CourseDetailPage />,
  },
   {
    path: '/company/:id',
    exact: true,
    private: false,
    main: () => <CompanyDetailPage />,
  },
  {
    path: '/recruitment-request-partner',
    exact: true,
    private: false,
    main: () => <JobRequestPage />,
    role: [USER_ROLE.PARTNER]
  },
  {
    path: '/profile-recruiter',
    exact: true,
    private: false,
    main: () => <UpdateRecruiterProfilePage />,
    role: [USER_ROLE.RECRUITER]
  },
  {
    path: '/profile-partner',
    exact: true,
    private: false,
    main: () => <UpdatePartnerProfilePage />,
    role: [USER_ROLE.PARTNER]
  },
  {
    path: '/update-company',
    exact: true,
    private: false,
    main: () => <UpdateCompanyPage />,
    role: [USER_ROLE.RECRUITER]
  },
  {
    path: '/recruitment-request/:id',
    exact: true,
    private: false,
    main: () => <RecruitmentRequestDetailPage />,
    role: [USER_ROLE.PARTNER]
  },
  {
    path: '/recruitment-request/edit/:id',
    exact: true,
    private: false,
    main: () => <RecruitmentRequestEditPage/>,
    role: [USER_ROLE.SHINYAMA, USER_ROLE.SHINYAMA_MANAGER, USER_ROLE.RECRUITER]
  },
  {
    path: '/candidate-job-request/:id',
    exact: true,
    private: false,
    main: () => <CandidateJobRequestPage />,
    role: [USER_ROLE.PARTNER]
  },
  {
    path: '/recruitment-request-recruiter',
    exact: true,
    private: false,
    main: () => <RecruitmentRequestPage />,
    role: [ USER_ROLE.RECRUITER]
  },
  {
    path: '/recruitment-request-recruiter/add',
    exact: true,
    private: false,
    main: () => <RecruitmentRequestFormPage />,
    role: [USER_ROLE.RECRUITER]
  },
  {
    path: '/recruitment-request-recruiter/edit/:id',
    exact: true,
    private: false,
    main: () => <RecruitmentRequestEditPage />,
    role: [USER_ROLE.RECRUITER]
  },
  {
    path: '/recruitment-request-shinyama',
    exact: true,
    private: false,
    main: () => <RecruitmentRequestShinyamaPage />,
    role: [ USER_ROLE.SHINYAMA, USER_ROLE.SHINYAMA_MANAGER]
  },
  {
    path: '/recruitment-request-shinyama/add',
    exact: true,
    private: false,
    main: () => <RecruitmentRequestFormPage />,
    role: [USER_ROLE.SHINYAMA, USER_ROLE.SHINYAMA_MANAGER]
  },
  {
    path: '/send-partner-request',
    exact: true,
    private: false,
    main: () => <SendPartnerRequestFormPage />,
    role: [USER_ROLE.SHINYAMA, USER_ROLE.SHINYAMA_MANAGER]
  },
  {
    path: '/recruitment-request-shinyama/edit/:id',
    exact: true,
    private: false,
    main: () => <RecruitmentRequestFormPage />,
    role: [USER_ROLE.SHINYAMA, USER_ROLE.SHINYAMA_MANAGER]
  },
  {
    path: '/candidate-recruiter',
    exact: true,
    private: false,
    main: () => <CandidateRecruiterPage />,
    role: [USER_ROLE.RECRUITER, USER_ROLE.PARTNER, USER_ROLE.SHINYAMA, USER_ROLE.SHINYAMA_MANAGER]
  },
  {
    path: '/candidate-shinyama',
    exact: true,
    private: false,
    main: () => <CandidateShinyamaPage/>,
    role: [USER_ROLE.SHINYAMA, USER_ROLE.SHINYAMA_MANAGER]
  },
  {
    path: '/course-candidate',
    exact: true,
    private: false,
    main: () => <CourseCandidatePage />,
    role: [USER_ROLE.SHINYAMA, USER_ROLE.SHINYAMA_MANAGER]
  },
];
