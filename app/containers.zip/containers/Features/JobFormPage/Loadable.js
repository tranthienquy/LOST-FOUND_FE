/**
 *
 * Asynchronously loads the component for JobFormPage
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
