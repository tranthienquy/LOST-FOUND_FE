import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the jobFormPage state domain
 */

const selectJobFormPageDomain = state => state.jobFormPage || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by JobFormPage
 */

const makeSelectJobFormPage = () =>
  createSelector(
    selectJobFormPageDomain,
    substate => substate,
  );

export default makeSelectJobFormPage;
export { selectJobFormPageDomain };
