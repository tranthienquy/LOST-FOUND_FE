/*
 *
 * JobFormPage actions
 *
 */

import { DEFAULT_ACTION, END_OF_ACTION,
  GET_PROFESSION,
  GET_PROFESSION_FAILED,
  GET_PROFESSION_SUCCESS, 
  GET_SKILL,
  GET_SKILL_SUCCESS,
  GET_SKILL_FAILED,
  GET_LOCATION,
  GET_LOCATION_FAILED,
  GET_LOCATION_SUCCESS,
  GET_CONTENT,
  GET_CONTENT_SUCCESS,
  GET_CONTENT_FAILED,
  GET_COMPANY,
  GET_COMPANY_SUCCESS,
  GET_COMPANY_FAILED,
  SUBMIT_CONTENT,
  SUBMIT_CONTENT_FAILED,
  SUBMIT_CONTENT_SUCCESS

} from './constants';

export function defaultAction() {
  return {
    type: DEFAULT_ACTION,
  };
}
export const endOfAction = () => {
  return {
    type: END_OF_ACTION,
  };
};
export const getProfessionList = (content = '') => {
  return {
    type: GET_PROFESSION,
    content,
  };
};
export const getProfessionListSuccess = data => {
  return {
    type: GET_PROFESSION_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getProfessionListFailed = () => {
  return {
    type: GET_PROFESSION_FAILED,
  };
};
export const getSkillList = (content = '') => {
  return {
    type: GET_SKILL,
    content,
  };
};
export const getSkillListSuccess = data => {
  return {
    type: GET_SKILL_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getSkillListFailed = () => {
  return {
    type: GET_SKILL_FAILED,
  };
};
export const getLocationList = () => {
  return {
    type: GET_LOCATION,
  };
};
export const getLocationListSuccess = data => {
  return {
    type: GET_LOCATION_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getLocationListFailed = () => {
  return {
    type: GET_LOCATION_FAILED,
  };
};

export const getContent = id => {
  return {
    type: GET_CONTENT,
    id,
  };
};
export const getContentSuccess = data => {
  return {
    type: GET_CONTENT_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getContentFailed = error => {
  return {
    type: GET_CONTENT_FAILED,
    error,
  };
};

export const getCompany = id => {
  return {
    type: GET_COMPANY,
    id,
  };
};
export const getCompanySuccess = data => {
  return {
    type: GET_COMPANY_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getCompanyFailed = error => {
  return {
    type: GET_COMPANY_FAILED,
    error,
  };
};


export const submitContent = value => {
  return {
    type: SUBMIT_CONTENT,
    value,
  };
};
export const submitContentSuccess = data => {
  return {
    type: SUBMIT_CONTENT_SUCCESS,
    payload: {
      data,
    },
  };
};
export const submitContentFailed = error => {
  return {
    type: SUBMIT_CONTENT_FAILED,
    error,
  };
};
