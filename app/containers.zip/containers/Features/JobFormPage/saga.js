import {
  take,
  call,
  put,
  select,
  takeLatest,
  delay,
  fork,
  takeEvery,
} from 'redux-saga/effects';
import * as types from './constants';
import * as actions from './actions';
import * as api from 'utils/api';
import { KEY_VALUE } from '../../../utils/api/constants';
import { notification } from 'antd';
import { push } from 'react-router-redux';
import moment from 'moment';


function* getProfessionList() {
  yield delay(500);

  const resp = yield call(
    api.postPagination,
    `v1/KeyValues`,
    null,
    null,
    `TGroup eq ${
      KEY_VALUE.PROFESSION
    }`,
    null,
  );
  const { data, status } = resp;
  if (status == 200) {
    yield put(actions.getProfessionListSuccess(data));
  } else {
    yield put(actions.getProfessionListFailed());
  }
}

function* getSkillList({ content }) {
  if (content && content.length > 0) {
    yield delay(500);
    let searchFilter = '';
    if (typeof content == 'string') {
      // Search by TValue
      searchFilter = `contains(tolower(TValue),tolower('${encodeURIComponent(
        content,
      )}'))`;
    } else {
      // Search by TKey Array
      content.forEach(el => {
        searchFilter += `contains(tolower(TKey),tolower('${encodeURIComponent(
          el,
        )}')) or `;
      });
      searchFilter = searchFilter.slice(0, -3);
    }
    const resp = yield call(
      api.postPagination,
      `v1/KeyValues`,
      null,
      null,
      `TGroup eq ${KEY_VALUE.SKILL} and ` + searchFilter,
      null,
    );
    const { data, status } = resp;
    if (status == 200) {
      yield put(actions.getSkillListSuccess(data));
    } else {
      yield put(actions.getSkillListFailed());
    }
  }
}

function* getLocationList() {
  const resp = yield call(
    api.postPagination,
    `v1/KeyValues`,
    null,
    null,
    `TGroup eq ${KEY_VALUE.LOCATION}`,
    null,
  );
  const { data, status } = resp;
  if (status == 200) {
    yield put(actions.getLocationListSuccess(data));
  } else {
    yield put(actions.getLocationListFailed());
  }
}

function* getContent({ id }) {
  yield delay(1000);
  const resp = yield call(api.get, `v1/Jobs(${id})`);
  const { data, status } = resp;

  if (status == 200) {
    yield put(actions.getContentSuccess({ ...data.value[0] }));
    yield put(actions.getSkillList(JSON.parse(data.value[0].Skills)));
    yield put(actions.getProfessionList([data.value[0].Professions]));
  } else {
    yield put(actions.getContentFailed());
  }
}
function* submitContent({ value }) {
  const { id } = yield select(state => state.jobFormPage);

  const requestData = {
    ...value,
    DueDate: moment(value.DueDate).toDate(),
    Skills: JSON.stringify(value.Skills),
    WorkExperience: Number.parseInt(value.WorkExperience),
  };
  console.log(requestData);
  if (id) {
    const resp = yield call(api.put, `v1/Jobs(${id})`, {}, requestData);
    const { data, status } = resp;
    console.log(resp);
    if (status == 200) {
      yield delay(200);
      yield put(actions.submitContentSuccess(data));
      yield notification.open({
        message: 'Cập nhật việc làm thành công',
        type:'success',
      });
      yield put(push('/job'));
    } else {
      yield put(actions.submitContentFailed(''));
    }

  } else {
    const resp = yield call(api.post, `v1/Jobs`, {}, requestData);
    const { data, status } = resp;
    if (status == 201) {
      yield delay(200);
      yield put(actions.submitContentSuccess(data));
      yield notification.open({
        message: 'Tạo mới việc làm thành công',
        type:'success',
      });
      yield put(push('/job'));
    } else {
      yield put(actions.submitContentFailed('password-failed'));
    }
  }
}

function* getCompany({ id }) {
  yield delay(500);
  const resp = yield call(api.get, `v1/Companies(${id})`);
  const { data, status } = resp;

  if (status == 200) {
    yield put(actions.getCompanySuccess({ ...data }));
  } else {
    yield put(actions.getCompanyFailed());
  }
}
// Individual exports for testing
export default function* jobFormPageSaga() {
  // See example in containers/HomePage/saga.js
  yield takeLatest(types.GET_PROFESSION, getProfessionList);
  yield takeLatest(types.GET_SKILL, getSkillList);
  yield takeLatest(types.GET_LOCATION, getLocationList);
  yield takeLatest(types.GET_CONTENT, getContent);
  yield takeLatest(types.SUBMIT_CONTENT, submitContent);
  yield takeLatest(types.GET_COMPANY, getCompany);
}
