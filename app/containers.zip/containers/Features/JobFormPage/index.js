/**
 *
 * JobFormPage
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import makeSelectJobFormPage from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import * as actions from './actions';
import './styles.scss';
import AuthContext from '../../../utils/auth';
import { withRouter ,Link} from 'react-router-dom';
import { Button, Card, Typography, Tag, Modal, Form, Input , Select, Skeleton, DatePicker} from 'antd';
import moment from 'moment';
import JobDetailSkeleton from '../JobDetailPage/JobDetailSkeleton';
import { Helmet } from 'react-helmet';
import { LinearProgress } from '@mui/material';



class JobFormPage extends React.Component {
  componentWillMount(){
    this.props.onGetCompany(this.context.user.CompanyId);
    this.props.onGetProfessionList();

    const { id } = this.props.match.params;
    if (id) {
      this.props.onGetContent(id);
    }
  }
  componentWillReceiveProps(nextProps) {
    const { id } = nextProps.match.params;
    if (nextProps.match.params !== this.props.match.params) {
      if (id) {
        this.props.onGetContent(id);
      }
    }
  }

  componentWillUnmount() {
    this.props.onEndOfAction();
  }
  componentDidMount(){
    this.props.onGetLocationList();

  }
  onSubmit= value => {
    this.props.onSubmitContent(value)
  };

  onSubmitFailed= error => {
  };

  searchProfession = value => {
    this.props.onGetProfessionList(value);
  };
  searchSkill = value => {
    this.props.onGetSkillList(value);
  };


  onSubmitFailed = errorInfo => {};

  render() {
    const {loading, professionList, locationList, id, company, skillList , content} = this.props.jobFormPage;
    return (
      <div className="job-form-container d-flex flex-column pt-5">
        <Helmet>
          <title>{id ? "Cập nhật việc làm": "Tạo việc làm"}</title>
        </Helmet>
        <div className='d-flex '>
        <Typography.Text
          className="link-text-on-click"
          type="secondary"
          onClick={() => this.props.history.goBack()}
        >
          <i className="icon-Caret-left" /> Quay lại
        </Typography.Text>
        <Typography className='ml-2'> / {id ? `Chỉnh sửa công việc mã ${id}`:`Tạo mới công việc`}</Typography>
       
        
        </div>
        {loading.content && id ? (
          <JobDetailSkeleton />
        ) : (
        
          <Form
          name="basic"
          onFinish={this.onSubmit}
          autoComplete="off"
          layout="vertical"
          initialValues={content}
          onFinishFailed={this.onSubmitFailed}
          className="ant-general-form"
        >
       
          <div className="row">
            <div className="d-flex flex-column pr-5 col-xs-12 col-sm-12 col-md-12 col-lg-9">
              
              <Card
         size="small"
         className="card-description mt-4"
         title={
           <Typography
             style={{ fontSize: '24px' }}
             className=" text-app-primary font-weight-bold mt-2 d-flex align-items-center"
           >
             <i
               style={{ fontSize: '29px' }}
               className=" mr-2 icon-Star-outline"
             />
             THÔNG TIN CHUNG
           </Typography>
         }
       >
         
         <div class="row">
           <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
           <Form.Item
        label="Tên công việc"
        name="Title"
        rules={[{ required: true, message: 'Vui lòng nhập Tên công ty' }]}
      >
        <Input size='large' />
      </Form.Item>
           </div>
           <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
           <Form.Item
               label="Ngành nghề"
               name="Professions"
               rules={[
                 { required: true, message: 'Vui lòng nhập Ngành nghề' },
               ]}
             >
               <Select
             filterOption={(input, option) =>
              option.children
                .toLowerCase()
                .includes(input.toLowerCase())
            }
               showSearch
               
               notFoundContent={''}
               suffixIcon={<i className="icon-Caret-down h3" />}
             
               >
                 {professionList &&
                 professionList.map(item => (
                   <Select.Option
                     value={item.TKey}
                     key={`options-profession-${item.Id}`}
                   >
                    
                     {item.TValue}
                   </Select.Option>
                 ))}
               {loading.profession && (
                 <Select.Option disabled>Đang tải...</Select.Option>
               )}
               </Select>
             </Form.Item>
         </div>
         <div className="col-xs-12 col-sm-12 col-md-12 col-lg-8">
             <Form.Item
               label="Thành phố"
               name="City"

               rules={[
                 { required: true, message: 'Vui lòng nhập Thành phố' },
               ]}
             >
               <Select
                 suffixIcon={<i className="icon-Caret-down h3" />}
               maxTagCount='responsive'

               >
                    {locationList &&
                 locationList.map(item => (
                   <Select.Option
                     value={item.TKey}
                     key={`options-nationality-${item.Id}`}
                   >
                    
                     {item.TValue}
                   </Select.Option>
                 ))}
               {loading.location && (
                 <Select.Option disabled>Đang tải...</Select.Option>
               )}
               </Select>
             </Form.Item>
           </div>
           <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
           <Form.Item
        label="Địa điểm làm việc"
        name="Location"
      >
        <Input />
      </Form.Item>
           </div>
         </div>

         
       </Card>
              
           
           
              <Card
                size="small"
                className="card-description mt-4"
                title={
                  <Typography
                    style={{ fontSize: '24px' }}
                    className=" text-app-primary font-weight-bold mt-2 d-flex align-items-center"
                  >
                    <i
                      style={{ fontSize: '29px' }}
                      className=" mr-2 icon-Star-outline"
                    />
                    CÔNG VIỆC
                  </Typography>
                }
              >
                <div className="row">
                  <div className="col-xs-12 col-sm-12 col-md-12 col-lg-4">
                  <Form.Item
        label="Số năm kinh nghiệm"
        name="WorkExperience"
      >
        <Input type={"number"} min={1}/>
      </Form.Item>
                  </div>
                  <div className="col-xs-12 col-sm-12 col-md-12 col-lg-4">
             <Form.Item
               label="Ngày hết hạn tuyển dụng "
               name="DueDate"
               rules={[
                 { required: true, message: 'Vui lòng nhập Ngày hết hạn tuyển dụng' },
               ]}
             >
               <DatePicker className="w-100" />
             </Form.Item>
           </div>
           <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
             <Form.Item
               label="Kỹ năng"
               name="Skills"
               rules={[
                 { required: true, message: 'Vui lòng nhập Kỹ năng' },
               ]}
             >
               <Select
                 mode="multiple"
               onSearch={this.searchSkill}
               notFoundContent={''}
               filterOption={false}

                 suffixIcon={<i className="icon-Caret-down h3" />}
               >
                 {skillList &&
                 skillList.map(item => (
                   <Select.Option
                     value={item.TKey}
                     key={`options-skill-${item.TKey}`}
                   >
                   
                     {item.TValue}
                   </Select.Option>
                 ))}
               {loading.skill && (
                 <Select.Option disabled>Đang tải...</Select.Option>
               )}
               </Select>
             </Form.Item>
           </div>
                
                </div>
              </Card>
              <Card
                size="small"
                className="card-description mt-4"
                title={
                  <Typography
                    style={{ fontSize: '24px' }}
                    className=" text-app-primary font-weight-bold mt-2 d-flex align-items-center "
                  >
                    <i
                      style={{ fontSize: '29px' }}
                      className=" mr-2 icon-Present-outline"
                    />
                    <span className='mr-1' style={{color:'red', fontSize:15}}>*</span>
                    PHÚC LỢI
                    <i className='require-field '></i>
                  </Typography>
                }
              >
                     <Form.Item
        name="Benefits"
        rules={[{ required: true, message: 'Vui lòng nhập Phúc lợi'}]}
      >
        <Input.TextArea rows={5} />
      </Form.Item>
              </Card>
              <Card
                size="small"
                className="card-description mt-4"
                title={
                  <Typography
                    style={{ fontSize: '24px' }}
                    className=" text-app-primary font-weight-bold mt-2 d-flex align-items-center"
                  >
                    <i
                      style={{ fontSize: '29px' }}
                      className=" mr-2 icon-Book-open-outline"
                    />
                    <span className='mr-1' style={{color:'red', fontSize:15}}>*</span>

                    MÔ TẢ CÔNG VIỆC
                  </Typography>
                }
              >
                     <Form.Item
        name="Description"
        rules={[{ required: true, message: 'Vui lòng nhập Mô tả công việc'}]}
      >
        <Input.TextArea rows={5} />
      </Form.Item>
              </Card>
              <Card
                size="small"
                className="card-description mt-4"
                title={
                  <Typography
                    style={{ fontSize: '24px' }}
                    className=" text-app-primary font-weight-bold mt-2 d-flex align-items-center"
                  >
                    <i
                      style={{ fontSize: '29px' }}
                      className=" mr-2 icon-Clipboard-alt-outline"
                    />
                    <span className='mr-1' style={{color:'red', fontSize:15}}>*</span>

                    YÊU CẦU CÔNG VIỆC
                  </Typography>
                }
              >
                     <Form.Item
        name="Requirement"
        rules={[{ required: true, message: 'Vui lòng nhập Yêu cầu công việc'}]}
      >
        <Input.TextArea rows={5} />
      </Form.Item>
              </Card>

              <Form.Item className='mb-0'>
      
     <Button disabled={loading.submit}  size="large" type="primary"  htmlType="submit" className="text-center w-100 mt-3">
       <b className="w-100 text-center"> 
       {id ? "CẬP NHẬT CÔNG VIỆC": "+  TẠO MỚI CÔNG VIỆC"}
       </b>
     </Button>
     </Form.Item>
     <div style={{height:'10px'}}>
      {loading.submit ?  <LinearProgress color='success' />:""}
          </div>
            </div>
            <div className="col-xs-12 col-sm-12 col-md-12 col-lg-3">
              <Card hoverable className="company-card">
                {loading.company ? <Skeleton active/> : 
                
                <div className="d-flex flex-column">
                <img
                  src={company.Avatar ? (company.Avatar.startsWith('http')? company.Avatar: `${this.context.prefixLink}/${company.Avatar}`): require('../../../images/logo/logo-shinyama-grayscale.png') }
                  width={'100%'}
                  height={'150px'}
                  style={{ objectFit: 'cover' }}
                />
                
                <div className="p-2">
                  <Typography className="h7 font-weight-bold mb-2">
                    {' '}
                    {company.Name}
                  </Typography>
                  <Typography
                    style={{ fontSize: '12px' }}
                    className="d-flex align-items-center text-app-primary"
                  >
                    <i
                      style={{ fontSize: '17px' }}
                      className="mr-1 icon-Location"
                    />
                    {company.Location}
                  </Typography>
                  <Typography
                    style={{ fontSize: '12px' }}
                    className="d-flex align-items-center text-app-primary"
                  >
                    <i
                      style={{ fontSize: '17px' }}
                      className="mr-1 icon-Contacts"
                    />
                    {company.Size} người
                  </Typography>
                
                </div>
              </div>
                }
               
              </Card>

            </div>
          </div>
          </Form>
        )}

      </div>
    );
  }
}

JobFormPage.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  jobFormPage: makeSelectJobFormPage(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    onEndOfAction: () => {
      dispatch(actions.endOfAction());
    },
    onGetContent: id => {
      dispatch(actions.getContent(id));
    },
    onSubmitContent: value => {
      dispatch(actions.submitContent(value));
    },
    onGetCompany: id => {
      dispatch(actions.getCompany(id));
    },
    onGetProfessionList: content => {
      dispatch(actions.getProfessionList(content));
    },
    onGetSkillList: content => {
      dispatch(actions.getSkillList(content));
    },
    onGetLocationList: () => {
      dispatch(actions.getLocationList());
    },
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

const withReducer = injectReducer({ key: 'jobFormPage', reducer });
const withSaga = injectSaga({ key: 'jobFormPage', saga });
JobFormPage.contextType = AuthContext;

export default compose(
  withConnect,
  withReducer,
  withSaga,
  withRouter
)(JobFormPage);
