/*
 *
 * JobFormPage constants
 *
 */

export const DEFAULT_ACTION = 'app/JobFormPage/DEFAULT_ACTION';
export const END_OF_ACTION = 'app/JobFormPage/END_OF_ACTION';

export const GET_CONTENT = 'app/JobFormPage/GET_CONTENT';
export const GET_CONTENT_SUCCESS = 'app/JobFormPage/GET_CONTENT_SUCCESS';
export const GET_CONTENT_FAILED = 'app/JobFormPage/GET_CONTENT_FAILED';

export const GET_PROFESSION = 'app/JobFormPage/GET_PROFESSION';
export const GET_PROFESSION_SUCCESS = 'app/JobFormPage/GET_PROFESSION_SUCCESS';
export const GET_PROFESSION_FAILED = 'app/JobFormPage/GET_PROFESSION_FAILED';

export const GET_SKILL = 'app/JobFormPage/GET_SKILL';
export const GET_SKILL_SUCCESS = 'app/JobFormPage/GET_SKILL_SUCCESS';
export const GET_SKILL_FAILED = 'app/JobFormPage/GET_SKILL_FAILED';

export const GET_LOCATION = 'app/JobFormPage/GET_LOCATION';
export const GET_LOCATION_SUCCESS = 'app/JobFormPage/GET_LOCATION_SUCCESS';
export const GET_LOCATION_FAILED = 'app/JobFormPage/GET_LOCATION_FAILED';

export const GET_COMPANY = 'app/JobFormPage/GET_COMPANY';
export const GET_COMPANY_SUCCESS = 'app/JobFormPage/GET_COMPANY_SUCCESS';
export const GET_COMPANY_FAILED = 'app/JobFormPage/GET_COMPANY_FAILED';

export const SUBMIT_CONTENT = 'app/JobFormPage/SUBMIT_CONTENT';
export const SUBMIT_CONTENT_SUCCESS = 'app/JobFormPage/SUBMIT_CONTENT_SUCCESS';
export const SUBMIT_CONTENT_FAILED = 'app/JobFormPage/SUBMIT_CONTENT_FAILED';