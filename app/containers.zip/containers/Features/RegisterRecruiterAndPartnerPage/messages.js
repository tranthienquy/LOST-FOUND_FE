/*
 * RegisterRecruiterAndPartnerPage Messages
 *
 * This contains all the text for the RegisterRecruiterAndPartnerPage container.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.containers.RegisterRecruiterAndPartnerPage';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'This is the RegisterRecruiterAndPartnerPage container!',
  },
});
