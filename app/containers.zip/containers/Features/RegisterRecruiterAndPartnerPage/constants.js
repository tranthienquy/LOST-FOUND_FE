/*
 *
 * RegisterRecruiterAndPartnerPage constants
 *
 */

export const DEFAULT_ACTION = 'app/RegisterRecruiterAndPartnerPage/DEFAULT_ACTION';
export const REGISTER = 'app/RegisterRecruiterAndPartnerPage/REGISTER';
export const REGISTER_SUCCESS = 'app/RegisterRecruiterAndPartnerPage/REGISTER_SUCCESS';
export const REGISTER_FAILED = 'app/RegisterRecruiterAndPartnerPage/REGISTER_FAILED';
