import { take, call, put, select, takeLatest, delay } from 'redux-saga/effects';
import { push } from 'react-router-redux';
import * as types from './constants';
import * as actions from './actions';
import * as api from 'utils/api';
import { notification } from 'antd';
import FormData from 'form-data';
function* register({value, image}){

delete value.RePassword;
  const resp = yield call(
    api.post,
    `v1/Accounts/create-account/recuiter-and-partner`, {}, value
  );
  const { data, status } = resp;

  if (status == 200 ) {
   
    if (image){
      document.cookie= yield data.token;
      yield uploadAvatar(image)
    } else {
      yield notification.open({
        message:"Đăng ký thành công. Vui lòng đăng nhập!"
      })
      yield put(push('/login'));
    }
  } else {
    yield put(actions.registerFailed(data.message));
  }
}

function* uploadAvatar(image){
  let dataImage= yield new FormData();
  yield dataImage.append('file', image.originFileObj);
  const resp = yield call(
    api.post,
    `v1/Companies/update-compant-current-avatar`, {}, dataImage,{"Content-Type": "multipart/form-data" }
  );
  const { data, status } = resp;

  if (status == 200 ) {
    document.cookie= yield null;
    yield delay(2000);
    yield put(actions.registerSuccess(data));
    yield notification.open({
      message:"Đăng ký thành công. Vui lòng đăng nhập!",
      type:'success'
    })
    yield put(push('/login'));
  } else {
    yield put(actions.registerFailed());
  }
}

// Individual exports for testing
export default function* registerRecruiterAndPartnerPageSaga() {
  // See example in containers/HomePage/saga.js
  yield takeLatest(types.REGISTER, register);
  
}
