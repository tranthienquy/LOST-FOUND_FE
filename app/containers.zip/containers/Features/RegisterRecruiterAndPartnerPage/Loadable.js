/**
 *
 * Asynchronously loads the component for RegisterRecruiterAndPartnerPage
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
