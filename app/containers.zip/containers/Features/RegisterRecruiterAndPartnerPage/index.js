/**
 *
 * RegisterRecruiterAndPartnerPage
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import makeSelectRegisterRecruiterAndPartnerPage from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import './styles.scss';
import * as actions from './actions';

import { Card, Typography, Input, Button, Form, Spin, Upload, Image, Popover } from 'antd';
import { Link } from 'react-router-dom';
import { Animated } from 'react-animated-css';
import { LinearProgress } from '@mui/material';
import { getBase64 } from '../../../utils/imageUtil';


class RegisterRecruiterAndPartnerPage extends React.Component {
  constructor(props){
    super(props);
    this.state={
      image:null,
      imagePreview: null,
      imageError: false,
    }
  }
  onSubmitSearch = value => {
    this.props.onRegister(value, this.state.image);
    
  };
  onFinishFailed = errorInfo =>{

  }

  onchangeFile= async value=>{
    const base64 = await getBase64(value.file.originFileObj);
    if (base64.startsWith('data:image/')) {
    await this.setState({
      image:value.file,
      imagePreview: base64
    })
  }
  }

  deleteImage= ()=>{
    this.setState({
      image:null,
      imagePreview: null
    })
  }
  render(){
    const {loading,error}= this.props.registerRecruiterAndPartnerPage;
    const {image,imagePreview}= this.state;

     return (
      <div className="register-recruiter-container">
      <Animated className="d-flex justify-content-center align-items-center w-100"
      animationIn="fadeInUp"
                animationOut=""
                isVisible={true}
                animationInDuration={500}
                animationInDelay={0}>
        <Card className="login-card">
          <div
                
                 className="d-flex flex-column justify-content-center"
              >
            <Typography className="text-center head-title font-weight-bold mt-2 mb-5">
              ĐĂNG KÝ LÀM NHÀ TUYỂN DỤNG VÀ ĐỐI TÁC TUYỂN DỤNG
            </Typography>
            <Form
          name="basic"
          onFinish={this.onSubmitSearch}
          autoComplete="off"
          layout='vertical'
          onFinishFailed={this.onFinishFailed}
        >
        
          <div className="row w-100 mr-0 ml-0">
            <div className="row col-xs-12 col-sm-12 col-md-12 col-lg-6">
            <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12 pl-5 pr-5 pb-4" style={{height:350}}>
            {image ?  <Popover content={<Button danger onClick={this.deleteImage}>Xóa</Button>}><Image src={imagePreview} height={350 } width={'100%'} /></Popover> 
              :
              <Upload.Dragger
               customRequest={({ file, onSuccess }) => {
                setTimeout(() => {
                  onSuccess('ok');
                }, 0);
              }}
              height={'100%'} onChange={this.onchangeFile} showUploadList={false} action={''} className='drop-file-avatar'>
              <Typography className="ant-upload-text">Thêm hình ảnh</Typography>
              <i className='icon-Image-outline h1'></i>
              </Upload.Dragger>}
              </div>
              <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <Form.Item
        label="Tên công ty"
        name="CompanyName"
        rules={[{ required: true, message: 'Vui lòng nhập Tên công ty' }]}
      >
        <Input />
      </Form.Item></div>
              <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <Form.Item
        label="Địa chỉ trụ sở chính"
        name="CompanyAddress"
      >
        <Input />
      </Form.Item></div>
            </div>
            <div className="row col-xs-12 col-sm-12 col-md-12 col-lg-6">
            <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <Form.Item
        label="Tên người liên hệ"
        name="RepresentativeName"
        rules={[{ required: true, message: 'Vui lòng nhập Tên' }]}
      >
        <Input />
      </Form.Item>
         
            </div>
           
            <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <Form.Item
        label="Số điện thoại người liên hệ"
        name="Phone"
        initialValue={''}
      >
        <Input />
      </Form.Item></div>
            <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <Form.Item
        label="Chức vụ"
        name="Position"
        initialValue={''}
      >
        <Input />
      </Form.Item></div>

            <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <Form.Item
        label="Email người liên hệ"
        name="Email"
        rules={[{ required: true, message: 'Vui lòng nhập Email' }, {
          type: 'email',
          message: 'Email không đúng định dạng',
        },]}
      >
        <Input   prefix={<i className="icon-Envelope h5 login-icon" />}/>
      </Form.Item>
            </div>
            <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <Form.Item
        label="Mật khẩu"
        name="Password"
        rules={[{ required: true, message: 'Vui lòng nhập Mật khẩu' }]}
      >
        <Input type={'password'}  prefix={<i className="icon-Key h5 login-icon" />}/>
      </Form.Item>
            <Form.Item
            
        label="Nhập lại mật khẩu"
        name="RePassword"
        rules={[{ required: true, message: 'Vui lòng nhập lại mật khẩu' },
        ({ getFieldValue }) => ({
          validator(_, value) {
            if (!value || getFieldValue('Password') === value) {
              return Promise.resolve();
            }
            return Promise.reject(new Error('Mật khẩu không trùng khớp'));
          },
        }),
      ]}
      >
        <Input type={'password'}  prefix={<i className="icon-Key h5 login-icon" />}/>
      </Form.Item>
            </div>
          </div>
         
          </div>
          

         
          <Form.Item className='mb-0'>
            <Button disabled={loading}  size="large" type="primary"  htmlType="submit" className="text-center w-100 mt-3">
              <b className="w-100 text-center"> ĐĂNG KÝ</b>
            </Button>
            </Form.Item>
            <div style={{height:'10px'}}>
             {loading ?  <LinearProgress color='success' />:""}
                 </div>
            
             </Form>
             {(error && error=="Email exited") && <Typography className='text-center' style={{color:'red'}}>
             Email đã được đăng ký. Nếu bạn quên mật khẩu, <Link to="/forgot-password" className='font-weight-bold'> click vào đây</Link>
              </Typography>}   
             {(error && error=="Company exited") && <Typography className='text-center' style={{color:'red'}}>
           Công ty đã tồn tại
              </Typography>}   

            <Typography className='mt-1'>Bạn đã có tài khoản?<Link to={'login'} className="pl-2 link-text-on-click font-weight-bold">Đăng nhập ngay!</Link></Typography>
         </div>
        </Card>
      </Animated>
    </div>
  );
  }
 

 
}

RegisterRecruiterAndPartnerPage.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  registerRecruiterAndPartnerPage: makeSelectRegisterRecruiterAndPartnerPage(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    onRegister: (value, image)=>{
      dispatch(actions.register(value, image));
    }
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);


const withReducer=  injectReducer({ key: 'registerRecruiterAndPartnerPage', reducer });
const withSaga=  injectSaga({ key: 'registerRecruiterAndPartnerPage', saga });
export default compose(withConnect, withReducer, withSaga)(RegisterRecruiterAndPartnerPage);
