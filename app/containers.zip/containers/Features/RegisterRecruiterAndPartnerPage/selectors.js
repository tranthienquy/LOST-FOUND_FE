import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the registerRecruiterAndPartnerPage state domain
 */

const selectRegisterRecruiterAndPartnerPageDomain = state => state.registerRecruiterAndPartnerPage || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by RegisterRecruiterAndPartnerPage
 */

const makeSelectRegisterRecruiterAndPartnerPage = () =>
  createSelector(
    selectRegisterRecruiterAndPartnerPageDomain,
    substate => substate,
  );

export default makeSelectRegisterRecruiterAndPartnerPage;
export { selectRegisterRecruiterAndPartnerPageDomain };
