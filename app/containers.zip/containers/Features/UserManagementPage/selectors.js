import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the userManagementPage state domain
 */

const selectUserManagementPageDomain = state =>
  state.userManagementPage || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by UserManagementPage
 */

const makeSelectUserManagementPage = () =>
  createSelector(
    selectUserManagementPageDomain,
    substate => substate,
  );

export default makeSelectUserManagementPage;
export { selectUserManagementPageDomain };
