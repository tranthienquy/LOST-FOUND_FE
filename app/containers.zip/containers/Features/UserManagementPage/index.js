/**
 *
 * UserManagementPage
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import makeSelectUserManagementPage from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import * as actions from './actions';
import { Input,DatePicker, Table, Typography, Form, Button, Tabs, Select, Checkbox } from 'antd';
import { LinearProgress } from '@mui/material';
import './styles.scss';
class UserManagementPage extends React.Component {
  componentWillUnmount() {
    this.props.onEndOfAction();
  }
  formRef = React.createRef();

  columns = [
    {
      title: 'Tên',
      children: [
        {
          title: (
            <Form.Item name="LastName">
              <Input  />
            </Form.Item>
          ),
          key: 'LastName',
          dataIndex: 'LastName',
        },
      ],
    },
    {
      title: 'Họ',
      children: [
        {
          title: (
            <Form.Item name="FirstName">
              <Input  />
            </Form.Item>
          ),
          key: 'FirstName',
          dataIndex: 'FirstName',
        },
      ],
    },
    {
      title: 'Email',
      children: [
        {
          title: (
            <Form.Item name="Email">
              <Input  />
            </Form.Item>
          ),
          key: 'Email',
          dataIndex: 'Email',
        },
      ],
    },
    {
      title: 'Phân Quyền',
      children: [
        {
          title: (
            <Form.Item name="Type">
              <Select
              onChange={this.onSelectChange}
                            suffixIcon={<i className="icon-Caret-down h3" />}
                          >
                            <Select.Option value={'Online'}>
                              Online
                            </Select.Option>
                            <Select.Option value={'Offline'}>
                              Offline
                            </Select.Option>
                          </Select>
            </Form.Item>
          ),
          key: 'Course',
          dataIndex: 'Course',
          // render:(value,record)=> <span>{value.Type}</span>
        },
      ],
    },
    {
      title: 'Ngày tạo tài khoản',
      children: [
        {
          title: (
            <Form.Item name="CreatedDate">
              <DatePicker  />
            </Form.Item>
          ),
          key: 'CreatedDate',
          dataIndex: 'CreatedDate',
        },
      ],
    },
    {
      title: 'Lần cuối đăng nhập',
      children: [
        {
          title: (
            <Form.Item name="CreatedDate">
              <DatePicker  />
            </Form.Item>
          ),
          key: 'CreatedDate',
          dataIndex: 'CreatedDate',
        },
      ],
    },

    {
      title: 'Trạng Thái',
      children: [
        {
          title: (
            <Form.Item name="Status">
              <Select
              onChange={this.onSelectChange}
                            suffixIcon={<i className="icon-Caret-down h3" />}
                          >
                            <Select.Option value={'Online'}>
                              Hoạt động
                            </Select.Option>
                            <Select.Option value={'Offline'}>
                              Không hoạt động
                            </Select.Option>
                          </Select>
            </Form.Item>
          ),
          key: 'Status',
          dataIndex: 'Status',
          render: (value, record)=><span>
             <Select value={value}
              onChange={this.onSelectChange}
              
                            suffixIcon={<i className="icon-Caret-down h3" />}
                          >
                            <Select.Option value={'Online'}>
                              Hoạt động
                            </Select.Option>
                            <Select.Option value={'Offline'}>
                              Không hoạt động
                            </Select.Option>
                          </Select>
            </span>

        },
      ],
    },

  ];  
  onSubmit = value => {
    console.log(value);
    this.setState({ valueSearch: value });

    this.props.onGetContentList(value);
  };
  onSubmitFailed = errorInfo => {};
  handleTableChange = (newPagination, filters, sorter)=>{
    console.log(newPagination, filters, sorter );
    this.props.onPagination(newPagination.current, newPagination.pageSize)
    this.props.onGetContentList({...this.state.valueSearch});

} 
changeSelectValue = (event, id)=>{
  this.props.onChangeSelectValue(id, event.target.name, event.target.checked)
    }

    onSelectChange = ()=>{
      this.props.onGetContentList(this.formRef.current.getFieldsValue())
    }
  render() {
    const{userList, loading, total,current,  pageSize}= this.props.userManagementPage;
    return (
      <div className="course-candidate-request-container d-flex flex-column">
     
     <Form
       name="basic"
       onFinish={this.onSubmit}
       autoComplete="off"
       layout="vertical"
       initialValues={{}}
       onFinishFailed={this.onSubmitFailed}
       className="ant-general-form"
       ref={this.formRef} 
     >
       <div className="d-flex justify-content-between ">
         <Typography className="text-app-primary h4 font-weight-bold">
           QUẢN LÝ NGƯỜI DÙNG
         </Typography>
         <Button className='d-flex align-items-center'><i className='icon-Clipboard-alt-outline'></i> <span>Xuất Excel</span>  </Button>
        
       </div>
     
      <Button htmlType='submit'></Button>

       <Table
       loading={loading.getContent}
         className="mt-5"
         columns={this.columns}
         dataSource={userList}
         sticky={true}
         pagination={{total,current, pageSize}}
         onChange={this.handleTableChange}
         
       >
       </Table>
       <Form.Item className="mb-0">
                <Button
                  disabled={loading.submit}
                  onClick={()=>this.props.onSubmitContent()}
                  size="large"
                  type="primary"
                  htmlType="submit"
                  className="text-center w-100 mt-3"
                >
                  <b className="w-100 text-center">
                   CẬP NHẬT
                  </b>
                </Button>
              </Form.Item>
              <div style={{ height: '10px' }}>
                {loading.submit ? <LinearProgress color="success" /> : ''}
              </div>
     </Form>
   </div>
    );
  }
}

UserManagementPage.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  userManagementPage: makeSelectUserManagementPage(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    onEndOfAction: () => {
      dispatch(actions.endOfAction());
    },
    onGetContentList: content => {
      dispatch(actions.getContentList(content));
    },
    onPagination: (current, pageSize) => {
      dispatch(actions.pagination(current, pageSize));
    },
    onSubmitContent: () => {
      dispatch(actions.submitContent());
    },
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

const withReducer = injectReducer({ key: 'userManagementPage', reducer });
const withSaga = injectSaga({ key: 'userManagementPage', saga });
export default compose(
  withConnect,
  withReducer,
  withSaga,
)(UserManagementPage);
