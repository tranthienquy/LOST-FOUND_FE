/*
 *
 * UserManagementPage constants
 *
 */

export const DEFAULT_ACTION = 'app/UserManagementPage/DEFAULT_ACTION';
export const END_OF_ACTION = 'app/UserManagementPage/END_OF_ACTION';


export const GET_CONTENT = 'app/UserManagementPage/GET_CONTENT';
export const GET_CONTENT_SUCCESS = 'app/UserManagementPage/GET_CONTENT_SUCCESS';
export const GET_CONTENT_FAILED = 'app/UserManagementPage/GET_CONTENT_FAILED';
export const PAGINATION = 'app/UserManagementPage/PAGINATION';



export const SUBMIT_CONTENT = 'app/UserManagementPage/SUBMIT_CONTENT';
export const SUBMIT_CONTENT_SUCCESS = 'app/UserManagementPage/SUBMIT_CONTENT_SUCCESS';
export const SUBMIT_CONTENT_FAILED = 'app/UserManagementPage/SUBMIT_CONTENT_FAILED';


export const CHANGE_SELECT_VALUE = 'app/UserManagementPage/CHANGE_SELECT_VALUE';
