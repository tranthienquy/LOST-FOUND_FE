import { take, call, put, select, takeLatest, delay } from 'redux-saga/effects';
import * as types from './constants';
import * as actions from './actions';
import * as api from 'utils/api';

function* getContentList() {
 yield getJobList();
 yield getCourseList();
}

function* getJobList(){
  const resp = yield call(
    api.postPagination,
    `v1/Jobs`,
    1,
    10,
    null,
    { Company: { $select: 'Id,Name,Avatar' } ,
    CreateByNavigation: { $select: 'Id' } 
  },);
  const { data, status } = resp;
  if (status == 200 ) {
    yield delay(2000);
    yield put(actions.getContentListSuccess('jobs',data));
  } else {
    yield put(actions.getContentListFailed());
  }
}


// function* getJobList(){
//   const resp = yield call(
//     api.get,
//     `v1/Jobs/get-top-job-in-week`,
//    );
//   const { data, status } = resp;
//   if (status == 200 ) {
//     yield delay(2000);
//     console.log(data.map(item=>item.Job))
//     yield put(actions.getContentListSuccess('jobs',{value:data.map(item=>item.Job)}));
//   } else {
//     yield put(actions.getContentListFailed());
//   }
// }


function* getCourseList(){
  const resp = yield call(api.postPagination,`v1/Courses`, 1, 8);
  const { data, status } = resp;
  if (status == 200 ) {
    yield delay(2000);
    yield put(actions.getContentListSuccess('courses',data));
  } else {
    yield put(actions.getContentListFailed());
  }
}
// Individual exports for testing
export default function* homeMainPageSaga() {
  // See example in containers/HomePage/saga.js
  yield takeLatest(types.GET_CONTENT, getContentList);

}
