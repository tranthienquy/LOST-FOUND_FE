/**
 *
 * HomeMainPage
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import makeSelectHomeMainPage from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import './styles.scss';
import { Link } from 'react-router-dom';

import { Splide, SplideSlide } from '@splidejs/react-splide';

import { Typography, Popover, Button, Card, Tag } from 'antd';
import * as actions from './actions';

import JobListComponent from '../../../components/JobListComponent';
import CourseListComponent from '../../../components/CourseListComponent';


class HomeMainPage extends React.Component {
  componentWillMount(){
    this.props.onGetContentList();
  }
  getJobList =()=>{
   return  ['',''].map(item=>(
      <div className="col-xs-12 col-sm-12 col-md-12 col-lg-6 mt-2">
      <Card hoverable className='job-card'>
        <div className='d-flex flex-row '>
          <img src={require('../../../images/background/background-icon-1.png')} width={"30%"} height={'100px'} style={{objectFit:"cover"}}/>
          <div className='d-flex flex-column w-100 pl-2'>
          <div className='d-flex flex-row flex-wrap justify-content-between align-items-start'>
          <Link to={''} className="text-decoration-none  w-75">
          <Typography className='h5 font-weight-bold'> Technical Leader (Eng)  Technical Leader (Eng)</Typography>
          </Link>
          <Typography className='d-flex align-items-center text-app-primary' ><span>Ho Chi Minh</span> <i className='icon-Location ml-1'></i></Typography>
            
            </div>

       <Link to={''} className="text-decoration-none">
            <Typography className='company'><i className='icon-Cursor-outline mr-1'></i>HCL Vietnam Company Limited Jobs</Typography></Link>
            <Typography className='d-flex align-items-center'><span style={{fontSize:'6px'}} className="mr-1 ">&#9899;</span> Thưởng hiệu suất công việc </Typography>
            <Typography className='d-flex align-items-center'><span style={{fontSize:'6px'}} className="mr-1 ">&#9899;</span> Bảo hiểm cá nhân + gia đình</Typography>
            <Typography className='d-flex align-items-center'><span style={{fontSize:'6px'}} className="mr-1 ">&#9899;</span> 18 ngày nghỉ phép có lương</Typography>
            <div className='d-flex flex-row mt-2'>
            <Tag color="green" className='font-weight-bold'>HTML</Tag>
            </div>
          </div>
        </div>
      </Card>
    </div>
    ))
  }

  getCourseList = ()=>{
    return  ['','','',''  ].map(item=>(
      <div className="col-xs-12 col-sm-12 col-md-6 col-lg-3 mt-2">
      <Card hoverable className='course-card'>
      <div className='d-flex flex-column'>
      <img src={require('../../../images/background/background-icon-1.png')} width={"100%"} height={'150px'} style={{objectFit:"cover"}}/>
      <div className='p-2'>
      <Typography className='h7 font-weight-bold mb-2'> Khóa học chứng chỉ tiếng Nhật (N3) - Japan</Typography>
      <Typography style={{fontSize:'12px'}} className='d-flex align-items-center text-app-primary'><i style={{fontSize:'17px'}} className="mr-1 icon-Sand-watch"></i> Ngày hết hạn: 10/6/2022</Typography>
      <Typography style={{fontSize:'12px'}} className='d-flex align-items-center text-app-primary'><i style={{fontSize:'17px'}} className="mr-1 icon-Location"></i>Địa điểm: HÀ NỘI</Typography>
      <Typography style={{fontSize:'12px'}} className='d-flex align-items-center text-app-primary'><i style={{fontSize:'17px'}} className="mr-1 icon-Play"></i> Hình thức: Online</Typography>
      <Typography className='mt-3 text-app-primary font-weight-bold h5'> 15.000.000 VND</Typography>

      </div>
      </div>
      </Card>
    </div>
    ));

  }
  render() {
    const {loading,jobs, courses} = this.props.homeMainPage;
    return (
      <div className="homemain-page-container d-flex flex-column pt-5">
        <Splide
          aria-label="My Favorite Images"
          className="splide-banner"
          options={{
            perMove: 1,
            perPage: 1,
            autoplay: true,
            autoHeight: true,
            gap: '5rem',
            padding: '0rem',
            type:'loop',
            speed:'1000', interval:'3000'
          }}
        >
          <SplideSlide>
            <div className="splide-banner-item" ><img src="https://images.vietnamworks.com/logo/NCB_hrbanner.JPG_119835.jpg"/></div>
          </SplideSlide>
          <SplideSlide>
            <div className="splide-banner-item" ><img src="https://images.vietnamworks.com/logo/111c_107602.jpg"/></div>
          </SplideSlide>
          <SplideSlide>
            <div className="splide-banner-item" ><img src="https://images.vietnamworks.com/logo/HondaPremiumbanner_119779.jpg"/></div>
          </SplideSlide>
          
        </Splide>
        <div className="divider align-self-center mt-5" />
        <Typography className='text-center head-title font-weight-bold mt-2'>CÔNG VIỆC NỔI BẬT TRONG TUẦN</Typography>
          
         
          <JobListComponent loading={loading.jobs} value={jobs}/>
          <Link to={'job'} className='link-text-on-click mt-5 text-center font-weight-bold text-app-primary d-flex align-items-center justify-content-center cursor-pointer'>Xem thêm <i className='icon-Caret-down'></i>  </Link>
          <div className="divider align-self-center mt-5" />
        <Typography className='text-center head-title font-weight-bold mt-2'>KHÓA HỌC NỔI BẬT TRONG TUẦN</Typography>
           <CourseListComponent loading={loading.courses} value={courses}/>
          <Link to={'course'} className='link-text-on-click mt-5 text-center font-weight-bold text-app-primary d-flex align-items-center justify-content-center cursor-pointer'>Xem thêm <i className='icon-Caret-down'></i>  </Link>

           
  
      </div>
    );
  }
}

HomeMainPage.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  homeMainPage: makeSelectHomeMainPage(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    onGetContentList: () => {
      dispatch(actions.getContentList());
    },
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

const withReducer = injectReducer({ key: 'homeMainPage', reducer });
const withSaga = injectSaga({ key: 'homeMainPage', saga });
export default compose(
  withConnect,
  withReducer,
  withSaga,
)(HomeMainPage);
