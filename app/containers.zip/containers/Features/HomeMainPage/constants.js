/*
 *
 * HomeMainPage constants
 *
 */

export const DEFAULT_ACTION = 'app/HomeMainPage/DEFAULT_ACTION';
export const GET_CONTENT = 'app/HomeMainPage/GET_CONTENT';
export const GET_CONTENT_SUCCESS = 'app/HomeMainPage/GET_CONTENT_SUCCESS';
export const GET_CONTENT_FAILED = 'app/HomeMainPage/GET_CONTENT_FAILED';

