/**
 *
 * ProfilePage
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import makeSelectProfilePage from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import * as actions from './actions';
import {
  Button,
  Card,
  Typography,
  Tag,
  Input,
  Form,
  DatePicker,
  Select,
  Upload,
  Popover,
  Image,
  List,
  Tooltip,
  notification,
  Spin,
  Modal,
  Table
} from 'antd';
import './style.scss';
import { getBase64 } from '../../../utils/imageUtil';
import AuthContext from '../../../utils/auth';
import { LinearProgress } from '@mui/material';
import FileViewerComponent from '../../../components/FileViewerComponent';
import moment from 'moment';

class ProfilePage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      image: null,
      imagePreview: null,
      imageError: false,
      duplicateCV:false
    };
  }

  componentWillMount(){
    this.props.onGetNationalityList();
    this.props.onGetProfessionList();
    this.props.onGetProfile(this.context.user.Id);
    this.props.onGetCVList(this.context.user.Id);
    this.props.onGetRequestList(this.context.user);
  }
  componentWillUnmount() {
    this.props.onEndOfAction();
  }

  onSubmit = value => {

    this.props.onSubmitUpdate(value);
  };
  onSubmitSearch = value => {
    console.log(value);
    // this.props.onSubmitSearch(value);
  };

  onSubmitFailed = errorInfo => {};
  onchangeFile = async value => {
    console.log(value);
    const base64 = await getBase64(value.file.originFileObj);
    await console.log(base64);
    if (base64.startsWith('data:image/')) {
      await this.setState({
        image: value.file,
        imagePreview: base64,
      });
    await this.props.onUploadAvatar(value.file);

    } else{
      notification.open("Vui lòng chọn file hình ảnh");
    }
  };
  onUpCVFile = async value => {
    if (this.state.duplicateCV){
      this.props.onUploadCV(value.file)
    }
    this.setState({duplicateCV:!this.state.duplicateCV})

    // const base64 = await getBase64(value.file.originFileObj);
    // if (base64.startsWith('data:image/')) {
    //   await this.setState({
    //     image: value.file,
    //     imagePreview: base64,
    //   });
    // await this.props.onUploadAvatar(value.file);

    // } else{
    //   notification.open("Vui lòng chọn file hình ảnh");
    // }
  };
  deleteImage = () => {
    this.setState({
      image: null,
      imagePreview: null,
    });
  };
  searchProfession = value => {
    this.props.onGetProfessionList(value);
  };
  searchSkill = value => {
    this.props.onGetSkillList(value);
  };
  searchCertificate = value => {
    this.props.onGetCertificateList(value);
  };

  columns= [
    {
      title: 'Công việc',
      children: [
        {
          title: (
            <Form.Item name="Title">
              <Input />
            </Form.Item>
          ),
          key: 'Title',
          dataIndex: 'Tidtle',
        },
      ],
    },
    {
      title: 'Công ty',
      children: [
        {
          title: (
            <Form.Item name="Titale">
              <Input />
            </Form.Item>
          ),
          key: 'Title',
          dataIndex: 'Title',
        },
      ],
    },
    {
      title: 'Ngày ứng tuyển',
      children: [
        {
          title: (
            <Form.Item name="Titdle">
              <DatePicker.RangePicker />
            </Form.Item>
          ),
          key: 'Title',
          dataIndex: 'Title',
        },
      ],
    },
    {
      title: 'Trạng thái',
      children: [
        {
          title: (
            <Form.Item name="Titae">
               <Select
                 suffixIcon={<i className="icon-Caret-down h3" />}
               >
                 <Select.Option value="M">Đang xử lý</Select.Option>
                 <Select.Option value="F">Đã xử lý</Select.Option>
               </Select>
            </Form.Item>
          ),
          key: 'Title',
          dataIndex: 'Title',
        },
      ],
    },
  ]

  render() {
    const { image, imagePreview, 
    
    } = this.state;
    const {
      skillList,
      professionLoading,
      professionList,
      skillLoading,
      nationalityLoading,
      nationalityList,
      avatar,
      profile,
      profileLoading,
      certificateList,
      certificateLoading,
      submitLoading,
      avatarLoading,
      cvLoading,
      cvUploadLoading,
      cvList,
      previewModal,
      previewItem
    }= this.props.profilePage;
    return (
      <div className="profile-container">
        {profileLoading ? "Đang tải": (
   <Form
   name="basic"
   onFinish={this.onSubmit}
   autoComplete="off"
   layout="vertical"
   onFinishFailed={this.onSubmitFailed}
   className="ant-general-form"
   initialValues={profile}
 >
   <div className="row">
     <div
       className="col-xs-12 col-sm-12 col-md-12 col-lg-3 pl-5 pr-5 pb-4 pt-4 d-flex-flex-column"
       style={{ height: 350 }}
     >
       {image || avatar ? (
         <Popover
           content={
             <Upload  showUploadList={false}   onChange={this.onchangeFile}>
             <Button danger onClick={this.deleteImage}>
               Thay đổi
             </Button></Upload>
           }
         >
           <Image src={imagePreview || `${this.context.prefixLink}/${avatar}`} height={250} width={'100%'} />
         </Popover>
       ) : (
         <Upload.Dragger
           customRequest={({ file, onSuccess }) => {
             setTimeout(() => {
               onSuccess('ok');
             }, 0);
           }}
           height={'100%'}
           onChange={this.onchangeFile}
           showUploadList={false}
           action={''}
           className="drop-file-avatar"
         >
           <Typography className="ant-upload-text">
             Thêm hình ảnh
           </Typography>
           <i className="icon-Image-outline h1" />
         </Upload.Dragger>
       )}
        <Form.Item className='mb-0'>
        {avatarLoading ?  <LinearProgress color='success' />:""}
        
      <Typography className='text-center font-weight-bold h5 text-app-primary'> {profile.FirstName}  {profile.LastName}</Typography>
      <Typography className='text-center h6 text-app-primary'> {this.context.user.Email}</Typography>
     <Button disabled={submitLoading}  size="large" type="primary"  htmlType="submit" className="text-center w-100 mt-3">
       <b className="w-100 text-center"> CẬP NHẬT</b>
     </Button>
     </Form.Item>
     <div style={{height:'10px'}}>
      {submitLoading ?  <LinearProgress color='success' />:""}
          </div>
     
     
     </div>
     <div className="col-xs-12 col-sm-12 col-md-12 col-lg-9">
       <Card
         size="small"
         className="card-description mt-4"
         title={
           <Typography
             style={{ fontSize: '24px' }}
             className=" text-app-primary font-weight-bold mt-2 d-flex align-items-center"
           >
             <i
               style={{ fontSize: '29px' }}
               className=" mr-2 icon-Star-outline"
             />
             THÔNG TIN CÁ NHÂN
           </Typography>
         }
       >
         <div className="row">
         <div className="col-xs-12 col-sm-12 col-md-12 col-lg-4">
            <Form.Item
        label="Tên"
        name="LastName"
        rules={[{ required: true, message: 'Vui lòng nhập Tên' }]}
      >
        <Input />
      </Form.Item>
            </div>
            <div className="col-xs-12 col-sm-12 col-md-12 col-lg-4">
            <Form.Item
        label="Họ"
        name="FirstName"
        rules={[{ required: true, message: 'Vui lòng nhập Họ' }]}
      >
        <Input />
      </Form.Item>
      </div>
           <div className="col-xs-12 col-sm-12 col-md-12 col-lg-4">
             <Form.Item
               label="Ngày sinh"
               name="DateOfBirth"
               
             >
               <DatePicker className="w-100" />
             </Form.Item>
           </div>
           <div className="col-xs-12 col-sm-12 col-md-12 col-lg-4">
             <Form.Item
               label="Giới tính"
               name="Gender"
              
             >
               <Select
                 suffixIcon={<i className="icon-Caret-down h3" />}
               >
                 <Select.Option value="M">Nam</Select.Option>
                 <Select.Option value="F">Nữ</Select.Option>
                 <Select.Option value="O">Khác</Select.Option>
               </Select>
             </Form.Item>
           </div>
           <div className="col-xs-12 col-sm-12 col-md-12 col-lg-4">
             <Form.Item
               label="Quốc tịch"
               name="Nationality"
             
             >
               <Select
                 suffixIcon={<i className="icon-Caret-down h3" />}
               >
                    {nationalityList &&
                 nationalityList.map(item => (
                   <Select.Option
                     value={item.TKey}
                     key={`options-nationality-${item.Id}`}
                   >
                    
                     {item.TValue}
                   </Select.Option>
                 ))}
               {nationalityLoading && (
                 <Select.Option disabled>Đang tải...</Select.Option>
               )}
               </Select>
             </Form.Item>
           </div>
         </div>
       </Card>
       <Card
         size="small"
         className="card-description mt-4"
         title={
           <Typography
             style={{ fontSize: '24px' }}
             className=" text-app-primary font-weight-bold mt-2 d-flex align-items-center"
           >
             <i
               style={{ fontSize: '29px' }}
               className=" mr-2 icon-Star-outline"
             />
             CÔNG VIỆC
           </Typography>
         }
       >
         <div className="row">
           <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
             <Form.Item
               label="Ngành nghề"
               name="Profession"
               rules={[
                 { required: true, message: 'Vui lòng nhập Ngành nghề' },
               ]}
             >
               <Select
                 mode="multiple"
               showSearch
               filterOption={(input, option) =>
                option.children
                  .toLowerCase()
                  .includes(input.toLowerCase())
              }
               notFoundContent={''}
                 suffixIcon={<i className="icon-Caret-down h3" />}
               >
                 {professionList &&
                 professionList.map(item => (
                   <Select.Option
                     value={item.TKey}
                     key={`options-profession-${item.Id}`}
                   >
                    
                     {item.TValue}
                   </Select.Option>
                 ))}
             
               </Select>
             </Form.Item>
           </div>
           <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
             <Form.Item
               label="Kỹ năng"
               name="Skill"
               rules={[
                 { required: true, message: 'Vui lòng nhập Kỹ năng' },
               ]}
             >
               <Select
                 mode="multiple"
               onSearch={this.searchSkill}
               notFoundContent={''}
               filterOption={false}

                 suffixIcon={<i className="icon-Caret-down h3" />}
               >
                 {skillList &&
                 skillList.map(item => (
                   <Select.Option
                     value={item.TKey}
                     key={`options-skill-${item.TKey}`}
                   >
                   
                     {item.TValue}
                   </Select.Option>
                 ))}
               {skillLoading && (
                 <Select.Option disabled>Đang tải...</Select.Option>
               )}
               </Select>
             </Form.Item>
           </div>
         </div>
       </Card>
       <Card
         size="small"
         className="card-description mt-4"
         title={
           <Typography
             style={{ fontSize: '24px' }}
             className=" text-app-primary font-weight-bold mt-2 d-flex align-items-center"
           >
             <i
               style={{ fontSize: '29px' }}
               className=" mr-2 icon-Star-outline"
             />
             CHỨNG CHỈ
           </Typography>
         }
       >
         <div className="row">
           <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
             <Form.Item
               name="Certificate"
             
             >
               <Select
                 mode="multiple"
               filterOption={false}
               onSearch={this.searchCertificate}
               notFoundContent={''}
                 suffixIcon={<i className="icon-Caret-down h3" />}
               >
                  {certificateList &&
                 certificateList.map(item => (
                   <Select.Option
                     value={item.TKey}
                     key={`options-certificate-${item.TKey}`}
                   >
                     {item.TValue}
                   </Select.Option>
                 ))}
               {certificateLoading && (
                 <Select.Option disabled>Đang tải...</Select.Option>
               )}
               </Select>
             </Form.Item>
           </div>
         </div>
       </Card>
       <Card
         size="small"
         className="card-description mt-4"
         title={
           <Typography
             style={{ fontSize: '24px' }}
             className=" text-app-primary font-weight-bold mt-2 d-flex align-items-center"
           >
             <i
               style={{ fontSize: '29px' }}
               className=" mr-2 icon-Star-outline"
             />
             CV CỦA TÔI
           </Typography>
         }
       >
         <div>
         <Spin spinning={cvLoading} tip="Đang tải...">
           <Upload.Dragger
             customRequest={({ file, onSuccess }) => {
               setTimeout(() => {
                 onSuccess('ok');
               }, 0);
             }}
             height={'200px'}
             showUploadList={false}
             action={''}
             className="drop-file-avatar mb-4"
             onChange={this.onUpCVFile}
           >
             <Typography className="ant-upload-text">
               Tải hồ sơ của bạn tại đây
             </Typography>
             <i className="icon-Cloud-upload-outline h1 text-app-primary" />
           </Upload.Dragger>
      {cvUploadLoading ?  <LinearProgress color='success' />:""}

           <List
             dataSource={cvList}
             className="w-100"
             renderItem={item => (
               <div className="d-flex flex-row justify-content-between align-items-center cv-item">
               <Typography className="d-flex flex-row mt-2 pl-2 ">
                 <i className="icon-Document-outline mr-2 h5 " /><span>{item.Name}</span>
                 <i className='ml-2' style={{color:'#aeaeae'}}>{item.UpdatedCvdate && moment(item.UpdatedCvdate).format('DD/MM/YYYY')}</i>
               </Typography>
               <div> 
               <Tooltip placement="top" title={'Xem'}>
                   <i className="icon-Eye-outline cursor-pointer h4" onClick={()=>this.props.onPreviewModal(true, item)} />
                   </Tooltip>
               <Tooltip placement="top" title={'Tải về'} onClick={()=>{this.props.onGetCVItem(item, true)}}>
                   <i className="icon-Download-outline cursor-pointer h4" />
                   </Tooltip>
               <Tooltip placement="top" title={'Xóa'} onClick={()=>this.props.onDeleteCV(item.Id)}>
                   <i className="icon-Trash-outline cursor-pointer mr-2 h4" />
                   </Tooltip>
                   </div>
               </div>
             )}
           />
           </Spin>
         </div>
       </Card>

       <Card
         size="small"
         className="card-description mt-4"
         title={
           <Typography
             style={{ fontSize: '24px' }}
             className=" text-app-primary font-weight-bold mt-2 d-flex align-items-center"
           >
             <i
               style={{ fontSize: '29px' }}
               className=" mr-2 icon-Star-outline"
             />
             CÔNG VIỆC ĐÃ ỨNG TUYỂN
           </Typography>
         }
       >
         <Form
          name="basic"
          onFinish={this.onSubmitSearch}
          autoComplete="off"
          layout="vertical"
          initialValues={{}}
          onFinishFailed={this.onSubmitFailed}
          className="ant-general-form"
        >
       

          <Table
            className="mt-5"
            size='small'
            columns={this.columns}
            // scroll={{ x: 3000, y: 1000 }}
            // dataSource={this.dataSource}
          >
          </Table>
        </Form>
       </Card>
     </div>
   </div>
 </Form>

        ) }
     <Modal width={'80vw'} visible={previewModal} footer={''} title={previewItem && previewItem.Name}
        onCancel ={()=>this.props.onPreviewModal(false, null)}
     ><FileViewerComponent value={previewItem}
 
     /></Modal>
      </div>
    );
  }
}

ProfilePage.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  profilePage: makeSelectProfilePage(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    onEndOfAction: () => {
      dispatch(actions.endOfAction());
    },
    onGetProfile: id => {
      dispatch(actions.getProfile(id));
    },
    onGetProfessionList: () => {
      dispatch(actions.getProfessionList());
    },
    onGetSkillList: content => {
      dispatch(actions.getSkillList(content));
    },
    onGetCertificateList: content => {
      dispatch(actions.getCertificateList(content));
    },
    onGetNationalityList: () => {
      dispatch(actions.getNationality());
    },
    onGetCVList: (id) => {
      dispatch(actions.getCV(id));
    },
    onGetRequestList: (id) => {
      dispatch(actions.getRequest(id));
    },
    onSubmitUpdate: (content) => {
      dispatch(actions.submitUpdate(content));
    },
    onUploadAvatar: (image)=>{
      dispatch(actions.uploadAvatar(image))
    },
    onUploadCV: (cv)=>{
      dispatch(actions.uploadCV(cv))
    },
    onDeleteCV: (id)=>{
      dispatch(actions.deleteCV(id))
    },
    onGetCVItem: (item, isDownload)=>{
      dispatch(actions.getCVItem(item, isDownload))
    },
    onPreviewModal: (isShowing, id)=>{
      dispatch(actions.showPreviewModal(isShowing, id))
    }
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);
ProfilePage.contextType = AuthContext;

const withReducer = injectReducer({ key: 'profilePage', reducer });
const withSaga = injectSaga({ key: 'profilePage', saga });
export default compose(
  withConnect,
  withReducer,
  withSaga,
)(ProfilePage);
