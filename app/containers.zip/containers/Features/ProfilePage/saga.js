import {
  take,
  call,
  put,
  select,
  takeLatest,
  delay,
  fork,
  takeEvery,
} from 'redux-saga/effects';
import * as types from './constants';
import * as actions from './actions';
import * as api from 'utils/api';
import { API_ENDPOINT, KEY_VALUE } from '../../../utils/api/constants';
import { notification } from 'antd';
import moment from 'moment';
import { saveAs } from 'file-saver';


function* getProfessionList() {
    yield delay(500);

    const resp = yield call(
      api.postPagination,
      `v1/KeyValues`,
      null,
      null,
      `TGroup eq ${
        KEY_VALUE.PROFESSION
      }`,
      null,
    );
    const { data, status } = resp;
    if (status == 200) {
      yield put(actions.getProfessionListSuccess(data));
    } else {
      yield put(actions.getProfessionListFailed());
    }
}

function* getSkillList({ content }) {
  if (content && content.length > 0) {
    yield delay(500);
    let searchFilter = '';
    if (typeof content == 'string') {
      // Search by TValue
      searchFilter = `contains(tolower(TValue),tolower('${encodeURIComponent(
        content,
      )}'))`;
    } else {
      // Search by TKey Array
      content.forEach(el => {
        searchFilter += `contains(tolower(TKey),tolower('${encodeURIComponent(
          el,
        )}')) or `;
      });
      searchFilter = searchFilter.slice(0, -3);
    }
    const resp = yield call(
      api.postPagination,
      `v1/KeyValues`,
      null,
      null,
      `TGroup eq ${
        KEY_VALUE.SKILL
      } and `+ searchFilter,
      null,
    );
    const { data, status } = resp;
    if (status == 200) {
      yield put(actions.getSkillListSuccess(data));
    } else {
      yield put(actions.getSkillListFailed());
    }
  }
}

function* getNationalityList() {
  const resp = yield call(
    api.postPagination,
    `v1/KeyValues`,
    null,
    null,
    `TGroup eq ${KEY_VALUE.NATIONALITY}`,
    null,
  );
  const { data, status } = resp;
  if (status == 200) {
    yield put(actions.getNationalitySuccess(data));
  } else {
    yield put(actions.getNationalityFailed());
  }
}

function* getCertificateList({ content }) {
  console.log(content);
  if (content && content.length > 0) {
    yield delay(500);
    let searchFilter = '';
    if (typeof content == 'string') {
      // Search by TValue
      searchFilter = `contains(tolower(TValue),tolower('${encodeURIComponent(
        content,
      )}'))`;
    } else {
      // Search by TKey Array
      content.forEach(el => {
        searchFilter += `contains(tolower(TKey),tolower('${encodeURIComponent(
          el,
        )}')) or `;
      });
      searchFilter = searchFilter.slice(0, -3);
    }
    const resp = yield call(
      api.postPagination,
      `v1/KeyValues`,
      null,
      null,
      `TGroup eq ${KEY_VALUE.CERTIFICATE} and ` + searchFilter,
      null,
    );
 
    const { data, status } = resp;
    if (status == 200) {
      yield put(actions.getCertificateListSuccess(data));
    } else {
      yield put(actions.getCertificateListFailed());
    }
  }
}

function* getProfile({ id }) {
  const resp = yield call(api.get, `v1/UserProfiles(${id})`);
  const { data, status } = resp;

  if (status == 200) {
    yield put(actions.getProfileSuccess(data));
    yield console.log(data.value[0]);
    yield put(
      actions.getCertificateList(JSON.parse(data.value[0].Certificate)),
    );
    yield put(
      actions.getSkillList(JSON.parse(data.value[0].Skill)),
    );
    yield put(
      actions.getProfessionList(JSON.parse(data.value[0].Profession)),
    );
  } else {
    yield put(actions.getProfileFailed());
  }
}

function* submitUpdate({ content }) {
  const { id, profile } = yield select(state => state.profilePage);
  const requestData = {
    ...content,
    DateOfBirth: moment(content.DateOfBirth).toDate(),
    Profession: JSON.stringify(content.Profession),
    Skill: JSON.stringify(content.Skill),
    Certificate: JSON.stringify(content.Certificate),
   
  };
  const resp = yield call(api.put, `v1/UserProfiles(${id})`, {}, requestData);
  const { data, status } = resp;

  if (status == 200) {
    yield delay(2000);
    yield put(actions.submitUpdateSuccess(data));
    yield notification.open({
      message: 'Cập nhật hồ sơ cá nhân thành công',
      type:"success"
    });
    // yield put(push('/'));
  } else {
    yield put(actions.submitUpdateFailed('password-failed'));
  }
}

function* uploadAvatar({ image }) {
  const { id, profile } = yield select(state => state.profilePage);

  let dataImage = yield new FormData();
  yield dataImage.append('file', image.originFileObj);
  const resp = yield call(
    api.post,
    `v1/UserProfiles/update-avatar-current-profile`,
    {},
    dataImage,
    { 'Content-Type': 'multipart/form-data' },
  );
  const { data, status } = resp;

  if (status == 200) {
    yield delay(2000);
    yield put(actions.uploadAvatarSuccess(data));
    yield notification.open({
      message: 'Cập nhật ảnh thành công',
      type: 'success',
    });
  } else {
    yield put(actions.uploadAvatarFailed());
  }
}

function* uploadCV({ cv }) {
  const { profile } = yield select(state => state.profilePage);

  let dataCV = yield new FormData();
  yield dataCV.append('file', cv.originFileObj);
  const resp = yield call(api.post, `v1/Cvs/upload-profile`, {}, dataCV, {
    'Content-Type': 'multipart/form-data',
  });
  const { data, status } = resp;

  if (status == 200) {
    yield delay(2000);
    yield put(actions.uploadCVSuccess(data));
    yield notification.open({
      message: 'Tải CV thành công',
      type: 'success',
    });
    const profileId = yield select(state => state.profilePage.id);

    yield put(actions.getCV(profileId));
  } else {
    yield put(actions.uploadCVFailed(data));
  }
}

function* getCVList({ id }) {
  if (id) {
    yield delay(500);

    const resp = yield call(
      api.postPagination,
      `v1/CVs`,
      null,
      null,
      `profileId eq ${id} and Status eq 1`,
      null,
    );
    const { data, status } = resp;
    if (status == 200) {
      yield put(actions.getCVSuccess(data));
    } else {
      yield put(actions.getCVFailed());
    }
  }
}

function* deleteCV({ id }) {
  const { profile } = yield select(state => state.profilePage);

  if (id) {
    yield delay(500);

    const resp = yield call(api.del, `v1/CVs(${id})`);
    const { data, status } = resp;
    if (status == 204) {
      yield put(actions.deleteCVSuccess(data));
      yield notification.open({
        message: 'Xóa CV thành công',
        type: 'success',
      });
      const profileId = yield select(state => state.profilePage.id);

      yield put(actions.getCV(profileId));
    } else {
      yield put(actions.deleteCVFailed());
    }
  }
}
function* getCVItem({ item , isDownload}) {
  if (isDownload){
    saveAs(`${API_ENDPOINT}/v1/Cvs/view/${item.Id}`, item.Name);
    return
  }
}
function* getRequest({user}) {
  const { profile } = yield select(state => state.profilePage);


  const resp = yield call(
    api.post,
    `v1/Requests/get-request`,{},
    {CandidateEmail: user.Email },
  );
  const { data, status } = resp;
  if (status == 200) {
    yield delay(500);
    yield put(actions.getRequestSuccess(data));
  } else {
    yield put(actions.getRequestFailed());
  }
}

// Individual exports for testing
export default function* profilePageSaga() {
  // See example in containers/HomePage/saga.js
  yield takeLatest(types.GET_PROFESSION, getProfessionList);
  yield takeLatest(types.GET_SKILL, getSkillList);
  yield takeLatest(types.GET_CERTIFICATE, getCertificateList);
  yield takeLatest(types.GET_NATIONALITY, getNationalityList);
  yield takeLatest(types.GET_PROFILE, getProfile);
  yield takeLatest(types.SUBMIT_UPDATE, submitUpdate);
  yield takeLatest(types.UPLOAD_AVATAR, uploadAvatar);
  yield takeLatest(types.UPLOAD_CV, uploadCV);
  yield takeLatest(types.GET_CV, getCVList);
  yield takeLatest(types.GET_CV_ITEM, getCVItem);
  yield takeLatest(types.DELETE_CV, deleteCV);
  yield takeLatest(types.GET_REQUEST, getRequest);
}
