/*
 *
 * ProfilePage constants
 *
 */

export const DEFAULT_ACTION = 'app/ProfilePage/DEFAULT_ACTION';
export const END_OF_ACTION = 'app/ProfilePage/END_OF_ACTION';



export const GET_PROFESSION = 'app/ProfilePage/GET_PROFESSION';
export const GET_PROFESSION_SUCCESS = 'app/ProfilePage/GET_PROFESSION_SUCCESS';
export const GET_PROFESSION_FAILED = 'app/ProfilePage/GET_PROFESSION_FAILED';

export const GET_SKILL = 'app/ProfilePage/GET_SKILL';
export const GET_SKILL_SUCCESS = 'app/ProfilePage/GET_SKILL_SUCCESS';
export const GET_SKILL_FAILED = 'app/ProfilePage/GET_SKILL_FAILED';

export const GET_CERTIFICATE = 'app/ProfilePage/GET_CERTIFICATE';
export const GET_CERTIFICATE_SUCCESS = 'app/ProfilePage/GET_CERTIFICATE_SUCCESS';
export const GET_CERTIFICATE_FAILED = 'app/ProfilePage/GET_CERTIFICATE_FAILED';

export const GET_NATIONALITY = 'app/ProfilePage/GET_NATIONALITY';
export const GET_NATIONALITY_SUCCESS = 'app/ProfilePage/GET_NATIONALITY_SUCCESS';
export const GET_NATIONALITY_FAILED = 'app/ProfilePage/GET_NATIONALITY_FAILED';

export const GET_PROFILE = 'app/ProfilePage/GET_PROFILE';
export const GET_PROFILE_SUCCESS = 'app/ProfilePage/GET_PROFILE_SUCCESS';
export const GET_PROFILE_FAILED = 'app/ProfilePage/GET_PROFILE_FAILED';

export const SUBMIT_UPDATE = 'app/ProfilePage/SUBMIT_UPDATE';
export const SUBMIT_UPDATE_SUCCESS = 'app/ProfilePage/SUBMIT_UPDATE_SUCCESS';
export const SUBMIT_UPDATE_FAILED = 'app/ProfilePage/SUBMIT_UPDATE_FAILED';

export const GET_CV = 'app/ProfilePage/GET_CV';
export const GET_CV_SUCCESS = 'app/ProfilePage/GET_CV_SUCCESS';
export const GET_CV_FAILED = 'app/ProfilePage/GET_CV_FAILED';

export const GET_CV_ITEM = 'app/ProfilePage/GET_CV_ITEM';
export const GET_CV_ITEM_SUCCESS = 'app/ProfilePage/GET_CV_ITEM_SUCCESS';
export const GET_CV_ITEM_FAILED = 'app/ProfilePage/GET_CV_ITEM_FAILED';

export const DELETE_CV = 'app/ProfilePage/DELETE_CV';
export const DELETE_CV_SUCCESS = 'app/ProfilePage/DELETE_CV_SUCCESS';
export const DELETE_CV_FAILED = 'app/ProfilePage/DELETE_CV_FAILED';

export const UPLOAD_CV = 'app/ProfilePage/UPLOAD_CV';
export const UPLOAD_CV_SUCCESS = 'app/ProfilePage/UPLOAD_CV_SUCCESS';
export const UPLOAD_CV_FAILED = 'app/ProfilePage/UPLOAD_CV_FAILED';

export const UPLOAD_AVATAR = 'app/ProfilePage/UPLOAD_AVATAR';
export const UPLOAD_AVATAR_SUCCESS = 'app/ProfilePage/UPLOAD_AVATAR_SUCCESS';
export const UPLOAD_AVATAR_FAILED = 'app/ProfilePage/UPLOAD_AVATAR_FAILED';

export const GET_REQUEST = 'app/ProfilePage/GET_REQUEST';
export const GET_REQUEST_SUCCESS = 'app/ProfilePage/GET_REQUEST_SUCCESS';
export const GET_REQUEST_FAILED = 'app/ProfilePage/GET_REQUEST_FAILED';

export const OPEN_PREVIEW_MODAL = 'app/ProfilePage/OPEN_PREVIEW_MODAL';

export const SHOW_CV = 'app/ProfilePage/SHOW_CV';
