/*
 *
 * ProfilePage reducer
 *
 */
import produce from 'immer';
import * as types from './constants';
import moment from 'moment';

export const initialState = {
  id: null,
  profile: null,
  professionList: [],
  skillList: [],
  nationalityList: [],
  certificateList: [],
  requestList: [],
  cvList: [],
  avatar: null,
  professionLoading: false,
  skillLoading: false,
  nationalityLoading: false,
  profileLoading: true,
  certificateLoading: false,
  submitLoading: false,
  cvUploadLoading: false,
  cvLoading: false,
  avatarLoading: false,
  cvitem: null,
  isDownload:false,
  requestLoading: false,
  modal: {
    isShowing: false,
  },
  previewModal: false,
  previewItem: null
};

/* eslint-disable default-case, no-param-reassign */
const profilePageReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case types.DEFAULT_ACTION:
        break;
      case types.END_OF_ACTION:
        for (var element in draft) {
          draft[element] = initialState[element];
        }
        break;
      case types.GET_PROFILE:
        draft.profileLoading = action.id ? true : false;
        draft.id = action.id;
        draft.profile = null;
        break;
      case types.GET_PROFILE_SUCCESS:
        draft.profileLoading = false;
        const {
          FirstName,
          LastName,
          DateOfBirth,
          Gender,
          Nationality,
          Profession,
          Skill,
          Certificate,
          AvtLink
        } = action.payload.data.value[0];
        draft.profile = {
          FirstName,
          LastName,
          DateOfBirth: DateOfBirth ? moment(DateOfBirth): "",
          Gender,
         Nationality,
          Profession: Profession ? JSON.parse(Profession) : [],
          Skill: Skill ?  JSON.parse(Skill): [],
          Certificate: Certificate ? JSON.parse(Certificate) : [],
         AvtLink
        };
        draft.avatar = draft.profile.AvtLink
          ? `${draft.profile.AvtLink}`
          : null;
        break;
      case types.GET_PROFILE_FAILED:
        break;

      case types.GET_PROFESSION:
        draft.professionLoading = action.content ? true : false;
        if (!action.content) {
          draft.professionList = [];
        }
        break;
      case types.GET_PROFESSION_SUCCESS:
        draft.professionLoading = false;
        draft.professionList = action.payload.data.value;
        break;
      case types.GET_PROFESSION_FAILED:
        break;

      case types.GET_CERTIFICATE:
        draft.certificateLoading = action.content ? true : false;
        if (!action.content) {
          draft.certificateList = [];
        }
        break;
      case types.GET_CERTIFICATE_SUCCESS:
        draft.certificateLoading = false;
        draft.certificateList = action.payload.data.value;
        break;
      case types.GET_CERTIFICATE_FAILED:
        break;

      case types.GET_SKILL:
        draft.skillLoading = action.content ? true : false;
        if (!action.content) {
          draft.skillList = [];
        }
        break;
      case types.GET_SKILL_SUCCESS:
        draft.skillLoading = false;
        draft.skillList = action.payload.data.value;
        break;
      case types.GET_SKILL_FAILED:
        break;

      case types.GET_NATIONALITY:
        draft.nationalityLoading = action.content ? true : false;
        draft.nationalityList = [];
        break;
      case types.GET_NATIONALITY_SUCCESS:
        draft.nationalityLoading = false;
        draft.nationalityList = action.payload.data.value;
        break;
      case types.GET_NATIONALITY_FAILED:
        break;
      case types.GET_CV:
        draft.cvLoading = true;
        draft.cvList = [];
        break;
      case types.GET_CV_SUCCESS:
        draft.cvLoading = false;
        draft.cvList = action.payload.data.value;
        break;
      case types.GET_CV_FAILED:
        break;
      case types.GET_CV_ITEM:
        draft.cvitem = {id:action.id};
        draft.isDownload = action.isDownload;
        break;
      case types.GET_CV_ITEM_SUCCESS:
        draft.cvitem = action.payload.data;
        
        break;
      case types.GET_CV_ITEM_FAILED:
        break;
      case types.OPEN_PREVIEW_MODAL:
        draft.previewModal = action.isShowing
        draft.previewItem = action.item
        break;

      case types.UPLOAD_AVATAR:
        draft.avatarLoading = true;
        draft.avatar = null;
        break;
      case types.UPLOAD_AVATAR_SUCCESS:
        draft.avatarLoading = false;
        draft.avatar = action.payload.data.value;
        break;
      case types.UPLOAD_CV:
        draft.cvUploadLoading = true;
        break;
      case types.UPLOAD_CV_SUCCESS:
        draft.cvUploadLoading = false;
        break;
      case types.UPLOAD_AVATAR_FAILED:
        break;
      case types.DELETE_CV:
        draft.cvUploadLoading = true;
        break;
      case types.DELETE_CV_SUCCESS:
        draft.cvUploadLoading = false;
        break;
      case types.SUBMIT_UPDATE:
        draft.submitLoading = true;
        break;
      case types.SUBMIT_UPDATE_SUCCESS:
        draft.submitLoading = false;
        break;
      case types.GET_REQUEST:
        draft.requestLoading = false;
        break;
      case types.GET_REQUEST_SUCCESS:
        draft.requestList = action.payload.data;
        break;
    }
  });

export default profilePageReducer;
