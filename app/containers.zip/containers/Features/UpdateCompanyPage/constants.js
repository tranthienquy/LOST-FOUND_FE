/*
 *
 * UpdateCompanyPage constants
 *
 */

export const DEFAULT_ACTION = 'app/UpdateCompanyPage/DEFAULT_ACTION';
export const END_OF_ACTION = 'app/UpdateCompanyPage/END_OF_ACTION';
export const GET_CONTENT = 'app/UpdateCompanyPage/GET_CONTENT';
export const GET_CONTENT_SUCCESS = 'app/UpdateCompanyPage/GET_CONTENT_SUCCESS';
export const GET_CONTENT_FAILED = 'app/UpdateCompanyPage/GET_CONTENT_FAILED';
export const SUBMIT_CONTENT = 'app/UpdateCompanyPage/SUBMIT_CONTENT';
export const SUBMIT_CONTENT_SUCCESS = 'app/UpdateCompanyPage/SUBMIT_CONTENT_SUCCESS';
export const SUBMIT_CONTENT_FAILED = 'app/UpdateCompanyPage/SUBMIT_CONTENT_FAILED';

export const UPLOAD_AVATAR = 'app/UpdateCompanyPage/UPLOAD_AVATAR';
export const UPLOAD_AVATAR_SUCCESS = 'app/UpdateCompanyPage/UPLOAD_AVATAR_SUCCESS';
export const UPLOAD_AVATAR_FAILED = 'app/UpdateCompanyPage/UPLOAD_AVATAR_FAILED';

export const UPLOAD_SLIDE = 'app/UpdateCompanyPage/UPLOAD_SLIDE';
export const UPLOAD_SLIDE_SUCCESS = 'app/UpdateCompanyPage/UPLOAD_SLIDE_SUCCESS';
export const UPLOAD_SLIDE_FAILED = 'app/UpdateCompanyPage/UPLOAD_SLIDE_FAILED';