/**
 *
 * Asynchronously loads the component for UpdateCompanyPage
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
