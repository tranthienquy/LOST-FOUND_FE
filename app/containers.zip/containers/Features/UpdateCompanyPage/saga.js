import { take, call, put, select, takeLatest, delay } from 'redux-saga/effects';
import { push } from 'react-router-redux';
import * as types from './constants';
import * as actions from './actions';
import * as api from 'utils/api';
import { notification } from 'antd';


function* getContent({ id }) {
  yield delay(1000);
  const resp = yield call(
    api.get,
    `v1/Companies(${id})`, 
  );
  const { data, status } = resp;

  if (status == 200 ) {
      yield put(actions.getContentSuccess({...data}));
   
  } else {
    yield put(actions.getContentFailed());
  }

}

function* submitContent({value}){
  const {content,id} = yield select(state => state.updateCompanyPage);

  const resp = yield call(
    api.put,
    `v1/Companies(${content.Id})`, {}, value
  );
  const { data, status } = resp;

  if (status == 200 ) {
    yield delay(2000);
    yield put(actions.submitContentSuccess(data));
    yield notification.open({
      message:"Cập nhật hồ sơ công ty thành công",
      type:'success'
    })
    yield put(actions.getContent(content.Id));
  } else {
    yield put(actions.submitContentFailed('password-failed'));
  }
}

function* uploadAvatar({ image }) {
  let dataImage = yield new FormData();
  yield dataImage.append('file', image.originFileObj);
  const resp = yield call(
    api.put,
    `v1/Companies/update-company-current-avatar`,
    {},
    dataImage,
    { 'Content-Type': 'multipart/form-data' },
  );
  const { data, status } = resp;

  if (status == 200) {
    yield delay(2000);
    yield put(actions.uploadAvatarSuccess(data));
    yield notification.open({
      message: 'Cập nhật ảnh thành công',
      type: 'success',
    });
  } else {
    yield put(actions.uploadAvatarFailed());
  }
}
function* uploadSlide({ image }) {
  let dataImage = yield new FormData();
  yield dataImage.append('file', image.originFileObj);
  const resp = yield call(
    api.post,
    `v1/Companies/update-compant-current-avatar`,
    {},
    dataImage,
    { 'Content-Type': 'multipart/form-data' },
  );
  const { data, status } = resp;

  if (status == 200) {
    yield delay(2000);
    yield put(actions.uploadAvatarSuccess(data));
    yield notification.open({
      message: 'Cập nhật ảnh slide thành công',
      type: 'success',
    });
  } else {
    yield put(actions.uploadAvatarFailed());
  }
}
// Individual exports for testing
export default function* updateCompanyPageSaga() {
  // See example in containers/HomePage/saga.js
  yield takeLatest(types.SUBMIT_CONTENT, submitContent);
  yield takeLatest(types.GET_CONTENT, getContent);
  yield takeLatest(types.UPLOAD_AVATAR, uploadAvatar);
  yield takeLatest(types.UPLOAD_SLIDE, uploadSlide);

}
