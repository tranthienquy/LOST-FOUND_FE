import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the updateCompanyPage state domain
 */

const selectUpdateCompanyPageDomain = state =>
  state.updateCompanyPage || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by UpdateCompanyPage
 */

const makeSelectUpdateCompanyPage = () =>
  createSelector(
    selectUpdateCompanyPageDomain,
    substate => substate,
  );

export default makeSelectUpdateCompanyPage;
export { selectUpdateCompanyPageDomain };
