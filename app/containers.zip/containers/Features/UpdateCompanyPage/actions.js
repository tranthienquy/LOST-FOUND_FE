/*
 *
 * UpdateCompanyPage actions
 *
 */

import { DEFAULT_ACTION, END_OF_ACTION,
  GET_CONTENT,
  GET_CONTENT_FAILED,
  GET_CONTENT_SUCCESS,
  SUBMIT_CONTENT,
  SUBMIT_CONTENT_FAILED,
  SUBMIT_CONTENT_SUCCESS, 
  UPLOAD_AVATAR,
  UPLOAD_AVATAR_FAILED,
  UPLOAD_AVATAR_SUCCESS,
  UPLOAD_SLIDE,
  UPLOAD_SLIDE_FAILED,
  UPLOAD_SLIDE_SUCCESS} from './constants';

export function defaultAction() {
  return {
    type: DEFAULT_ACTION,
  };
}
export const endOfAction = () => {
  return {
    type: END_OF_ACTION,
  };
};

export const getContent = id => {
  return {
    type: GET_CONTENT,
    id,
  };
};
export const getContentSuccess = data => {
  return {
    type: GET_CONTENT_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getContentFailed = error => {
  return {
    type: GET_CONTENT_FAILED,
    error,
  };
};

export const submitContent = value => {
  return {
    type: SUBMIT_CONTENT,
    value,
  };
};
export const submitContentSuccess = data => {
  return {
    type: SUBMIT_CONTENT_SUCCESS,
    payload: {
      data,
    },
  };
};
export const submitContentFailed = error => {
  return {
    type: SUBMIT_CONTENT_FAILED,
    error,
  };
};

export const uploadAvatar = (image) => {
  return {
    type: UPLOAD_AVATAR,
    image
  };
};
export const uploadAvatarSuccess = (data) => {
  return {
    type: UPLOAD_AVATAR_SUCCESS,
    payload:{
      data
    }
    
  };
};
export const uploadAvatarFailed = (err) => {
  return {
    type: UPLOAD_AVATAR_FAILED,
    err
  };
};

export const uploadSlide = (image) => {
  return {
    type: UPLOAD_SLIDE,
    image
  };
};
export const uploadSlideSuccess = (data) => {
  return {
    type: UPLOAD_SLIDE_SUCCESS,
    payload:{
      data
    }
    
  };
};
export const uploadSlideFailed = (err) => {
  return {
    type: UPLOAD_SLIDE_FAILED,
    err
  };
};