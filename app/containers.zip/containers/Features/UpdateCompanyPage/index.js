/**
 *
 * UpdateCompanyPage
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import makeSelectUpdateCompanyPage from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import * as actions from './actions';
import AuthContext from '../../../utils/auth';
import './styles.scss';
import { Helmet } from 'react-helmet';
import { Button, Card, Skeleton, Typography, Form, Input, Upload, Tooltip, List, Spin, Popover, Image } from 'antd';
import { Splide, SplideSlide } from '@splidejs/react-splide';
import { LinearProgress,  } from '@mui/material';
import { getBase64 } from '../../../utils/imageUtil';

class UpdateCompanyPage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      image: null,
      imagePreview: null,
      imageError: false,
    };
  }
  componentWillUnmount() {
    this.props.onEndOfAction();
  }
  onchangeFile = async value => {
    console.log(value);
    const base64 = await getBase64(value.file.originFileObj);
    if (base64.startsWith('data:image/')) {
      await this.setState({
        image: value.file,
        imagePreview: base64,
      });
    await this.props.onUploadAvatar(value.file);

    } else{
      notification.open("Vui lòng chọn file hình ảnh");
    }
  };
  componentWillMount() {
 
    this.props.onGetContent(this.context.user.CompanyId);
  
}

onSubmitSearch = value => {
  this.props.onSubmitContent(value);
  // this.props.onChangePassword({...value, email:this.context.user.email});
};
onFinishFailed = errorInfo =>{

}
onUploadBanner = async  value =>{
console.log(value)
}

  render() {
    const { image, imagePreview, 
    } = this.state;
    const {loading,error,content, avatar}= this.props.updateCompanyPage;

    return (
      <div className='update-company-container'>
            <Helmet>
          <title>Chỉnh sửa thông tin công ty</title>
        </Helmet>
        {loading.content && content ? (
          <>
            {' '}
            <Skeleton active />
            <Skeleton active />
            <Skeleton active />
            <Skeleton active />{' '}
          </>
        ) : (
          <Form
          name="basic"
          onFinish={this.onSubmitSearch}
          autoComplete="off"
          layout='vertical'
          onFinishFailed={this.onFinishFailed}
          initialValues={content}
        >
          <React.Fragment>
            {' '}
            <div className="row">
             
             <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
             {image || avatar ? (
         <Popover
           content={
             <Upload  showUploadList={false}   onChange={this.onchangeFile}>
             <Button danger onClick={this.deleteImage}>
               Thay đổi
             </Button></Upload>
           }
         >
           <Image src={imagePreview || `${this.context.prefixLink}/${avatar}`} height={250} width={'100%'} />
         </Popover>
       ) : (
         <Upload.Dragger
           customRequest={({ file, onSuccess }) => {
             setTimeout(() => {
               onSuccess('ok');
             }, 0);
           }}
           height={'100%'}
           onChange={this.onchangeFile}
           showUploadList={false}
           action={''}
           className="drop-file-avatar"
         >
           <Typography className="ant-upload-text">
             Thêm hình ảnh
           </Typography>
           <i className="icon-Image-outline h1" />
         </Upload.Dragger>
       )}
        {loading.avatar ?  <LinearProgress color='success' />:""}
             
             </div>
             
        
              <div className="col-xs-12 col-sm-12 col-md-12 col-lg-4">
              <Form.Item
        label="Tên công ty"
        name="Name"
        rules={[{ required: true, message: 'Vui lòng nhập Tên công ty' }]}
      >
        <Input />
      </Form.Item>
            <Form.Item
        label={<Typography className='d-flex align-items-center'><i className='text-app-primary icon-Location-outline mr-2'></i>Địa chỉ trụ sở chính</Typography>}
        name="Location"
        rules={[{ required: true, message: 'Vui lòng nhập Địa chỉ trụ sở chính' }]}
      >
        <Input />
      </Form.Item>
            <Form.Item
        label={<Typography className='d-flex align-items-center'><i className='text-app-primary icon-Contacts-outline mr-2'></i>Quy mô</Typography>}

        name="Size"
      >
        <Input type="number" min={0} />
      </Form.Item>
        
              </div>
            </div>
            {/* <Splide
              aria-label="My Favorite Images"
              className="splide-banner mt-3"
              options={{
                perMove: 1,
                perPage: 1,
                autoplay: true,
                autoHeight: true,
                gap: '5rem',
                padding: '0rem',
              }}
            >
              {content.Slide &&
                JSON.parse(content.Slide).map(item => (
                  <SplideSlide>
                    <div className="splide-banner-item" >
                      <img src={item} width="100%" height={'400px'} style={{objectFit:"cover", borderRadius:10}}/>
                      </div>
                  </SplideSlide>
                ))}
            </Splide> */}

{/* <Spin spinning={false} tip="Đang tải...">
           <Upload.Dragger
             customRequest={({ file, onSuccess }) => {
               setTimeout(() => {
                 onSuccess('ok');
               }, 0);
             }}
             height={'200px'}
             showUploadList={false}
             action={''}
             className="drop-file-avatar mb-4"
             onChange={this.onUploadBanner}
           >
             <Typography className="ant-upload-text">
               Tải hình ảnh banner tại đây
             </Typography>
             <i className="icon-Cloud-upload-outline h1 text-app-primary" />
           </Upload.Dragger>
      {true ?  <LinearProgress color='success' />:""}

           <List
             dataSource={[
               { name: 'ds', kk: '333' },
               { name: 'ds', kk: '333' },
             ]}
             className="w-100"
             renderItem={item => (
               <div className="d-flex flex-row justify-content-between align-items-center cv-item">
               <Typography className="d-flex flex-row mt-2 pl-2 ">
                 <i className="icon-Document-outline mr-2 h5 " /><span>Content</span>
                 <i className='ml-2' style={{color:'#aeaeae'}}>18/6/2002</i>
               </Typography>
               <div> 
               <Tooltip placement="top" title={'Xem'}>
                   <i className="icon-Eye-outline cursor-pointer h4" />
                   </Tooltip>
               <Tooltip placement="top" title={'Tải về'}>
                   <i className="icon-Download-outline cursor-pointer h4" />
                   </Tooltip>
               <Tooltip placement="top" title={'Xóa'}>
                   <i className="icon-Trash-outline cursor-pointer mr-2 h4" />
                   </Tooltip>
                   </div>
               </div>
             )}
           />
           </Spin> */}
            <Card
              size="small"
              className="card-description mt-4"
              title={
                <Typography
                  style={{ fontSize: '24px' }}
                  className=" text-app-primary font-weight-bold mt-2 d-flex align-items-center"
                >
                  <i
                    style={{ fontSize: '29px' }}
                    className=" mr-2 icon-History-outline"
                  />
                  LỊCH SỬ
                </Typography>
              }
            >

<Form.Item
        name="History"
      >
        <Input.TextArea rows={5} />
      </Form.Item>
            </Card>
            <Card
              size="small"
              className="card-description mt-4"
              title={
                <Typography
                  style={{ fontSize: '24px' }}
                  className=" text-app-primary font-weight-bold mt-2 d-flex align-items-center"
                >
                  <i
                    style={{ fontSize: '29px' }}
                    className=" mr-2 icon-Book-open-outline"
                  />
                  TẦM NHÌN
                </Typography>
              }
            >
            <Form.Item
        name="Vision"
      >
        <Input.TextArea rows={5} />
      </Form.Item>
            </Card>
            <Card
              size="small"
              className="card-description mt-4"
              title={
                <Typography
                  style={{ fontSize: '24px' }}
                  className=" text-app-primary font-weight-bold mt-2 d-flex align-items-center"
                >
                  <i
                    style={{ fontSize: '29px' }}
                    className=" mr-2 icon-Play-outline"
                  />
                  CHIẾN LƯỢC
                </Typography>
              }
            >
             <Form.Item
        name="Strategy"
      >
        <Input.TextArea rows={5} />
      </Form.Item>
            </Card>

            <Form.Item className='mb-0'>
            <Button disabled={loading.submit}  size="large" type="primary"  htmlType="submit" className="text-center w-100 mt-3">
              <b className="w-100 text-center"> CẬP NHẬT</b>
            </Button>
            </Form.Item>
            <div style={{height:'10px'}}>
             {loading.submit ?  <LinearProgress color='success' />:""}
                 </div>
            
          
          </React.Fragment>
          </Form>
        )}
        

      </div>
    );
  }
}

UpdateCompanyPage.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  updateCompanyPage: makeSelectUpdateCompanyPage(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    onEndOfAction: () => {
      dispatch(actions.endOfAction());
    },
    onGetContent: id => {
      dispatch(actions.getContent(id));
    },
    onSubmitContent: content => {
      dispatch(actions.submitContent(content));
    },
    onUploadAvatar : content => {
      dispatch(actions.uploadAvatar(content));
    },

  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

const withReducer = injectReducer({ key: 'updateCompanyPage', reducer });
const withSaga = injectSaga({ key: 'updateCompanyPage', saga });
UpdateCompanyPage.contextType = AuthContext;

export default compose(
  withConnect,
  withReducer,
  withSaga,
)(UpdateCompanyPage);
