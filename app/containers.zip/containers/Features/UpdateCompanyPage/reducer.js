/*
 *
 * UpdateCompanyPage reducer
 *
 */
import produce from 'immer';
import * as types from './constants';

export const initialState = {
  id: null,
  loading: {
    content: true,
    submit: false,
    avatar: false
  },
  content: {},
  error: null,
  avatar:null
};

/* eslint-disable default-case, no-param-reassign */
const updateCompanyPageReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case types.DEFAULT_ACTION:
        break;
      case types.END_OF_ACTION:
        for (var element in draft) {
          draft[element] = initialState[element];
        }
        break;

      case types.GET_CONTENT:
        draft.id= action.id;
        draft.loading.content = true;
        break;
      case types.GET_CONTENT_SUCCESS:
        draft.loading.content = false;
        const {
          Name,
          Avatar,
          Id,
          Location,
          Size,
          History,
          Vision,
          Strategy,
          Slide,
          Status,
        } = action.payload.data.value[0];
        draft.content = {
           Name,
 Avatar,
           Id,
           Location,
          Size,
           History,
          Vision,
           Strategy,
          Slide,
          Status,
        };
        draft.avatar = draft.content.Avatar
        ? `${draft.content.Avatar}`
        : null;
        break;

      case types.GET_CONTENT_FAILED:
        break;
      case types.SUBMIT_CONTENT:
        draft.loading.submit = true;
        draft.id = action.value;
        break;
      case types.SUBMIT_CONTENT_SUCCESS:
        draft.loading.submit = false;

        break;
      case types.SUBMIT_CONTENT_FAILED:
        draft.loading.submit = false;
      

        break;
        case types.UPLOAD_AVATAR:
          draft.loading.avatar = true;
          draft.avatar = null;
          break;
        case types.UPLOAD_AVATAR_SUCCESS:
          draft.loading.avatar = false;
          draft.avatar = action.payload.data.value;
          break;
    }
  });

export default updateCompanyPageReducer;
