/*
 *
 * CandidateFormPage constants
 *
 */

export const DEFAULT_ACTION = 'app/CandidateFormPage/DEFAULT_ACTION';
export const END_OF_ACTION = 'app/CandidateFormPage/END_OF_ACTION';



export const GET_PROFESSION = 'app/CandidateFormPage/GET_PROFESSION';
export const GET_PROFESSION_SUCCESS = 'app/CandidateFormPage/GET_PROFESSION_SUCCESS';
export const GET_PROFESSION_FAILED = 'app/CandidateFormPage/GET_PROFESSION_FAILED';

export const GET_SKILL = 'app/CandidateFormPage/GET_SKILL';
export const GET_SKILL_SUCCESS = 'app/CandidateFormPage/GET_SKILL_SUCCESS';
export const GET_SKILL_FAILED = 'app/CandidateFormPage/GET_SKILL_FAILED';

export const GET_CERTIFICATE = 'app/CandidateFormPage/GET_CERTIFICATE';
export const GET_CERTIFICATE_SUCCESS = 'app/CandidateFormPage/GET_CERTIFICATE_SUCCESS';
export const GET_CERTIFICATE_FAILED = 'app/CandidateFormPage/GET_CERTIFICATE_FAILED';

export const GET_NATIONALITY = 'app/CandidateFormPage/GET_NATIONALITY';
export const GET_NATIONALITY_SUCCESS = 'app/CandidateFormPage/GET_NATIONALITY_SUCCESS';
export const GET_NATIONALITY_FAILED = 'app/CandidateFormPage/GET_NATIONALITY_FAILED';

export const GET_PROFILE = 'app/CandidateFormPage/GET_PROFILE';
export const GET_PROFILE_SUCCESS = 'app/CandidateFormPage/GET_PROFILE_SUCCESS';
export const GET_PROFILE_FAILED = 'app/CandidateFormPage/GET_PROFILE_FAILED';

export const SUBMIT_UPDATE = 'app/CandidateFormPage/SUBMIT_UPDATE';
export const SUBMIT_UPDATE_SUCCESS = 'app/CandidateFormPage/SUBMIT_UPDATE_SUCCESS';
export const SUBMIT_UPDATE_FAILED = 'app/CandidateFormPage/SUBMIT_UPDATE_FAILED';

export const GET_CV = 'app/CandidateFormPage/GET_CV';
export const GET_CV_SUCCESS = 'app/CandidateFormPage/GET_CV_SUCCESS';
export const GET_CV_FAILED = 'app/CandidateFormPage/GET_CV_FAILED';

export const GET_CV_ITEM = 'app/CandidateFormPage/GET_CV_ITEM';
export const GET_CV_ITEM_SUCCESS = 'app/CandidateFormPage/GET_CV_ITEM_SUCCESS';
export const GET_CV_ITEM_FAILED = 'app/CandidateFormPage/GET_CV_ITEM_FAILED';

export const DELETE_CV = 'app/CandidateFormPage/DELETE_CV';
export const DELETE_CV_SUCCESS = 'app/CandidateFormPage/DELETE_CV_SUCCESS';
export const DELETE_CV_FAILED = 'app/CandidateFormPage/DELETE_CV_FAILED';

export const UPLOAD_CV = 'app/CandidateFormPage/UPLOAD_CV';
export const UPLOAD_CV_SUCCESS = 'app/CandidateFormPage/UPLOAD_CV_SUCCESS';
export const UPLOAD_CV_FAILED = 'app/CandidateFormPage/UPLOAD_CV_FAILED';

export const UPLOAD_AVATAR = 'app/CandidateFormPage/UPLOAD_AVATAR';
export const UPLOAD_AVATAR_SUCCESS = 'app/CandidateFormPage/UPLOAD_AVATAR_SUCCESS';
export const UPLOAD_AVATAR_FAILED = 'app/CandidateFormPage/UPLOAD_AVATAR_FAILED';

export const OPEN_PREVIEW_MODAL = 'app/CandidateFormPage/OPEN_PREVIEW_MODAL';

export const SHOW_CV = 'app/CandidateFormPage/SHOW_CV';

export const UPLOAD_FILE = 'app/CandidateFormPage/UPLOAD_FILE';
export const DELETE_FILE = 'app/CandidateFormPage/DELETE_FILE';
export const CHANGE_AVATAR = 'app/CandidateFormPage/CHANGE_AVATAR';
