import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the candidateFormPage state domain
 */

const selectCandidateFormPageDomain = state => state.candidateFormPage || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by CandidateFormPage
 */

const makeSelectCandidateFormPage = () =>
  createSelector(
    selectCandidateFormPageDomain,
    substate => substate,
  );

export default makeSelectCandidateFormPage;
export { selectCandidateFormPageDomain };
