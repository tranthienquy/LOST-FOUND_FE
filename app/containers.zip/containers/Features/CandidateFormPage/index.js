/**
 *
 * CandidateFormPage
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import makeSelectCandidateFormPage from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import * as actions from './actions';
import {
  Button,
  Card,
  Typography,
  Tag,
  Input,
  Form,
  DatePicker,
  Select,
  Upload,
  Popover,
  Image,
  List,
  Tooltip,
  notification,
  Spin,
  Modal
} from 'antd';
import './style.scss';
import { getBase64 } from '../../../utils/imageUtil';
import AuthContext from '../../../utils/auth';
import { LinearProgress } from '@mui/material';
import FileViewerComponent from '../../../components/FileViewerComponent';
import { withRouter } from 'react-router-dom';
import { API_ENDPOINT } from '../../../utils/api/constants';
class CandidateFormPage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      image: null,
      imagePreview: null,
      imageError: false,
      duplicateCV:false
    };
  }


  componentWillMount(){
    this.props.onGetNationalityList();
    // this.props.onGetCompany(this.context.user.CompanyId);
    const { id } = this.props.match.params;
    if (id) {
      this.props.onGetProfile(id);
         this.props.onGetCVList(id);
    }
  }
  componentWillReceiveProps= async(nextProps) =>{
    const { id } = nextProps.match.params;
    if (nextProps.match.params !== this.props.match.params) {
      if (id) {
        this.props.onGetProfile(id);
           this.props.onGetCVList(id);
      }
    }
    if (nextProps.candidateFormPage.image != this.props.candidateFormPage.image) {
      const base64 = await getBase64(
        nextProps.candidateFormPage.image.originFileObj,
      );
      await this.setState({
        imagePreview: base64,
      });
    }
  }
  componentWillUnmount() {
    this.props.onEndOfAction();
  }

  onSubmit = value => {

    this.props.onSubmitUpdate(value);
  };

  onSubmitFailed = errorInfo => {};

  deleteImage = () => {
    this.setState({
      image: null,
      imagePreview: null,
    });
  };
  searchProfession = value => {
    this.props.onGetProfessionList(value);
  };
  searchSkill = value => {
    this.props.onGetSkillList(value);
  };
  searchCertificate = value => {
    this.props.onGetCertificateList(value);
  };

  onUpFile = async value => {
    if (this.state.duplicateCV) {
      this.props.onUploadFile(value.file);
    }
    this.setState({ duplicateCV: !this.state.duplicateCV });
  };

  downloadFile = file => {
    saveAs(file.originFileObj, file.name);
  };

  onchangeFile = async value => {
    this.setState({ duplicateAv: !this.state.duplicateAv });
    if (this.state.duplicateAv) {
      return;
    }
    const base64 = await getBase64(value.file.originFileObj);
    if (base64.startsWith('data:image/')) {
      this.props.onChangeAvatar(value.file);
    }

  };

  render() {
   
    const {
      id,
      skillList,
      professionLoading,
      professionList,
      skillLoading,
      nationalityLoading,
      nationalityList,
      avatar,
      profile,
      profileLoading,
      certificateList,
      certificateLoading,
      submitLoading,
      avatarLoading,
      cvLoading,
      cvUploadLoading,
      fileList,
      previewModal,
      previewItem,
      image,imageURL
    }= this.props.candidateFormPage;
    const { imagePreview } = this.state;

    return (
      <div className="profile-container">
        <div className="d-flex justify-content-between">
          <Typography.Text
            className="link-text-on-click"
            type="secondary"
            onClick={() => this.props.history.goBack()}
          >
            <i className="icon-Caret-left" /> Quay lại
          </Typography.Text>
        </div>

        {profileLoading ? "Đang tải": (
   <Form
   name="basic"
   onFinish={this.onSubmit}
   autoComplete="off"
   layout="vertical"
   onFinishFailed={this.onSubmitFailed}
   className="ant-general-form"
   initialValues={profile}
 >
   <div className="row">
     <div
       className="col-xs-12 col-sm-12 col-md-12 col-lg-3 pl-5 pr-5 pb-4 pt-4 d-flex-flex-column"
       style={{ height: 350 }}
     >
       {image || avatar ? (
         <Popover
           content={
             <Upload  showUploadList={false}   onChange={this.onchangeFile}>
             <Button danger>
               Thay đổi
             </Button></Upload>
           }
         >
           <Image src={imagePreview || `${this.context.prefixLink}/${avatar}`} height={250} width={'100%'} />
         </Popover>
       ) : (
         <Upload.Dragger
           customRequest={({ file, onSuccess }) => {
             setTimeout(() => {
               onSuccess('ok');
             }, 0);
           }}
           height={'100%'}
           onChange={this.onchangeFile}
           showUploadList={false}
           action={''}
           className="drop-file-avatar"
         >
           <Typography className="ant-upload-text">
             Thêm hình ảnh
           </Typography>
           <i className="icon-Image-outline h1" />
         </Upload.Dragger>
       )}
        {avatarLoading ?  <LinearProgress color='success' />:""}

 
     
     
     </div>
     <div className="col-xs-12 col-sm-12 col-md-12 col-lg-9">
       <Card
         size="small"
         className="card-description mt-4"
         title={
           <Typography
             style={{ fontSize: '24px' }}
             className=" text-app-primary font-weight-bold mt-2 d-flex align-items-center"
           >
             <i
               style={{ fontSize: '29px' }}
               className=" mr-2 icon-Star-outline"
             />
             THÔNG TIN CÁ NHÂN
           </Typography>
         }
       >
         <div className="row">
         <div className="col-xs-12 col-sm-12 col-md-12 col-lg-4">
            <Form.Item
        label="Tên"
        name="LastName"
        rules={[{ required: true, message: 'Vui lòng nhập Tên' }]}
      >
        <Input />
      </Form.Item>
            </div>
            <div className="col-xs-12 col-sm-12 col-md-12 col-lg-4">
            <Form.Item
        label="Họ"
        name="FirstName"
        rules={[{ required: true, message: 'Vui lòng nhập Họ' }]}
      >
        <Input />
      </Form.Item>
      </div>
      <div className="col-xs-12 col-sm-12 col-md-12 col-lg-4">
            <Form.Item
        label="Email"
        name="Email"
        rules={[{ required: true, message: 'Vui lòng nhập Email' }, {
          type: 'email',
          message: 'Email không đúng định dạng',
        },]}
      >
        <Input disabled={id}  prefix={<i className="icon-Envelope h5 login-icon" />}/>
      </Form.Item>
            </div>
           <div className="col-xs-12 col-sm-12 col-md-12 col-lg-4">
             <Form.Item
               label="Ngày sinh"
               name="DateOfBirth"
            
             >
               <DatePicker className="w-100" />
             </Form.Item>
           </div>
           <div className="col-xs-12 col-sm-12 col-md-12 col-lg-4">
             <Form.Item
               label="Giới tính"
               name="Gender"
             
             >
               <Select
                 suffixIcon={<i className="icon-Caret-down h3" />}
               >
                 <Select.Option value="M">Nam</Select.Option>
                 <Select.Option value="F">Nữ</Select.Option>
                 <Select.Option value="O">Khác</Select.Option>
               </Select>
             </Form.Item>
           </div>
           <div className="col-xs-12 col-sm-12 col-md-12 col-lg-4">
             <Form.Item
               label="Quốc tịch"
               name="Nationality"

             >
               <Select
                 suffixIcon={<i className="icon-Caret-down h3" />}
               >
                    {nationalityList &&
                 nationalityList.map(item => (
                   <Select.Option
                     value={item.TKey}
                     key={`options-nationality-${item.Id}`}
                   >
                    
                     {item.TValue}
                   </Select.Option>
                 ))}
               {nationalityLoading && (
                 <Select.Option disabled>Đang tải...</Select.Option>
               )}
               </Select>
             </Form.Item>
           </div>
         </div>
       </Card>
       <Card
         size="small"
         className="card-description mt-4"
         title={
           <Typography
             style={{ fontSize: '24px' }}
             className=" text-app-primary font-weight-bold mt-2 d-flex align-items-center"
           >
             <i
               style={{ fontSize: '29px' }}
               className=" mr-2 icon-Star-outline"
             />
             CÔNG VIỆC
           </Typography>
         }
       >
         <div className="row">
           <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
             <Form.Item
               label="Ngành nghề"
               name="Profession"
               rules={[
                 { required: true, message: 'Vui lòng nhập Ngành nghề' },
               ]}
             >
               <Select
                 mode="multiple"
               onSearch={this.searchProfession}
               showSearch
               filterOption={false}
               notFoundContent={''}
                 suffixIcon={<i className="icon-Caret-down h3" />}
               >
                 {professionList &&
                 professionList.map(item => (
                   <Select.Option
                     value={item.TKey}
                     key={`options-profession-${item.Id}`}
                   >
                    
                     {item.TValue}
                   </Select.Option>
                 ))}
               {professionLoading && (
                 <Select.Option disabled>Đang tải...</Select.Option>
               )}
               </Select>
             </Form.Item>
           </div>
           <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
             <Form.Item
               label="Kỹ năng"
               name="Skill"
               rules={[
                 { required: true, message: 'Vui lòng nhập Kỹ năng' },
               ]}
             >
               <Select
                 mode="multiple"
               onSearch={this.searchSkill}
               notFoundContent={''}
               filterOption={false}

                 suffixIcon={<i className="icon-Caret-down h3" />}
               >
                 {skillList &&
                 skillList.map(item => (
                   <Select.Option
                     value={item.TKey}
                     key={`options-skill-${item.TKey}`}
                   >
                   
                     {item.TValue}
                   </Select.Option>
                 ))}
               {skillLoading && (
                 <Select.Option disabled>Đang tải...</Select.Option>
               )}
               </Select>
             </Form.Item>
           </div>
         </div>
       </Card>
      
       <Card
         size="small"
         className="card-description mt-4"
         title={
           <Typography
             style={{ fontSize: '24px' }}
             className=" text-app-primary font-weight-bold mt-2 d-flex align-items-center"
           >
             <i
               style={{ fontSize: '29px' }}
               className=" mr-2 icon-Star-outline"
             />
             CV CỦA TÔI
           </Typography>
         }
       >
         <div>
         <Spin spinning={cvLoading} tip="Đang tải...">
           <Upload.Dragger
             customRequest={({ file, onSuccess }) => {
               setTimeout(() => {
                 onSuccess('ok');
               }, 0);
             }}
             height={'200px'}
             showUploadList={false}
             action={''}
             className="drop-file-avatar mb-4"
             onChange={this.onUpFile}
           >
             <Typography className="ant-upload-text">
               Tải hồ sơ của bạn tại đây
             </Typography>
             <i className="icon-Cloud-upload-outline h1 text-app-primary" />
           </Upload.Dragger>
      {cvUploadLoading ?  <LinearProgress color='success' />:""}

      <List
                  dataSource={fileList}
                  className="w-100"
                  renderItem={item => (
                    <div
                      className="d-flex flex-row justify-content-between align-items-center list-item"
                      style={{
                        backgroundColor: item.originFileObj && '#edffe6',
                      }}
                    >
                      <Typography className="d-flex flex-row mt-2 pl-2 ">
                        <i className="icon-Document-outline mr-2 h5 " />
                        <span>
                          {item.originFileObj ? item.name : item.Link}
                        </span>
                        {/* <i className='ml-2' style={{color:'#aeaeae'}}>18/6/2002</i> */}
                      </Typography>
                      <div>
                
                    <Tooltip placement="top" title={'Xem'}>
                   <i className="icon-Eye-outline cursor-pointer h4" onClick={()=>this.props.onPreviewModal(true, item)} />
                   </Tooltip>
                        <Tooltip
                          placement="top"
                          title={'Tải về'}
                          onClick={() => {
                            item.Id
                              ? window.open(
                                  `${API_ENDPOINT}/v1/Cvs/view/${item.Id}`,
                                )
                              : this.downloadFile(item);
                          }}
                        >
                          <i className="icon-Download-outline cursor-pointer h4" />
                        </Tooltip>
                        <Tooltip
                          placement="top"
                          title={'Xóa'}
                          onClick={() => this.props.onDeleteFile(item)}
                        >
                          <i className="icon-Trash-outline cursor-pointer mr-2 h4" />
                        </Tooltip>
                      </div>
                    </div>
                  )}
                />
           </Spin>
         </div>
       </Card>
       
       <Form.Item className='mb-0'>
        
        <Button disabled={submitLoading}  size="large" type="primary"  htmlType="submit" className="text-center w-100 mt-3">
          <b className="w-100 text-center"> {id?"CẬP NHẬT": "+ TẠO MỚI"}</b>
        </Button>
        <div style={{height:'10px'}}>
      {submitLoading ?  <LinearProgress color='success' />:""}
          </div>
        </Form.Item>
     </div>
   </div>
 </Form>

        ) }
     <Modal width={'80vw'} visible={previewModal} footer={''} title={previewItem && previewItem.Name}
        onCancel ={()=>this.props.onPreviewModal(false, null)}
     ><FileViewerComponent value={previewItem}
 
     /></Modal>
      </div>
    );
  }
}

CandidateFormPage.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  candidateFormPage: makeSelectCandidateFormPage(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    onEndOfAction: () => {
      dispatch(actions.endOfAction());
    },
    onGetProfile: id => {
      dispatch(actions.getProfile(id));
    },
    onGetProfessionList: content => {
      dispatch(actions.getProfessionList(content));
    },
    onGetSkillList: content => {
      dispatch(actions.getSkillList(content));
    },
    onGetCertificateList: content => {
      dispatch(actions.getCertificateList(content));
    },
    onGetNationalityList: () => {
      dispatch(actions.getNationality());
    },
    onGetCVList: (id) => {
      dispatch(actions.getCV(id));
    },
    onSubmitUpdate: (content) => {
      dispatch(actions.submitUpdate(content));
    },
    onUploadAvatar: (image)=>{
      dispatch(actions.uploadAvatar(image))
    },
  
    onGetCVItem: (item, isDownload)=>{
      dispatch(actions.getCVItem(item, isDownload))
    },
    onPreviewModal: (isShowing, id)=>{
      dispatch(actions.showPreviewModal(isShowing, id))
    },
    onChangeAvatar: image => {
      dispatch(actions.changeAvatar(image));
    },
    onUploadFile: file => {
      dispatch(actions.uploadFile(file));
    },
    onDeleteFile: file => {
      dispatch(actions.deleteFile(file));
    },
    onPreviewModal: (isShowing, id)=>{
      dispatch(actions.showPreviewModal(isShowing, id))
    }
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);
CandidateFormPage.contextType = AuthContext;

const withReducer = injectReducer({ key: 'candidateFormPage', reducer });
const withSaga = injectSaga({ key: 'candidateFormPage', saga });
export default compose(
  withConnect,
  withReducer,
  withSaga,
  withRouter
)(CandidateFormPage);
