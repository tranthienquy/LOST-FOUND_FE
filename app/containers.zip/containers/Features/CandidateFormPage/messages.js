/*
 * CandidateFormPage Messages
 *
 * This contains all the text for the CandidateFormPage container.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.containers.CandidateFormPage';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'This is the CandidateFormPage container!',
  },
});
