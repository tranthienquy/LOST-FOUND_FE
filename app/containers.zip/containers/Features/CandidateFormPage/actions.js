/*
 *
 * CandidateFormPage actions
 *
 */

import { DEFAULT_ACTION, END_OF_ACTION, GET_PROFESSION,
  GET_PROFESSION_FAILED,
  GET_PROFESSION_SUCCESS,
  GET_SKILL,
  GET_SKILL_SUCCESS,
  GET_SKILL_FAILED, 
  GET_PROFILE,
GET_PROFILE_FAILED,
GET_PROFILE_SUCCESS,
GET_NATIONALITY,
GET_NATIONALITY_SUCCESS,
GET_NATIONALITY_FAILED,
GET_CERTIFICATE,
GET_CERTIFICATE_SUCCESS,
GET_CERTIFICATE_FAILED,
GET_CV,
GET_CV_SUCCESS,
GET_CV_FAILED,
SUBMIT_UPDATE,
SUBMIT_UPDATE_SUCCESS,
SUBMIT_UPDATE_FAILED,
UPLOAD_AVATAR,
UPLOAD_AVATAR_FAILED,
UPLOAD_AVATAR_SUCCESS,
UPLOAD_CV,
UPLOAD_CV_FAILED,
UPLOAD_CV_SUCCESS,
DELETE_CV,
DELETE_CV_FAILED,
DELETE_CV_SUCCESS,
SHOW_CV,
GET_CV_ITEM,
GET_CV_ITEM_SUCCESS,
GET_CV_ITEM_FAILED,
OPEN_PREVIEW_MODAL,
UPLOAD_FILE,
DELETE_FILE,
CHANGE_AVATAR
} from './constants';

export function defaultAction() {
  return {
    type: DEFAULT_ACTION,
  };
}
export const endOfAction = () => {
  return {
    type: END_OF_ACTION,
  };
};

export const getProfessionList = (content = '') => {
  return {
    type: GET_PROFESSION,
    content,
  };
};
export const getProfessionListSuccess = data => {
  return {
    type: GET_PROFESSION_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getProfessionListFailed = () => {
  return {
    type: GET_PROFESSION_FAILED,
  };
};

export const getCertificateList = (content = '') => {
  return {
    type: GET_CERTIFICATE,
    content,
  };
};
export const getCertificateListSuccess = data => {
  return {
    type: GET_CERTIFICATE_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getCertificateListFailed = () => {
  return {
    type: GET_CERTIFICATE_FAILED,
  };
};

export const getSkillList = (content = '') => {
  return {
    type: GET_SKILL,
    content,
  };
};
export const getSkillListSuccess = data => {
  return {
    type: GET_SKILL_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getSkillListFailed = () => {
  return {
    type: GET_SKILL_FAILED,
  };
};

export const getNationality = () => {
  return {
    type: GET_NATIONALITY,
  };
};
export const getNationalitySuccess = data => {
  return {
    type: GET_NATIONALITY_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getNationalityFailed = () => {
  return {
    type: GET_NATIONALITY_FAILED,
  };
};


export const getProfile = (id) => {
  return {
    type: GET_PROFILE,
    id,
  };
};
export const getProfileSuccess = data => {
  return {
    type: GET_PROFILE_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getProfileFailed = () => {
  return {
    type: GET_PROFILE_FAILED,
  };
};

export const submitUpdate = (content) => {
  return {
    type: SUBMIT_UPDATE,
    content,
  };
};
export const submitUpdateSuccess = data => {
  return {
    type: SUBMIT_UPDATE_SUCCESS,
    payload: {
      data,
    },
  };
};
export const submitUpdateFailed = () => {
  return {
    type: SUBMIT_UPDATE_FAILED,
  };
};
export const uploadAvatar = (image) => {
  return {
    type: UPLOAD_AVATAR,
    image
  };
};
export const uploadAvatarSuccess = (data) => {
  return {
    type: UPLOAD_AVATAR_SUCCESS,
    payload:{
      data
    }
    
  };
};
export const uploadAvatarFailed = (err) => {
  return {
    type: UPLOAD_AVATAR_FAILED,
    err
  };
};
export const uploadCV = (cv) => {
  return {
    type: UPLOAD_CV,
    cv
  };
};
export const uploadCVSuccess = (data) => {
  return {
    type: UPLOAD_CV_SUCCESS,
    payload:{
      data
    }
    
  };
};
export const uploadCVFailed = (err) => {
  return {
    type: UPLOAD_CV_FAILED,
    err
  };
};
export const getCV = (id) => {
  return {
    type: GET_CV,
    id
  };
};
export const showPreviewModal = (isShowing,item) => {
  return {
    type: OPEN_PREVIEW_MODAL,
    isShowing,
    item
  };
};
export const getCVSuccess = (data) => {
  return {
    type: GET_CV_SUCCESS,
    payload:{
      data
    }
    
  };
};
export const getCVFailed = (err) => {
  return {
    type: GET_CV_FAILED,
    err
  };
};
export const getCVItem = (item, isDownload) => {
  return {
    type: GET_CV_ITEM,
    item,
isDownload
  };
};
export const getCVItemSuccess = (data) => {
  return {
    type: GET_CV_ITEM_SUCCESS,
    payload:{
      data
    }
    
  };
};
export const getCVItemFailed = (err) => {
  return {
    type: GET_CV_ITEM_FAILED,
    err
  };
};
export const deleteCV = (id) => {
  return {
    type: DELETE_CV,
    id
  };
};
export const deleteCVSuccess = (data) => {
  return {
    type: DELETE_CV_SUCCESS,
    payload:{
      data
    }
    
  };
};
export const deleteCVFailed = (err) => {
  return {
    type: DELETE_CV_FAILED,
    err
  };
};
export const showCV = (cv) => {
  return {
    type: SHOW_CV,
    cv
  };
};

export const uploadFile = file => {
  return {
    type: UPLOAD_FILE,
    file,
  };
};
export const deleteFile = file => {
  return {
    type: DELETE_FILE,
    file,
  };
};

export const changeAvatar = image => {
  return {
    type: CHANGE_AVATAR,
    image,
  };
};
