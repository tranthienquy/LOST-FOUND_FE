import { take, call, put, select, takeLatest, delay } from 'redux-saga/effects';
import * as types from './constants';
import * as actions from './actions';
import * as api from 'utils/api';
import axios from 'axios';
// Individual exports for testing
function* login({value}){

  console.log(value)
  const resp = yield call(
    api.post,
    `v1/Accounts/login`,{},
    value
  );
  const { data, status } = resp;
  if (status == 200 ) {
document.cookie= yield data.Token;

    yield delay(100);
    yield put(actions.loginSuccess(data));
    yield location.replace('/');
  } else {
    yield put(actions.loginFailed());
  }
}
function* getCurrentUser(content){
}
export default function* loginPageSaga() {
  // See example in containers/HomePage/saga.js
  yield takeLatest(types.LOGIN, login);

}
