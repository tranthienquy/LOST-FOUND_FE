/**
 *
 * LoginPage
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import makeSelectLoginPage from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import './styles.scss';
import * as actions from './actions';

import { Card, Typography, Input, Button, Form, Modal } from 'antd';
import { Link, Redirect } from 'react-router-dom';
import { Animated } from 'react-animated-css';
import { LinearProgress } from '@mui/material';
import AuthContext from '../../../utils/auth';


class LoginPage extends React.Component {
  componentWillMount(){
  }
  onSubmitSearch = value => {
    this.props.onLogin(value);
  };
  onFinishFailed = errorInfo =>{

  }


  componentWillUnmount= ()=>{
    this.props.onEndOfAction();

  }
  render() {
    const {loading, error, registerModal}= this.props.loginPage;
    // if (this.context.user !==null) return <Redirect to={{ pathname: `/` }} /> 
    return (
      <div className="login-container">
        <Animated className="d-flex justify-content-center align-items-center w-100 h-100"
        animationIn="fadeInUp"
                  animationOut=""
                  isVisible={true}
                  animationInDuration={500}
                  animationInDelay={0}>
          <Card className="login-card">
            <div
                  
                   className="d-flex flex-column justify-content-center"
                >
              <Typography className="text-center head-title font-weight-bold mt-2 mb-5">
                ĐĂNG NHẬP ĐỂ TIẾP TỤC
              </Typography>
              <Form
          name="basic"
          onFinish={this.onSubmitSearch}
          autoComplete="off"
          layout='vertical'
          onFinishFailed={this.onFinishFailed}
        >
             <Form.Item
        name="Email"
        rules={[{ required: true, message: 'Vui lòng nhập Email' }]}

        >
              <Input
                size="large"
                className=""
                placeholder="Email"
                prefix={<i className="icon-Envelope h5 login-icon" />}
              />
              </Form.Item>

              <Form.Item
        name="Password"
        rules={[{ required: true, message: 'Vui lòng nhập mật khẩu' }]}
      
        >
            
              <Input
                size="large"
                type="password"
                placeholder="Mật khẩu"
                prefix={<i className="icon-Key h5 login-icon" />}
              />

             </Form.Item>
            
              <Link to={'forgot-password'}>
                <Typography className="mt-1 text-right link-text-on-click font-weight-bold">
                  Quên mật khẩu
                </Typography>
              </Link>{' '}

              <Form.Item className='mb-0'>
              <Button disabled={loading} size="large" type="primary" htmlType='submit' className="text-center w-100 mt-3">
                <b className="w-100 text-center"> ĐĂNG NHẬP</b>
              </Button>
              </Form.Item>
             <div style={{height:'10px'}}>
             {loading &&  <LinearProgress color='success' />}
                 </div>
              {error && <Typography className='text-center' style={{color:'red'}}>Email và mật khẩu không khớp</Typography>}   
              </Form>
              <Typography className='mt-1'>Chưa có tài khoản?<span onClick={()=> this.props.onShowRegisterModal(true)} className="pl-2 link-text-on-click font-weight-bold">Đăng ký ngay!</span></Typography>
           </div>
          </Card>
        </Animated>

        <Modal centered title={<Typography className='text-center font-weight-bold '>BẠN MUỐN ĐĂNG KÝ LÀM</Typography>} visible={registerModal} 
        onCancel={()=> this.props.onShowRegisterModal(false)}
        style={{maxWidth:'1080px'}} width={'fit-content'} footer={''} >
        
        <div className="row">
          <Animated  className="col-xs-12 col-sm-12 col-md-6 col-lg-3 pl-1 pr-1  h-100 mt-2"
              animationIn="fadeIn"
              animationOut="" 
              animationInDuration={500}
              animationInDelay={200}>
            <Link to={'/register'} className='h-100'> <Card hoverable className=''>
              <i className='icon-Cv icon-register-card'></i>
              <Typography className='text-center h6 mt-2'>Ứng viên</Typography>
              </Card></Link>
          </Animated>
          <Animated  className="col-xs-12 col-sm-12 col-md-6 col-lg-3 pl-1 pr-1 h-100 mt-2"
              animationIn="fadeIn"
              animationOut="" 
              animationInDuration={500}
              animationInDelay={300}>
            <Link to={'/register-recruiter'} className='h-100'> <Card hoverable className=''>
              <i className='icon-search icon-register-card'></i>
              <Typography className='text-center h6 mt-2'>Nhà tuyển dụng</Typography>
              </Card></Link>
          </Animated>
          <Animated  className="col-xs-12 col-sm-12 col-md-6 col-lg-3 pl-1 pr-1  h-100 mt-2"
              animationIn="fadeIn"
              animationOut="" 
              animationInDuration={500}
              animationInDelay={400}>
            <Link to={'/register-partner'} className='h-100'> <Card hoverable className=''>
              <i className='icon-Candidates icon-register-card'></i>
              <Typography className='text-center h6 mt-2'>Đối tác tuyển dụng</Typography>
              </Card></Link>
          </Animated>
          <Animated  className="col-xs-12 col-sm-12 col-md-6 col-lg-3 pl-1 pr-1  h-100 mt-2"
              animationIn="fadeIn"
              animationOut="" 
              animationInDuration={500}
              animationInDelay={500}>
            <Link to={'/register-recruiter-and-partner'} className='h-100'> <Card hoverable className=''>
              <i className='icon-Candidate-Management icon-register-card text-center w-100'></i>
              <Typography className='text-center h6 mt-2'>Nhà tuyển dụng và đối tác</Typography>
              </Card></Link>
          </Animated>
     
        </div>
        
      </Modal>
      </div>
    );
  }
}

LoginPage.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  loginPage: makeSelectLoginPage(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,

    onLogin: value=>{
      dispatch(actions.login(value));
    },
    onEndOfAction: () => {
      dispatch(actions.endOfAction());
    },

    onShowRegisterModal: value=>{
      dispatch(actions.showRegisterModal(value));
    },
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);
const withReducer = injectReducer({ key: 'loginPage', reducer });
const withSaga = injectSaga({ key: 'loginPage', saga });

LoginPage.contextType = AuthContext;
export default compose(
  withConnect,
  withReducer,
  withSaga,
)(LoginPage);
