/**
 *
 * Asynchronously loads the component for ContactEditPage
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
