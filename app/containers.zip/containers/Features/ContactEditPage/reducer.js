/*
 *
 * ContactEditPage reducer
 *
 */
import produce from 'immer';
import * as types from './constants';

export const initialState = {

  content: null,
  loading: {
  
    content: false,
    submit: false,
  },
};

/* eslint-disable default-case, no-param-reassign */
const contactEditPageReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case types.DEFAULT_ACTION:
        break;
      case types.END_OF_ACTION:
        for (var element in draft) {
          draft[element] = initialState[element];
        }
        break;

        case types.GET_CONTENT:
          draft.id = action.id;
          draft.loading.content = true;
          break;
        case types.GET_CONTENT_SUCCESS:
          draft.loading.content = false;
          draft.content = {
            ...action.payload.data,
          
          
          };
          break;
          case types.GET_CONTENT_FAILED:
            break;

            case types.SUBMIT_CONTENT:
              draft.loading.submit = true;
              break;
            case types.SUBMIT_CONTENT_SUCCESS:
              draft.loading.submit = false;
      
              break;
            case types.SUBMIT_CONTENT_FAILED:
              draft.loading.submit = false;
              break;
        

    }
  });

export default contactEditPageReducer;
