import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the contactEditPage state domain
 */

const selectContactEditPageDomain = state =>
  state.contactEditPage || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by ContactEditPage
 */

const makeSelectContactEditPage = () =>
  createSelector(
    selectContactEditPageDomain,
    substate => substate,
  );

export default makeSelectContactEditPage;
export { selectContactEditPageDomain };
