/**
 *
 * ContactEditPage
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import makeSelectContactEditPage from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import * as actions from './actions';
import {
  Button,
  Card,
  Typography,
  Tag,
  Modal,
  Form,
  Input,
  Select,
  Skeleton,
  DatePicker,
  Upload,
  Popover,
  Image,
  List,
  Tooltip,
} from 'antd';
import { Helmet } from 'react-helmet';
import { LinearProgress } from '@mui/material';
import { withRouter } from 'react-router-dom';
import { getBase64 } from '../../../utils/imageUtil';
import AuthContext from '../../../utils/auth';
import { API_ENDPOINT } from '../../../utils/api/constants';
import { saveAs } from 'file-saver';
import './styles.scss';
class ContactEditPage extends React.Component {
  componentWillUnmount() {
    this.props.onEndOfAction();
  }

  componentWillMount() {
  
      this.props.onGetContent();

  }
  onchangeFile = async value => {
    this.setState({ duplicateAv: !this.state.duplicateAv });
    if (this.state.duplicateAv) {
      return;
    }
    const base64 = await getBase64(value.file.originFileObj);
    if (base64.startsWith('data:image/')) {
      this.props.onChangeAvatar(value.file);
    }
    //   await this.setState({
    //     imagePreview: base64
    //   })
  };

  onUpFile = async value => {
    if (this.state.duplicateCV) {
      this.props.onUploadFile(value.file);
    }
    this.setState({ duplicateCV: !this.state.duplicateCV });
  };

  downloadFile = file => {
    saveAs(file.originFileObj, file.name);
  };

  onSubmit = value => {
    this.props.onSubmitContent(value);
  };
  onSubmitFailed = error => {};

  render() {
    const {content, loading} =this.props.contactEditPage;
    return (
      <div className="course-detail-container d-flex flex-column pt-5">
        <Helmet>
          <title>{'Cập nhật liên hệ' }</title>
        </Helmet>
        <div className="d-flex justify-content-between">
          <Typography.Text
            className="link-text-on-click"
            type="secondary"
            onClick={() => this.props.history.goBack()}
          >
            <i className="icon-Caret-left" /> Quay lại
          </Typography.Text>
        </div>

        {loading.content? (
          <span>Đang tải....</span>
        ) : (
          <React.Fragment>
            <Form
              name="basic"
              onFinish={this.onSubmit}
              autoComplete="off"
              layout="vertical"
              initialValues={content}
              onFinishFailed={this.onSubmitFailed}
              className="ant-general-form"
            >
          

              <Card
                size="small"
                className="card-description mt-4"
                title={
                  <Typography
                    style={{ fontSize: '24px' }}
                    className=" text-app-primary font-weight-bold mt-2 d-flex align-items-center"
                  >
                    <i
                      style={{ fontSize: '29px' }}
                      className=" mr-2 icon-Checked-box-outline"
                    />
                      <span className='mr-1' style={{color:'red', fontSize:15}}>*</span>
                    VỀ CÔNG TY
                  </Typography>
                }
              >
                <Form.Item
                  name="AboutCompany"
                  rules={[
                    {
                      required: true,
                      message: 'Vui lòng nhập VỀ CÔNG TY',
                    },
                  ]}
                >
                  <Input.TextArea rows={5} />
                </Form.Item>
              </Card>
              <Card
                size="small"
                className="card-description mt-4"
                title={
                  <Typography
                    style={{ fontSize: '24px' }}
                    className=" text-app-primary font-weight-bold mt-2 d-flex align-items-center"
                  >
                    <i
                      style={{ fontSize: '29px' }}
                      className=" mr-2 icon-Book-open-outline"
                    />
                      <span className='mr-1' style={{color:'red', fontSize:15}}>*</span>

                    VĂN PHÒNG VIỆT NAM
                  </Typography>
                }
              >
                <Form.Item name="VietnamOffice">
                  <Input.TextArea rows={5} />
                </Form.Item>
              </Card>
              <Card
                size="small"
                className="card-description mt-4"
                title={
                  <Typography
                    style={{ fontSize: '24px' }}
                    className=" text-app-primary font-weight-bold mt-2 d-flex align-items-center"
                  >
                    <i
                      style={{ fontSize: '29px' }}
                      className=" mr-2 icon-Book-open-outline"
                    />
                      <span className='mr-1' style={{color:'red', fontSize:15}}>*</span>

                    VĂN PHÒNG NHẬT BẢN
                  </Typography>
                }
              >
                <Form.Item name="JapanOffice">
                  <Input.TextArea rows={5} />
                </Form.Item>
              </Card>
              <Card
                size="small"
                className="card-description mt-4"
                title={
                  <Typography
                    style={{ fontSize: '24px' }}
                    className=" text-app-primary font-weight-bold mt-2 d-flex align-items-center"
                  >
                    <i
                      style={{ fontSize: '29px' }}
                      className=" mr-2 icon-Book-open-outline"
                    />
                      <span className='mr-1' style={{color:'red', fontSize:15}}>*</span>

                    THÔNG TIN LIÊN LẠC
                  </Typography>
                }
              >
                <Form.Item name="ContactInfomation">
                  <Input.TextArea rows={5} />
                </Form.Item>
              </Card>
           

              <Form.Item className="mb-0">
                <Button
                  disabled={loading.submit}
                  size="large"
                  type="primary"
                  htmlType="submit"
                  className="text-center w-100 mt-3"
                >
                  <b className="w-100 text-center">
                  
                    { 'CẬP NHẬT THÔNG TIN' }
                  </b>
                </Button>
              </Form.Item>
              <div style={{ height: '10px' }}>
                {loading.submit ? <LinearProgress color="success" /> : ''}
              </div>
            </Form>
          </React.Fragment>
        )}
      </div>
    );
  }
}

ContactEditPage.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  contactEditPage: makeSelectContactEditPage(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    onEndOfAction: () => {
      dispatch(actions.endOfAction());
    },
    onGetContent: () => {
      dispatch(actions.getContent());
    },
    onSubmitContent: value => {
      dispatch(actions.submitContent(value));
    },
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

const withReducer = injectReducer({ key: 'contactEditPage', reducer });
const withSaga = injectSaga({ key: 'contactEditPage', saga });
export default compose(
  withConnect,
  withReducer,
  withSaga,
)(ContactEditPage);
