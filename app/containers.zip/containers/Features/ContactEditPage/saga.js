import {
  take,
  call,
  put,
  select,
  takeLatest,
  delay,
  fork,
  takeEvery,
} from 'redux-saga/effects';
import * as types from './constants';
import * as actions from './actions';
import * as api from 'utils/api';
import { KEY_VALUE } from '../../../utils/api/constants';
import { notification } from 'antd';
import moment from 'moment';
import { push } from 'react-router-redux';


function* getContent()  {
  yield delay(1000);
  const resp = yield call(api.get, `v1/ShinyamaContents/get-content`);
  const { data, status } = resp;

  if (status == 200) {
    yield put(actions.getContentSuccess({ ...data }));
  } else {
    yield put(actions.getContentFailed());
  }
}


function* submitContent({ value }) {
  const { image, id } = yield select(state => state.courseFormPage);
  const requestData = {
    ...value,
    DueDate: moment(value.DueDate).toDate(),
    StartDate: moment(value.StudyDate[0]).toDate(),
    EndDate: moment(value.StudyDate[1]).toDate(),
  };
  yield console.log(value);
  if (id) {
    const resp = yield call(api.put, `v1/Courses(${id})`, {}, requestData);
    const { data, status } = resp;

    if (status == 200) {
      yield removeFiles();
      yield uploadFiles(data.Id);
      if (image) {
        yield uploadAvatar(data.Id, image);
      }
      yield delay(2000);

      yield put(actions.submitContentSuccess(data));
      yield notification.open({
        message: id
          ? 'Cập nhật khóa học thành công'
          : 'Tạo mới khóa học thành công',
          type:"success"
      });

      yield put(push(`/course/${id}`));

    } else {
      yield put(actions.submitContentFailed('password-failed'));
    }
  } else {
    const resp = yield call(api.post, `v1/Courses`, {}, requestData);
    const { data, status } = resp;

    if (status == 200) {
      yield uploadFiles(data.Id);
      if (image) {
        yield uploadAvatar(data.Id, image);
      }
      yield delay(2000);

      yield put(actions.submitContentSuccess(data));
      yield notification.open({
        message: id
          ? 'Cập nhật khóa học thành công'
          : 'Tạo mới khóa học thành công',
      });

      yield put(push(`/course/${data.Id}`));
    } else {
      yield put(actions.submitContentFailed('password-failed'));
    }
  }
}


// Individual exports for testing
export default function* contactEditPageSaga() {
  // See example in containers/HomePage/saga.js

  yield takeLatest(types.GET_CONTENT, getContent);

  yield takeLatest(types.SUBMIT_CONTENT, submitContent);
}
