/*
 *
 * ContactEditPage constants
 *
 */

export const DEFAULT_ACTION = 'app/ContactEditPage/DEFAULT_ACTION';
export const END_OF_ACTION = 'app/ContactEditPage/END_OF_ACTION';



export const GET_CONTENT = 'app/ContactEditPage/GET_CONTENT';
export const GET_CONTENT_SUCCESS = 'app/ContactEditPage/GET_CONTENT_SUCCESS';
export const GET_CONTENT_FAILED = 'app/ContactEditPage/GET_CONTENT_FAILED';


export const SUBMIT_CONTENT = 'app/ContactEditPage/SUBMIT_CONTENT';
export const SUBMIT_CONTENT_SUCCESS = 'app/ContactEditPage/SUBMIT_CONTENT_SUCCESS';
export const SUBMIT_CONTENT_FAILED = 'app/ContactEditPage/SUBMIT_CONTENT_FAILED';