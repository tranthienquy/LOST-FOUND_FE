import {
  take,
  call,
  put,
  select,
  takeLatest,
  delay,
  fork,
  takeEvery,
} from 'redux-saga/effects';
import * as types from './constants';
import * as actions from './actions';
import * as api from 'utils/api';
import { KEY_VALUE } from '../../../utils/api/constants';
import { notification } from 'antd';
import { push } from 'react-router-redux';
import moment from 'moment';

function* getProfessionList({ content }) {
  if (content) {
    yield delay(500);
    let searchFilter = '';

    if (typeof content == 'string') {
      // Search by TValue
      searchFilter = `contains(tolower(TValue),tolower('${encodeURIComponent(
        content,
      )}'))`;
    } else {
      // Search by TKey Array
      content.forEach(el => {
        searchFilter += `contains(tolower(TKey),tolower('${encodeURIComponent(
          el,
        )}')) or `;
      });
      searchFilter = searchFilter.slice(0, -3);
    }
    const resp = yield call(
      api.postPagination,
      `v1/KeyValues`,
      null,
      null,
      `TGroup eq ${KEY_VALUE.PROFESSION} and ` + searchFilter,
      null,
    );
    const { data, status } = resp;
    if (status == 200) {
      yield put(actions.getProfessionListSuccess(data));
    } else {
      yield put(actions.getProfessionListFailed());
    }
  }
}

function* getSkillList({ content }) {
  if (content && content.length > 0) {
    yield delay(500);
    let searchFilter = '';
    if (typeof content == 'string') {
      // Search by TValue
      searchFilter = `contains(tolower(TValue),tolower('${encodeURIComponent(
        content,
      )}'))`;
    } else {
      // Search by TKey Array
      content.forEach(el => {
        searchFilter += `contains(tolower(TKey),tolower('${encodeURIComponent(
          el,
        )}')) or `;
      });
      searchFilter = searchFilter.slice(0, -3);
    }
    const resp = yield call(
      api.postPagination,
      `v1/KeyValues`,
      null,
      null,
      `TGroup eq ${KEY_VALUE.SKILL} and ` + searchFilter,
      null,
    );
    const { data, status } = resp;
    if (status == 200) {
      yield put(actions.getSkillListSuccess(data));
    } else {
      yield put(actions.getSkillListFailed());
    }
  }
}

function* getLocationList() {
  const resp = yield call(
    api.postPagination,
    `v1/KeyValues`,
    null,
    null,
    `TGroup eq ${KEY_VALUE.LOCATION}`,
    null,
  );
  const { data, status } = resp;
  if (status == 200) {
    yield put(actions.getLocationListSuccess(data));
  } else {
    yield put(actions.getLocationListFailed());
  }
}

function* getContent({ id ,userId}) {
  yield delay(1000);
  const resp = yield call(api.get, `v1/Requests(${id})?$expand=FileStorages(filter = status ne 0),RequestAssignments(filter=ProfileId eq ${userId})`);
  const { data, status } = resp;

  if (status == 200) {
    yield put(actions.getContentSuccess({ ...data }));
    yield put(actions.getSkillList(data.Skills));
    yield put(actions.getProfessionList([data.Professions]));
  } else {
    yield put(actions.getContentFailed());
  }
}
function* submitContent({ value }) {
  const { id,userId } = yield select(state => state.recruitmentRequestDetailPage);

  const resp = yield call(api.put, `v1/RequestAssignmentRequest/accept-request`, value);
  const { data, status } = resp;

  if (status == 200) {
    yield delay(200);
    yield put(actions.submitContentSuccess(data));
    yield notification.open({
      message: 'Cập nhật yêu cầu tuyển dụng thành công',
      type:'success'
    });
    yield put(actions.getContent(id, userId));
  } else {
    yield put(actions.submitContentFailed('password-failed'));
  }
 
}

function* getCompany({ id }) {
  yield delay(500);
  const resp = yield call(api.get, `v1/Companies(${id})`);
  const { data, status } = resp;

  if (status == 200) {
    yield put(actions.getCompanySuccess({ ...data }));
  } else {
    yield put(actions.getCompanyFailed());
  }
}
// Individual exports for testing
export default function* recruitmentRequestDetailPageSaga() {
  // See example in containers/HomePage/saga.js
  yield takeLatest(types.GET_PROFESSION, getProfessionList);
  yield takeLatest(types.GET_SKILL, getSkillList);
  yield takeLatest(types.GET_LOCATION, getLocationList);
  yield takeLatest(types.GET_CONTENT, getContent);
  yield takeLatest(types.SUBMIT_CONTENT, submitContent);
  yield takeLatest(types.GET_COMPANY, getCompany);
}
