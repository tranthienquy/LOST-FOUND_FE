/**
 *
 * RecruitmentRequestDetailPage
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import makeSelectRecruitmentRequestDetailPage from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import * as actions from './actions';
import CandidateListPage from './CandidateListPage';
import './styles.scss';
import AuthContext from '../../../utils/auth';
import { withRouter ,Link} from 'react-router-dom';
import { Button, Card, Typography, Tag, Modal, Form, Input , Select, Skeleton, DatePicker, Tooltip, List} from 'antd';
import moment from 'moment';
import JobDetailSkeleton from '../JobDetailPage/JobDetailSkeleton';
import { Helmet } from 'react-helmet';
import { LinearProgress } from '@mui/material';



class RecruitmentRequestDetailPage extends React.Component {
  componentWillMount(){
    this.props.onGetCompany(this.context.user.CompanyId);
    const { id } = this.props.match.params;
    if (id) {
      this.props.onGetContent(id, this.context.user.Id);
    }
  }
  componentWillReceiveProps(nextProps) {
    const { id } = nextProps.match.params;
    if (nextProps.match.params !== this.props.match.params) {
      if (id) {
        this.props.onGetContent(id, this.context.user.Id);
      }
    }
  }

  componentWillUnmount() {
    this.props.onEndOfAction();
  }
  componentDidMount(){
    this.props.onGetLocationList();

  }
  onSubmit= value => {
    // this.props.onSubmitContent(value)
  };

  onSubmitFailed= error => {
  };

  searchProfession = value => {
    this.props.onGetProfessionList(value);
  };
  searchSkill = value => {
    this.props.onGetSkillList(value);
  };


  onSubmitFailed = errorInfo => {};

  render() {
    const {loading, professionList, locationList, id, company, skillList , content, fileList,mainStatus,  tab} = this.props.recruitmentRequestDetailPage;
    return (
      <div className="job-form-container d-flex flex-column pt-5">
        <Helmet>
          <title> Yêu cầu tuyển dụng</title>
        </Helmet>
        <div className='d-flex '>
        <Typography.Text
          className="link-text-on-click"
          type="secondary"
          onClick={() => this.props.history.goBack()}
        >
          <i className="icon-Caret-left" /> Quay lại
        </Typography.Text>
        <Typography className='ml-2'> / {`Yêu cầu tuyển dụng mã ${id}`}</Typography>
       
        
        </div>
        {loading.content && id ? (
          <JobDetailSkeleton />
        ) : (
        
      
       
          <div className="row">
            <div className="d-flex flex-column pr-5 col-xs-12 col-sm-12 col-md-12 col-lg-9">
            <Form
          name="basic"
          onFinish={this.onSubmit}
          autoComplete="off"
          layout="vertical"
          initialValues={content}
          onFinishFailed={this.onSubmitFailed}
          className="ant-general-form"
        >
              <Card
         size="small"
         className="card-description mt-4"
         title={
           <Typography
             style={{ fontSize: '24px' }}
             className=" text-app-primary font-weight-bold mt-2 d-flex align-items-center"
           >
             <i
               style={{ fontSize: '29px' }}
               className=" mr-2 icon-Star-outline"
             />
             THÔNG TIN CHUNG
           </Typography>
         }
       >
         
         <div class="row">
           <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
           <Form.Item
        label="Tên công việc"
        name="Title"
      >
        <Input size='large' readOnly />
      </Form.Item>
           </div>
           <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                      <Form.Item
                        label="Tag"
                        name="Tag"
                       
                      >
                        <Input size="large" readOnly />
                      </Form.Item>
                    </div>
           <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
           <Form.Item
               label="Ngành nghề"
               name="Professions"
             
             >
               <Select
               readOnly
               filterOption={false}
               notFoundContent={''}
               suffixIcon={<span></span>}
             
               >
                 {professionList &&
                 professionList.map(item => (
                   <Select.Option
                     value={item.TKey}
                     key={`options-profession-${item.Id}`}
                   >
                    
                     {item.TValue}
                   </Select.Option>
                 ))}
               {loading.profession && (
                 <Select.Option disabled>Đang tải...</Select.Option>
               )}
               </Select>
             </Form.Item>
         </div>
         <div className="col-xs-12 col-sm-12 col-md-12 col-lg-8">
             <Form.Item
               label="Thành phố"
               name="City"
             
             >
               <Select
               disabled
                 suffixIcon={<i className="icon-Caret-down h3" />}
               maxTagCount='responsive'

               >
                    {locationList &&
                 locationList.map(item => (
                   <Select.Option
                     value={item.TKey}
                     key={`options-nationality-${item.Id}`}
                   >
                    
                     {item.TValue}
                   </Select.Option>
                 ))}
               {loading.location && (
                 <Select.Option disabled>Đang tải...</Select.Option>
               )}
               </Select>
             </Form.Item>
           </div>
           <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
           <Form.Item
        label="Địa điểm làm việc"
        name="Location"
      >
        <Input readOnly />
      </Form.Item>
           </div>
         </div>

         
       </Card>
       {!tab &&  <>  <Card
                  size="small"
                  className="card-description mt-4"
                  title={
                    <Typography
                      style={{ fontSize: '24px' }}
                      className=" text-app-primary font-weight-bold mt-2 d-flex align-items-center"
                    >
                      <i
                        style={{ fontSize: '29px' }}
                        className=" mr-2 icon-Star-outline"
                      />
                      CÔNG VIỆC
                    </Typography>
                  }
                >
                  <div className="row">
                    
                    <div className="col-xs-12 col-sm-12 col-md-12 col-lg-4">
                      <Form.Item
                        label="Số lượng"
                        name="Quantity"
                      >
                        <Input type={'number'} min={1}  readOnly/>
                      </Form.Item>
                    </div>
                    <div className="col-xs-12 col-sm-12 col-md-12 col-lg-4">
                      <Form.Item
                        label="Số năm kinh nghiệm"
                        name="WorkExperience"
                      >
                        <Input type={'number'} min={1} readOnly/>
                      </Form.Item>
                    </div>
                    <div className="col-xs-12 col-sm-12 col-md-12 col-lg-4">
                      <Form.Item
                        label="Ngày hết hạn tuyển dụng "
                        name="DueDate"
                        
                      >
                        <DatePicker className="w-100" inputReadOnly />
                      </Form.Item>
                    </div>
                    <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                      <Form.Item
                        label="Kỹ năng"
                        name="Skills"
                      
                      >
                        <Select
                          mode="multiple"
                          onSearch={this.searchSkill}
                          notFoundContent={''}
                          filterOption={false}
                          
                          suffixIcon={<i className="icon-Caret-down h3" />}
                        >
                          {skillList &&
                            skillList.map(item => (
                              <Select.Option
                                value={item.TKey}
                                key={`options-skill-${item.TKey}`}
                              >
                                {item.TValue}
                              </Select.Option>
                            ))}
                          {loading.skill && (
                            <Select.Option disabled>Đang tải...</Select.Option>
                          )}
                        </Select>
                      </Form.Item>
                    </div>
                  </div>
                </Card>
                <Card
                  size="small"
                  className="card-description mt-4"
                  title={
                    <Typography
                      style={{ fontSize: '24px' }}
                      className=" text-app-primary font-weight-bold mt-2 d-flex align-items-center"
                    >
                      <i
                        style={{ fontSize: '29px' }}
                        className=" mr-2 icon-Box-outline"
                      />
                      TÀI LIỆU THAM KHẢO
                    </Typography>
                  }
                >


                  <List
                    dataSource={fileList}s
                    className="w-100"
                    renderItem={item => (
                      <div
                        className="d-flex flex-row justify-content-between align-items-center list-item"
                        style={{
                          backgroundColor: item.originFileObj && '#edffe6',
                        }}
                      >
                        <Typography className="d-flex flex-row mt-2 pl-2 ">
                          <i className="icon-Document-outline mr-2 h5 " />
                          <span>
                            {item.originFileObj ? item.name : item.Link}
                          </span>
                          {/* <i className='ml-2' style={{color:'#aeaeae'}}>18/6/2002</i> */}
                        </Typography>
                        <div>
                          {/* <Tooltip placement="top" title={'Xem'}>
                   <i className="icon-Eye-outline cursor-pointer h4" onClick={()=>this.props.onPreviewModal(true, item)} />
                   </Tooltip> */}
                          <Tooltip
                            placement="top"
                            title={'Tải về'}
                            onClick={() => {
                              item.Id
                                ? window.open(
                                    `${this.context.prefixLink}/${item.Link}`,
                                  )
                                : this.downloadFile(item);
                            }}
                          >
                            <i className="icon-Download-outline cursor-pointer h4" />
                          </Tooltip>
                         
                        </div>
                      </div>
                    )}
                  />
                </Card>
              
        {mainStatus=== null &&                    
      <div className='d-flex flex-row mt-4'>
      <Button onClick={()=>this.props.onSubmitContent({Accepted:true,ProfileId:Number.parseInt(this.context.user.Id), RequestId:content.Id})} >
      <span className="w-100 text-center d-flex justify-content-center">
      <i className="icon-Check mr-1" /> 
        Chấp nhận</span></Button>
      <Button className='ml-3' style={{color:'red', borderColor:'red'}}  onClick={()=>this.props.onSubmitContent({Accepted:false,ProfileId:Number.parseInt(this.context.user.Id), RequestId:content.Id})} >
      <span className="w-100 text-center d-flex justify-content-center">
      <span className=" mr-1" >X</span> 
        Từ chối</span>
      </Button>
     
      </div> } 
      
      <div className='mt-2'>
              {mainStatus==1 && <Typography style={{fontSize:28, color:'green'}}  className='ml-1'><i className='icon-Check'></i>Chấp nhận</Typography>  }
              {mainStatus==0 &&  <Typography style={{fontSize:28, color:'red'}}  className='ml-1'>X Từ chối</Typography> }</div>
      {loading.submit ?  <LinearProgress color='success' />:""}
    
</> }

     </Form>
           
     <div style={{height:'10px'}}>
      {loading.submit ?  <LinearProgress color='success' />:""}
          </div>
            </div>
            <div className="col-xs-12 col-sm-12 col-md-12 col-lg-3">
              <Card hoverable className="company-card">
                {loading.company ? <Skeleton active/> : 
                
                <div className="d-flex flex-column">
                  {company.Avatar && <img
                  src={company.Avatar && company.Avatar ?company.Avatar  :''}
                  width={'100%'}
                  height={'150px'}
                  style={{ objectFit: 'cover' }}
                />}
                
                <div className="p-2">
                  <Typography className="h7 font-weight-bold mb-2">
                    {company.Name}
                  </Typography>
                  <Typography
                    style={{ fontSize: '12px' }}
                    className="d-flex align-items-center text-app-primary"
                  >
                    <i
                      style={{ fontSize: '17px' }}
                      className="mr-1 icon-Location"
                    />
                    {company.Location}
                  </Typography>
                  <Typography
                    style={{ fontSize: '12px' }}
                    className="d-flex align-items-center text-app-primary"
                  >
                    <i
                      style={{ fontSize: '17px' }}
                      className="mr-1 icon-Contacts"
                    />
                    {company.Size} người
                  </Typography>
                
                </div>
              </div>
                }
               <Button  size="large" type="primary"  className="text-center w-100 mt-5">
              <b className="w-100 text-center" onClick={()=>this.props.onChangeTab()}>   GỬI CV </b>
     </Button>
              </Card>
              

            </div>
          </div>
         
        )}
     {tab && <CandidateListPage value={{partnerID:this.context.user.Id, jobId:content.Id}}/>}

      </div>
    );
  }
}

RecruitmentRequestDetailPage.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  recruitmentRequestDetailPage: makeSelectRecruitmentRequestDetailPage(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    onEndOfAction: () => {
      dispatch(actions.endOfAction());
    },
    onGetContent: (id, userId) => {
      dispatch(actions.getContent(id,userId));
    },
    onSubmitContent: value => {
      dispatch(actions.submitContent(value));
    },
    onGetCompany: id => {
      dispatch(actions.getCompany(id));
    },
    onGetProfessionList: content => {
      dispatch(actions.getProfessionList(content));
    },
    onGetSkillList: content => {
      dispatch(actions.getSkillList(content));
    },
    onGetLocationList: () => {
      dispatch(actions.getLocationList());
    },
    onChangeTab: (content) => {
      dispatch(actions.changeTab(content));
    },
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

const withReducer = injectReducer({ key: 'recruitmentRequestDetailPage', reducer });
const withSaga = injectSaga({ key: 'recruitmentRequestDetailPage', saga });
RecruitmentRequestDetailPage.contextType = AuthContext;

export default compose(
  withConnect,
  withReducer,
  withSaga,
  withRouter
)(RecruitmentRequestDetailPage);
