import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the recruitmentRequestDetailPage state domain
 */

const selectRecruitmentRequestDetailPageDomain = state => state.recruitmentRequestDetailPage || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by RecruitmentRequestDetailPage
 */

const makeSelectRecruitmentRequestDetailPage = () =>
  createSelector(
    selectRecruitmentRequestDetailPageDomain,
    substate => substate,
  );

export default makeSelectRecruitmentRequestDetailPage;
export { selectRecruitmentRequestDetailPageDomain };
