/**
 *
 * Asynchronously loads the component for RecruitmentRequestDetailPage
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
