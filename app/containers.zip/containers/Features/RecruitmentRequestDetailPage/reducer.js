/*
 *
 * RecruitmentRequestDetailPage reducer
 *
 */
import produce from 'immer';
import * as types from './constants';
import moment from 'moment';

export const initialState = {
  professionList: [],
  skillList: [],
  locationList: [],
  content: {},
  id: null,
  userId: null,
  company: null,
loading: {
  profession:  false,
  skill: false,
  content: false,
  submit: false,
  location: false,
  company: true
},
tab: false,
fileList: [],
mainStatus: null,

};

/* eslint-disable default-case, no-param-reassign */
const recruitmentRequestDetailPageReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case types.DEFAULT_ACTION:
        break;
      case types.END_OF_ACTION:
        for (var element in draft) {
          draft[element] = initialState[element];
        }
        break;

        case types.GET_PROFESSION:
          draft.loading.profession = action.content ? true : false;
          if (!action.content) {
            draft.professionList = [];
          }
          break;
        case types.GET_PROFESSION_SUCCESS:
          draft.loading.profession = false;
          draft.professionList = action.payload.data.value;
          break;
        case types.GET_PROFESSION_FAILED:
          break;
        case types.CHANGE_TAB:
          draft.tab = !draft.tab;
          break;

          
        case types.GET_SKILL:
          draft.loading.skill = action.content ? true : false;
          if (!action.content) {
            draft.skillList = [];
          }
          break;
        case types.GET_SKILL_SUCCESS:
          draft.loading.skill = false;
          draft.skillList = action.payload.data.value;
          break;
        case types.GET_SKILL_FAILED:
          break;

          case types.GET_LOCATION:
            draft.locationList = [];
            draft.loading.location= true;
          break;
      
          case types.GET_LOCATION_SUCCESS:
            draft.locationList = action.payload.data.value;
            draft.loading.location= false;
      
          break;
      
          case types.GET_LOCATION_FAILED:
          break;

          case types.GET_CONTENT:
            draft.id = action.id;
            draft.userId = action.userId;
            draft.loading.content = true;
            break;
          case types.GET_CONTENT_SUCCESS:
            const {
          
              DueDate,
              Skills,
              FileStorages,
              RequestAssignments
            } = action.payload.data.value[0];
            draft.content = {...action.payload.data.value[0],
              Skills :  JSON.parse(Skills),
              DueDate: moment(DueDate)
            };
            draft.loading.content = false;
          draft.fileList = FileStorages;
            if (RequestAssignments && RequestAssignments.length>0)
            {
              console.log(RequestAssignments[0].Status);
              draft.mainStatus = RequestAssignments[0].Status;
              console.log(draft.mainStatus);
            }

            break;
          case types.GET_CONTENT_FAILED:
            break;
            case types.SUBMIT_CONTENT:
              draft.loading.submit = true;
              break;
            case types.SUBMIT_CONTENT_SUCCESS:
              draft.loading.submit = false;
      
              break;
            case types.SUBMIT_CONTENT_FAILED:
              draft.loading.submit = false;
              break;
              case types.GET_COMPANY:
                draft.loading.company = true;
                break;
              case types.GET_COMPANY_SUCCESS:
                draft.company =  action.payload.data.value[0];
                draft.loading.company = false;

                break;
              case types.GET_COMPANY_FAILED:
                break;
          

    }
  });

export default recruitmentRequestDetailPageReducer;
