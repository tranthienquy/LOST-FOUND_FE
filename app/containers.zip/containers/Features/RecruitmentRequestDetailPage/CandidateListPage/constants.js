/*
 *
 * CandidateListPage constants
 *
 */

export const DEFAULT_ACTION = 'app/CandidateListPage/DEFAULT_ACTION';
export const END_OF_ACTION = 'app/CandidateListPage/END_OF_ACTION';


export const GET_CONTENT = 'app/CandidateListPage/GET_CONTENT';
export const GET_CONTENT_SUCCESS = 'app/CandidateListPage/GET_CONTENT_SUCCESS';
export const GET_CONTENT_FAILED = 'app/CandidateListPage/GET_CONTENT_FAILED';

export const GET_PROFESSION = 'app/CandidateListPage/GET_PROFESSION';
export const GET_PROFESSION_SUCCESS = 'app/CandidateListPage/GET_PROFESSION_SUCCESS';
export const GET_PROFESSION_FAILED = 'app/CandidateListPage/GET_PROFESSION_FAILED';

export const GET_SKILL = 'app/CandidateListPage/GET_SKILL';
export const GET_SKILL_SUCCESS = 'app/CandidateListPage/GET_SKILL_SUCCESS';
export const GET_SKILL_FAILED = 'app/CandidateListPage/GET_SKILL_FAILED';


export const SUBMIT_CONTENT = 'app/CandidateListPage/SUBMIT_CONTENT';
export const SUBMIT_CONTENT_SUCCESS = 'app/CandidateListPage/SUBMIT_CONTENT_SUCCESS';
export const SUBMIT_CONTENT_FAILED = 'app/CandidateListPage/SUBMIT_CONTENT_FAILED';

export const OPEN_PREVIEW_MODAL = 'app/CandidateListPage/OPEN_PREVIEW_MODAL';
