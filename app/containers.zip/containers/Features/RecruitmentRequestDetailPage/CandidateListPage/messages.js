/*
 * CandidateListPage Messages
 *
 * This contains all the text for the CandidateListPage container.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.containers.CandidateListPage';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'This is the CandidateListPage container!',
  },
});
