import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the candidateListPage state domain
 */

const selectCandidateListPageDomain = state =>
  state.candidateListPage || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by CandidateListPage
 */

const makeSelectCandidateListPage = () =>
  createSelector(
    selectCandidateListPageDomain,
    substate => substate,
  );

export default makeSelectCandidateListPage;
export { selectCandidateListPageDomain };
