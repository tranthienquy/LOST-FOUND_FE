/**
 *
 * Asynchronously loads the component for CandidateListPage
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
