/**
 *
 * CandidateListPage
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import makeSelectCandidateListPage from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import * as actions from './actions';
import {
  Button,
  Card,
  Typography,
  Tag,
  Modal,
  Form,
  Input,
  Select,
  Skeleton,
  DatePicker,
  Tooltip,
  List,
  Upload,
  Checkbox
} from 'antd';

import {
  Paper,
  TableContainer,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  LinearProgress,
} from '@mui/material';
import { API_ENDPOINT } from '../../../../utils/api/constants';
import FileViewerComponent from '../../../../components/FileViewerComponent';

class CandidateListPage extends React.Component {
  componentWillUnmount() {
    this.props.onEndOfAction();
  }
  formRef = React.createRef();
  componentWillMount() {
    this.props.onGetContent(this.props.value);
    this.props.onGetProfessionList();
  }

  dataSource = [
    {
      ID: '33',
      Title: '',
    },
  ];
  onSubmit = value => {
    console.log(value);
    this.props.onSubmitContent(value);
  
  };
  onSubmitFailed = errorInfo => {};

  searchSkill = value => {
    this.props.onGetSkillList(value);
  };

  render() {
    const { content, loading, professionList, skillList ,  previewModal,
      previewItem,} = this.props.candidateListPage;
    return (
      <div className="recruitment-request-form-container d-flex flex-column pt-5">
        {loading.content && <Skeleton active/>}
        {!loading.content && content && (
          <Form
            name="basic"
            onFinish={this.onSubmit}
            autoComplete="off"
            layout="vertical"
            onFinishFailed={this.onSubmitFailed}
            className="ant-general-form"
            initialValues={{ candidates: content }}
            ref={this.formRef}
          >
            <div className="d-flex justify-content-between ">
              <Typography className="text-app-primary h4 font-weight-bold">
                Danh sách ứng viên
              </Typography>
            </div>

            {/* <Form.List name="users"> */}

            <TableContainer component={Paper} style={{ width: '100%', height:500 }}>
              <Table
                style={{ minWidth: '2000px' }}
                // width={3000}
                stickyHeader
                aria-label="simple table"
                size='small'
              >
                <TableHead>
                  <TableRow>
                    <TableCell width={10} />
                    <TableCell width={300}>Tên </TableCell>
                    <TableCell width={300}>Họ</TableCell>
                    <TableCell width={300}>Email</TableCell>
                    <TableCell width={300}>Số điện thoại</TableCell>
                    <TableCell width={300}>Kinh nghiệm (năm)</TableCell>
                    <TableCell width={300}>Ngành nghề</TableCell>
                    <TableCell width={300}>Kỹ năng</TableCell>
                    <TableCell width={300}>Ngày ứng tuyển</TableCell>
                    <TableCell width={50}>CV</TableCell>
                    <TableCell width={300}>Ngày cập nhật CV</TableCell>
                    <TableCell width={300}>Upload CV mới</TableCell>
                    <TableCell width={300}>Trạng thái</TableCell>
                    {/* <TableCell width={300}>Lý do</TableCell> */}
                  </TableRow>
                </TableHead>
                <TableBody>
                  <Form.List name="candidates">
                    {(fields, { add, remove }) => (
                      <>
                        {fields.map(({ key, name, ...restField }) => (
                          <TableRow
                            sx={{
                              '&:last-child td, &:last-child th': { border: 0 },
                            }}
                          >
                            <TableCell className='check-box-item' component="th" scope="row" width={50}>
                              <Form.Item
                                {...restField}
                                name={[name, 'Checked']}
                                valuePropName="checked"
                              
                              >
                                <Checkbox  disabled={key < content.length && content[key].IsSubmited} ></Checkbox>
                              </Form.Item>
                            </TableCell>
                            <TableCell component="th" scope="row">
                              <Form.Item
                                {...restField}
                                name={[name, 'FirstName']}
                                rules={[
                                  {
                                    required: true,
                                    message: 'Vui lòng nhập Tên',
                                  },
                                ]}
                              >
                                <Input placeholder="FirstName" />
                              </Form.Item>
                            </TableCell>
                            <TableCell component="th" scope="row">
                              <Form.Item
                                {...restField}
                                name={[name, 'LastName']}
                                rules={[
                                  {
                                    required: true,
                                    message: 'Vui lòng nhập Họ',
                                  },
                                ]}
                              >
                                <Input placeholder="Họ" />
                              </Form.Item>
                            </TableCell>
                            <TableCell component="th" scope="row">
                              <Form.Item
                                {...restField}
                                name={[name, 'Email']}
                                rules={[
                                  {
                                    required: true,
                                    message: 'Vui lòng nhập Email',
                                  },
                                  {
                                    type: 'email',
                                    message: 'Email không đúng định dạng',
                                  }
                                ]}
                              >
                                <Input placeholder="Email"  disabled={key < content.length && content[key].AccountId}  />
                              </Form.Item>
                            </TableCell>
                            <TableCell>
                              <Form.Item
                                {...restField}
                                name={[name, 'Phone']}
                                rules={[
                                  {
                                    required: true,
                                    message: 'Vui lòng nhập Số điện thoại',
                                  },
                                ]}
                              >
                                <Input placeholder="Số điện thoại" />
                              </Form.Item>
                            </TableCell>
                            <TableCell>
                              <Form.Item
                                {...restField}
                                name={[name, 'WorkExperience']}
                               
                              >
                                <Input placeholder="Năm kinh nghiệm" type={'number'}/>
                              </Form.Item>
                            </TableCell>
                            <TableCell>
                              <Form.Item
                                {...restField}
                                name={[name, 'Profession']}
                             
                              >
                                <Select
                                  filterOption={false}
                                  notFoundContent={''}
                                  mode="multiple"
                                >
                                  {professionList &&
                                    professionList.map(item => (
                                      <Select.Option
                                        value={item.TKey}
                                        key={`options-profession-${item.Id}`}
                                      >
                                        {item.TValue}
                                      </Select.Option>
                                    ))}
                                  {loading.profession && (
                                    <Select.Option disabled>
                                      Đang tải...
                                    </Select.Option>
                                  )}
                                </Select>
                              </Form.Item>
                            </TableCell>
                            <TableCell>
                            
                            <Form.Item
                                {...restField}
                                name={[name, 'Skill']}
                               
                              >
                                <Select
                                  filterOption={false}
                          onSearch={this.searchSkill}
                          mode="multiple"

                                  notFoundContent={''}
                                  suffixIcon={<span />}
                                >
                                  {skillList &&
                                    skillList.map(item => (
                                      <Select.Option
                                        value={item.TKey}
                                        key={`options-skill-${item.Id}`}
                                      >
                                        {item.TValue}
                                      </Select.Option>
                                    ))}
                                  {loading.skill && (
                                    <Select.Option disabled>
                                      Đang tải...
                                    </Select.Option>
                                  )}
                                </Select>
                              </Form.Item>
                              </TableCell>
                              <TableCell>Ngày ứng tuyển</TableCell>
                            <TableCell>
                              { key < content.length &&  content[key].CV &&
                            <Tooltip
                          placement="top"
                          title={'Tải về'}
                          onClick={() => {
                            key < content.length
                              && window.open(
                                  `${API_ENDPOINT}/v1/Cvs/view/${content[key].CV.Id}`,
                                )
                             
                          }}
                        >
                          <i className="icon-Download-outline cursor-pointer h4" />
                        </Tooltip>}
                            </TableCell>
                            <TableCell>{ key < content.length && content[key].CV &&content[key].CV.UpdatedCvdate}</TableCell>
                            <TableCell>
                            <Form.Item   name={[name, 'UploadFile']} >
                          <Upload
                             customRequest={({ file, onSuccess }) => {
                              setTimeout(() => {
                                onSuccess('ok');
                              }, 0);
                            }}
                          >  <Button>+ Tải tệp</Button></Upload>
          </Form.Item>

                            </TableCell>
                            <TableCell>{key < content.length?content[key].Status:''}</TableCell>
                            {/* <TableCell>lý do</TableCell> */}
                          </TableRow>
                        ))}
                        <Form.Item>
                          <Button type="dashed" onClick={() => add()} block>
                            + Thêm mới ứng viên
                          </Button>
                        </Form.Item>
                      </>
                    )}
                  </Form.List>
                </TableBody>
              </Table>
            </TableContainer>
              <Button
                size="large"
                type="primary"
                htmlType="submit"
                className="text-center w-100 mt-3"
              >
                <b className="w-100 text-center">GỬI ỨNG VIÊN</b>
              </Button>
      {loading.submit ?  <LinearProgress color='success' />:""}

          </Form>
        )}
            <Modal
          width={'80vw'}
          visible={previewModal}
          footer={''}
          title={previewItem && previewItem.Name}
          onCancel={() => this.props.onPreviewModal(false, null)}
        >
          <FileViewerComponent value={previewItem} />
        </Modal>
      </div>
    );
  }
}

CandidateListPage.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  candidateListPage: makeSelectCandidateListPage(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    onEndOfAction: () => {
      dispatch(actions.endOfAction());
    },
    onGetContent: id => {
      dispatch(actions.getContent(id));
    },
    onSubmitContent: value => {
      dispatch(actions.submitContent(value));
    },
    onGetProfessionList: content => {
      dispatch(actions.getProfessionList(content));
    },
    onGetSkillList: content => {
      dispatch(actions.getSkillList(content));
    },
    onPreviewModal: (isShowing, id) => {
      dispatch(actions.showPreviewModal(isShowing, id));
    },
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

const withReducer = injectReducer({ key: 'candidateListPage', reducer });
const withSaga = injectSaga({ key: 'candidateListPage', saga });
export default compose(
  withConnect,
  withReducer,
  withSaga,
)(CandidateListPage);
