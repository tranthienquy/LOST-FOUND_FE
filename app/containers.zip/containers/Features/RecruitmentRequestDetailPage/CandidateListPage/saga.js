import {
  take,
  call,
  put,
  select,
  takeLatest,
  delay,
  fork,
  takeEvery,
  all,
} from 'redux-saga/effects';
import * as types from './constants';
import * as actions from './actions';
import * as api from 'utils/api';
import { KEY_VALUE } from '../../../../utils/api/constants';
import { notification } from 'antd';
import { push } from 'react-router-redux';
import moment from 'moment';
import { Numeral } from 'numeral';

function* getProfessionList() {
  yield delay(500);

  const resp = yield call(
    api.postPagination,
    `v1/KeyValues`,
    null,
    null,
    `TGroup eq ${KEY_VALUE.PROFESSION}`,
    null,
  );
  const { data, status } = resp;
  if (status == 200) {
    yield put(actions.getProfessionListSuccess(data));
  } else {
    yield put(actions.getProfessionListFailed());
  }
}
function* getSkillList({ content }) {
  if (content && content.length > 0) {
    yield delay(500);
    let searchFilter = '';
    if (typeof content == 'string') {
      // Search by TValue
      searchFilter = `contains(tolower(TValue),tolower('${encodeURIComponent(
        content,
      )}'))`;
    } else {
      // Search by TKey Array
      content.forEach(el => {
        searchFilter += `contains(tolower(TKey),tolower('${encodeURIComponent(
          el,
        )}')) or `;
      });
      searchFilter = searchFilter.slice(0, -3);
    }
    const resp = yield call(
      api.postPagination,
      `v1/KeyValues`,
      null,
      null,
      `TGroup eq ${KEY_VALUE.SKILL} and ` + searchFilter,
      null,
    );
    const { data, status } = resp;
    if (status == 200) {
      yield put(actions.getSkillListSuccess(data));
    } else {
      yield put(actions.getSkillListFailed());
    }
  }
}
function* getContent({ content }) {
  yield delay(1000);
  const resp = yield call(
    api.get,
    `v1/RequestAssignmentRequest/get-candidate-partner?requestId=${
      content.jobId
    }`,
  );
  const { data, status } = resp;

  if (status == 200) {
    yield put(actions.getContentSuccess(data));
    // yield put(actions.getSkillList(JSON.parse(data.Skills)));
    // yield put(actions.getProfessionList([data.Professions]));
  } else {
    yield put(actions.getContentFailed());
  }
}

function* submitContent({ value }) {
  const { id } = yield select(state => state.candidateListPage);

  const existProfile = value.candidates
    .filter(el => el.AccountId)
    .map(el => ({
      ...el,
      Id: el.ProfileId,
      Profession: JSON.stringify(el.Profession),
      Skill: JSON.stringify(el.Skill),
    }));
  const newProfile = value.candidates
    .filter(el => !el.AccountId)
    .map(el => ({
      ...el,

      Profession: JSON.stringify(el.Profession),
      Skill: JSON.stringify(el.Skill),
    }));

  const createResp = yield call(
    api.post,
    'v1/Accounts/create-accounts-applicant-for-partner-request',
    {},
    newProfile,
  );
  if (createResp.status === 200) {
    let dataResp = createResp.data;
    yield console.log(createResp.data, newProfile);
    let dataFilterResp = yield dataResp.map(el => ({
      ...el,
      ProfileId: Number.parseInt(el.Id),
      Checked: newProfile.find(item => item.Email === el.Email).Checked,
      UploadFile: newProfile.find(item => item.Email === el.Email).UploadFile,
      IsSubmited: false,
    }));
    yield console.log(dataFilterResp);

    const updateResp = yield call(
      api.put,
      'v1/Accounts/update-accounts-applicant-for-partner-request',
      {},
      existProfile,
    );

    const checkedValue = yield [...existProfile, ...dataFilterResp].filter(
      el => el.Checked && !el.IsSubmited,
    );
    yield console.log(dataFilterResp, existProfile);
      yield console.log( [...existProfile, ...dataFilterResp].filter(el => el.UploadFile))
    yield all(
      [...existProfile, ...dataFilterResp]
        .filter(el => el.UploadFile)
        .map(item => call(uploadFiles, item.ProfileId, item.UploadFile.fileList)),
    );

    const resp3 = yield call(
      api.post,
      `v1/RequestResponses/Request(${id})/send-candidate`,
      {},
      checkedValue.map(el => el.ProfileId),
    );
    const { data, status } = resp3;
    if (status === 200) {
      yield put(actions.submitContentSuccess());
      yield notification.open({
        message: 'Gửi ứng viên thành công',
        type: 'success',
      });
      yield put(actions.getContent({ jobId: id }));
    } else {
      yield put(actions.submitContentFailed());
    }
  } else {
    console.log('Lỗi');
    yield put(actions.submitContentFailed(createResp.data));
    yield notification.open({
      message: 'Có Email tồn tại',
      type: 'error',
    });
  }
}

function* uploadFiles(id, fileList) {
  let dataFile = yield new FormData();
  let listNewFiles = yield [];
  yield fileList.forEach(element => {
    if (element.originFileObj) {
      listNewFiles.push(element.originFileObj);
      dataFile.append('files', element.originFileObj);
    }
  });
  if (listNewFiles.length > 0) {
    const resp = yield call(
      api.post,
      `v1/Cvs/upload-profile-for-partner?profileID=${id}`,
      {},
      dataFile,
      { 'Content-Type': 'multipart/form-data' },
    );
    const { data, status } = resp;

    if (status == 200) {
    } else {
      // yield put(actions.submitUpdateFailed());
    }
  }
}
// Individual exports for testing
export default function* candidateListPageSaga() {
  // See example in containers/HomePage/saga.js
  yield takeLatest(types.GET_PROFESSION, getProfessionList);
  yield takeLatest(types.GET_SKILL, getSkillList);
  yield takeLatest(types.GET_CONTENT, getContent);
  yield takeLatest(types.SUBMIT_CONTENT, submitContent);
}
