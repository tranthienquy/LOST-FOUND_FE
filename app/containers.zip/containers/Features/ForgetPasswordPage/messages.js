/*
 * ForgetPasswordPage Messages
 *
 * This contains all the text for the ForgetPasswordPage container.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.containers.ForgetPasswordPage';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'This is the ForgetPasswordPage container!',
  },
});
