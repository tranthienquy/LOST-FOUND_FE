import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the forgetPasswordPage state domain
 */

const selectForgetPasswordPageDomain = state =>
  state.forgetPasswordPage || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by ForgetPasswordPage
 */

const makeSelectForgetPasswordPage = () =>
  createSelector(
    selectForgetPasswordPageDomain,
    substate => substate,
  );

export default makeSelectForgetPasswordPage;
export { selectForgetPasswordPageDomain };
