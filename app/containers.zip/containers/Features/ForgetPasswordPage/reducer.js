/*
 *
 * ForgetPasswordPage reducer
 *
 */
import produce from 'immer';
import {
  DEFAULT_ACTION,
  END_OF_ACTION,
  SUBMIT,
  SUBMIT_FAILED,
  SUBMIT_SUCCESS,
} from './constants';
import { message, notification } from 'antd';


export const initialState = {
  loading: false,
  success: false,
  failed: false,
};

/* eslint-disable default-case, no-param-reassign */
const forgetPasswordPageReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case DEFAULT_ACTION:
        break;
      case END_OF_ACTION:
        for (var element in draft) {
          draft[element] = initialState[element];
        }
        break;
      case SUBMIT:
        draft.loading = true;
        draft.success= false;
        draft.failed= false;
        break;
      case SUBMIT_SUCCESS:
        draft.loading = false;
        draft.success = true;
        break;
      case SUBMIT_FAILED:
        draft.loading = false;
        draft.failed = true;
        break;
    }
  });

export default forgetPasswordPageReducer;
