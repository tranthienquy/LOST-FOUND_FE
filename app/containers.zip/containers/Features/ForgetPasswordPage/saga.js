import { take, call, put, select, takeLatest, delay } from 'redux-saga/effects';
import { push } from 'react-router-redux';
import * as types from './constants';
import * as actions from './actions';
import * as api from 'utils/api';
import { notification } from 'antd';

function* forgetpassword({value}){
  const resp = yield call(
    api.get,
    `v1/Accounts/forget-password?email=${encodeURIComponent(value.email)}`,
  );
  const { data, status } = resp;
  if (status == 200 ) {
    yield delay(2000);
    yield put(actions.submitSuccess(data));
    yield notification.open({
      message:"Email cập nhật mật khẩu đã được gửi đến bạn. Vui lòng kiểm tra email"
    })
    yield delay(2000);
    yield put(push('/login'));
  } else {
    yield put(actions.submitFailed());
  }
}

export default function* forgetPasswordPageSaga() {
  // See example in containers/HomePage/saga.js
  yield takeLatest(types.SUBMIT, forgetpassword);
}
