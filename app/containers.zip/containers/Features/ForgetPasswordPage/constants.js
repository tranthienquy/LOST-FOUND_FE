/*
 *
 * ForgetPasswordPage constants
 *
 */

export const DEFAULT_ACTION = 'app/ForgetPasswordPage/DEFAULT_ACTION';
export const END_OF_ACTION = 'app/ForgetPasswordPage/END_OF_ACTION';
export const SUBMIT = 'app/ForgetPasswordPage/SUBMIT';
export const SUBMIT_SUCCESS = 'app/ForgetPasswordPage/SUBMIT_SUCCESS';
export const SUBMIT_FAILED = 'app/ForgetPasswordPage/SUBMIT_FAILED';
