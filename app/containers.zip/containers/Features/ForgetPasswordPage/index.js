/**
 *
 * ForgetPasswordPage
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import makeSelectForgetPasswordPage from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import * as actions from './actions';

import { Card, Typography, Input, Button, Form, notification } from 'antd';
import { Link } from 'react-router-dom';
import { Animated } from 'react-animated-css';
import { LinearProgress } from '@mui/material';
import './styles.scss';

class ForgetPasswordPage extends React.Component {
  componentWillMount(){
    notification.destroy();

  }
  componentWillUnmount() {
    this.props.onEndOfAction();
  }
  onSubmitSearch = value => {
    this.props.onSubmit(value);
  };
  onFinishFailed = errorInfo =>{

  }
  render() {
    const {loading, success, failed}= this.props.forgetPasswordPage;
    return (
      <div className="forgot-password-container">
        <Animated className="d-flex justify-content-center align-items-center w-100 h-100"
        animationIn="fadeInUp"
                  animationOut=""
                  isVisible={true}
                  animationInDuration={500}
                  animationInDelay={0}>
          <Card className="login-card" style={{maxWidth:'500px'}}>
            <div
                  
                   className="d-flex flex-column justify-content-center"
                >
              <Typography className="text-center head-title font-weight-bold mt-2 mb-4">
              QUÊN MẬT KHẨU
              </Typography>
              <Typography className="text-center font-weight-bold mt-1 mb-1">
              Hãy nhập email vào khung bên dưới. Chúng tôi sẽ gửi thông tin để bạn thay đổi mật khẩu vào email.
              </Typography>
            
              <Form
          name="basic"
          onFinish={this.onSubmitSearch}
          autoComplete="off"
          layout='vertical'
          onFinishFailed={this.onFinishFailed}
        >
             <Form.Item
        name="email"
        rules={[{ required: true, message: 'Vui lòng nhập Email' },  {
          type: 'email',
          message: 'Email không đúng định dạng',
        }]}

        >
              <Input
                size="large"
                className="text-center"
              />
              </Form.Item>

              <Form.Item className='mb-0'>
              <Button disabled={loading} size="large" type="primary" htmlType='submit' className="text-center w-100 mt-3">
                <b className="w-100 text-center">GỬI LẠI MẬT KHẨU</b>
              </Button>
              </Form.Item>
              {failed && <Typography className='text-center' style={{color:'red'}}>Email không tồn tại</Typography>}   
              {success && <Typography className='text-center text-app-primary' >Vui lòng check email để lấy lại mật khẩu</Typography>}   
             <div style={{height:'10px'}}>
             {loading ?  <LinearProgress color='success' />:""}
                 </div>
              </Form>
           </div>
          </Card>
        </Animated>
      </div>
    );
  }
}

ForgetPasswordPage.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  forgetPasswordPage: makeSelectForgetPasswordPage(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    onEndOfAction: () => {
      dispatch(actions.endOfAction());
    },
    
    onSubmit: value=>{
      dispatch(actions.submit(value));
    }
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

const withReducer = injectReducer({ key: 'forgetPasswordPage', reducer });
const withSaga = injectSaga({ key: 'forgetPasswordPage', saga });
export default compose(
  withConnect,
  withReducer,
  withSaga,
)(ForgetPasswordPage);
