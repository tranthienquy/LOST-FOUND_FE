/*
 *
 * ForgetPasswordPage actions
 *
 */

import { DEFAULT_ACTION, END_OF_ACTION, SUBMIT, SUBMIT_FAILED, SUBMIT_SUCCESS} from './constants';

export function defaultAction() {
  return {
    type: DEFAULT_ACTION,
  };
}
export const endOfAction = () => {
  return {
    type: END_OF_ACTION,
  };
};
export const submit = (value) => {
  return {
    type: SUBMIT,
    value
  };
};
export const submitSuccess = data => {
  return {
    type: SUBMIT_SUCCESS,
    payload: {
      data,
    },
  };
};
export const submitFailed = () => {
  return {
    type: SUBMIT_FAILED,
  };
};