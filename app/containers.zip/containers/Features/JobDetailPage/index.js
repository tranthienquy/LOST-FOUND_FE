/**
 *
 * JobDetailPage
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import makeSelectJobDetailPage from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import './styles.scss';
import { Helmet } from 'react-helmet';
import {
  Button,
  Card,
  Typography,
  Tag,
  Modal,
  List,
  Upload,
  Spin,
  Tooltip,
  Checkbox,
} from 'antd';
import { Link, useHistory, withRouter } from 'react-router-dom';
import JobDetailSkeleton from './JobDetailSkeleton';
import * as actions from './actions';
import moment from 'moment';
import AuthContext from '../../../utils/auth';
import { LinearProgress } from '@mui/material';
import { USER_ROLE } from '../../../utils/constants';
import { getValidRole } from '../../../utils/permissionUtil';
import { Animated } from 'react-animated-css';
import { API_ENDPOINT } from '../../../utils/api/constants';
import FileViewerComponent from '../../../components/FileViewerComponent';

class JobDetailPage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedCV: [],
      duplicateCV: false,
    };
  }
  componentWillMount() {
    const { id } = this.props.match.params;
    if (id) {
      this.props.onLoadContent(id);
    }
  }
  componentWillUnmount() {
    this.props.onEndOfAction();
  }
  componentWillReceiveProps(nextProps) {
    const { id } = nextProps.match.params;
    if (nextProps.match.params !== this.props.match.params) {
      if (id) {
        this.props.onLoadContent(id);
      }
    }
  }
  onUpCVFile = async value => {
    if (this.state.duplicateCV) {
      this.props.onUploadCV(value.file);
    }
    this.setState({ duplicateCV: !this.state.duplicateCV });

    // const base64 = await getBase64(value.file.originFileObj);
    // if (base64.startsWith('data:image/')) {
    //   await this.setState({
    //     image: value.file,
    //     imagePreview: base64,
    //   });
    // await this.props.onUploadAvatar(value.file);

    // } else{
    //   notification.open("Vui lòng chọn file hình ảnh");
    // }
  };

  submitContent = () => {
    this.props.onSubmitContent(this.state.selectedCV);
  };

  showConfirmModal = isShowing => {
    if (!this.context.user) {
      this.props.history.replace('/login');
      notification.open({
        message: 'Vui lòng đăng nhập để tham gia ứng tuyển',
        type: 'info',
      });
      return;
    }
    this.props.onShowConfirmModal(isShowing);
    this.props.onGetProfile(this.context.user.Id);
    this.props.onGetCVList(this.context.user.Id);
  };

  onChangeCVCheckList = checkedValues => {
    console.log(checkedValues);
    this.setState({ selectedCV: checkedValues });
  };

  render() {
    const {
      content,
      loading,
      confirmModal,
      cvList,
      profile,
      isRegistered,
      previewModal, previewItem
    } = this.props.jobDetailPage;

    return (
      <div className="job-detail-container d-flex flex-column pt-5">
        <Helmet>
          <title>Việc làm</title>
        </Helmet>

        <Typography.Text
          className="link-text-on-click"
          type="secondary"
          onClick={() => this.props.history.goBack()}
        >
          <i className="icon-Caret-left" /> Quay lại
        </Typography.Text>

        {loading.getContent ? (
          <JobDetailSkeleton />
        ) : (
          <div className="row">
            <div className="d-flex flex-column pr-5 col-xs-12 col-sm-12 col-md-12 col-lg-9">
              <div className="d-flex justify-content-between w-100">
                {' '}
                <Typography className="font-weight-bold h4 mt-4">
                  {content.Title}
                </Typography>
                {!loading.isRegistered &&
                  !isRegistered &&
                  !getValidRole(this.context.user, [USER_ROLE.RECRUITER]) && (
                    <Animated animationIn="fadeIn" animationInDuration={500}>
                      <Button
                        type="primary"
                        className="text-center  mt-3"
                        onClick={() => this.showConfirmModal(true)}
                      >
                        <b classNam e="w-100 text-center">
                          + ỨNG TUYỂN NGAY
                        </b>
                      </Button>
                    </Animated>
                  )}
                {!loading.isRegistered && isRegistered && (
                  <Animated animationIn="fadeIn" animationInDuration={500}>
                    <Typography className="text-app-primary font-weight-bold mt-3 d-flex align-items-center">
                      <i className="icon-Check-outline h5" /> ĐÃ ỨNG TUYỂN
                    </Typography>
                  </Animated>
                )}
                {getValidRole(this.context.user, [USER_ROLE.RECRUITER]) &&
                  this.context.user.Id == content.CreateBy && (
                    <Link to={`/job-form/edit/${content.Id}`}>
                      <Button
                        className="text-center d-flex align-items-center  mt-3"
                      >
                        <i className="icon-Edit-outline mr-2" />{' '}
                        <b className="w-100 text-center"> CHỈNH SỬA</b>
                      </Button>
                    </Link>
                  )}
              </div>
                        {content.Location  && 
              <Typography
                style={{ fontSize: '16px' }}
                className="mt-2 d-flex align-items-center"
              >
                <i
                  style={{ fontSize: '25px' }}
                  className=" text-app-primary mr-2 icon-Location-outline"
                />
               Địa điểm: {' '} <b className='ml-1'>{content.Location}</b> 
              </Typography>}
           
              <Typography
                style={{ fontSize: '16px' }}
                className="mt-2 d-flex align-items-center"
              >
                <i
                  style={{ fontSize: '25px' }}
                  className=" text-app-primary mr-2 icon-Map-location-outline"
                />
                Thành phố: {' '} <b className='ml-1'> {content.CityLabel && content.CityLabel[0].TValue} </b>
              </Typography>
              <Typography
                style={{ fontSize: '16px' }}
                className="mt-2 d-flex align-items-center"
              >
                <i
                  style={{ fontSize: '25px' }}
                  className=" text-app-primary mr-2 icon-Palette-outline"
                />
                Ngành nghề: {' '} <b className='ml-1'> {content.ProfessionLabel && content.ProfessionLabel[0].TValue}</b> 
              </Typography>
              <Typography
                style={{ fontSize: '16px' }}
                className="mt-2 d-flex align-items-center"
              >
                <i
                  style={{ fontSize: '25px' }}
                  className=" text-app-primary mr-2 icon-Cursor-outline"
                />
                Công ty:  { ' '} <b className='ml-1'>  {content.Company.value[0].Name} </b>
              </Typography>
              <Card
                size="small"
                className="card-description mt-4"
                title={
                  <Typography
                    style={{ fontSize: '24px' }}
                    className=" text-app-primary font-weight-bold mt-2 d-flex align-items-center"
                  >
                    <i
                      style={{ fontSize: '29px' }}
                      className=" mr-2 icon-Star-outline"
                    />
                    CÔNG VIỆC
                  </Typography>
                }
              >
                <div className="row">
                  <div className="col-xs-12 col-sm-12 col-md-12 col-lg-6">
                    <Typography
                      style={{ fontSize: '14px' }}
                      className="mt-3 d-flex align-items-center"
                    >
                      <i
                        style={{ fontSize: '25px' }}
                        className=" text-app-primary mr-2 icon-Bag-outline"
                      />
                      Số năm kinh nghiệm: {content.WorkExperience}{' '}
                    </Typography>
                  </div>
                  <div className="col-xs-12 col-sm-12 col-md-12 col-lg-6">
                    <Typography
                      style={{ fontSize: '14px' }}
                      className="mt-3 d-flex align-items-center"
                    >
                      <i
                        style={{ fontSize: '25px' }}
                        className=" text-app-primary mr-2 icon-Alarm-outline"
                      />
                      Ngày tạo: {moment(content.CreateAt).format('DD/MM/YYYY')}
                    </Typography>
                  </div>
                  <div className="col-xs-12 col-sm-12 col-md-12 col-lg-6">
                    <Typography
                      style={{ fontSize: '14px' }}
                      className="mt-3 d-flex align-items-center"
                    >
                      <i
                        style={{ fontSize: '25px' }}
                        className=" text-app-primary mr-2 icon-Sand-watch-outline"
                      />
                      Ngày hết hạn tuyển dụng:{' '}
                      {moment(content.DueDate).format('DD/MM/YYYY')}
                    </Typography>
                  </div>
                  <div className="col-xs-12 col-sm-12 col-md-12 col-lg-6">
                    <Typography
                      style={{ fontSize: '14px' }}
                      className="mt-3 d-flex align-items-start"
                    >
                      <i
                        style={{ fontSize: '25px' }}
                        className=" text-app-primary mr-2 icon-Award-outline"
                      />
                      <div className="d-flex flex-row flex-wrap">
                        <span className="mr-2">Kỹ năng:</span>
                        {content.Skills
                          ? JSON.parse(content.Skills).map(el => (
                              <Tag
                                key={el}
                                color="green"
                                className="font-weight-bold mb-1"
                              >
                                {content.SkillsLabel && content.SkillsLabel.find(item=>item.TKey === el)
                                 && content.SkillsLabel.find(item=>item.TKey === el).TValue
                                }
                              </Tag>
                            ))
                          : ''}
                      </div>
                    </Typography>
                  </div>
                </div>
              </Card>
              <Card
                size="small"
                className="card-description mt-4"
                title={
                  <Typography
                    style={{ fontSize: '24px' }}
                    className=" text-app-primary font-weight-bold mt-2 d-flex align-items-center"
                  >
                    <i
                      style={{ fontSize: '29px' }}
                      className=" mr-2 icon-Present-outline"
                    />
                    PHÚC LỢI
                  </Typography>
                }
              >
                <Typography.Text style={{whiteSpace:'pre-wrap'}}>{content.Benefits}</Typography.Text>
              </Card>
              <Card
                size="small"
                className="card-description mt-4"
                title={
                  <Typography
                    style={{ fontSize: '24px' }}
                    className=" text-app-primary font-weight-bold mt-2 d-flex align-items-center"
                  >
                    <i
                      style={{ fontSize: '29px' }}
                      className=" mr-2 icon-Book-open-outline"
                    />
                    MÔ TẢ CÔNG VIỆC
                  </Typography>
                }
              >
                <Typography.Text style={{whiteSpace:'pre-wrap'}}>{content.Description}</Typography.Text>
              </Card>
              <Card
                size="small"
                className="card-description mt-4"
                title={
                  <Typography
                    style={{ fontSize: '24px' }}
                    className=" text-app-primary font-weight-bold mt-2 d-flex align-items-center"
                  >
                    <i
                      style={{ fontSize: '29px' }}
                      className=" mr-2 icon-Clipboard-alt-outline"
                    />
                    YÊU CẦU CÔNG VIỆC
                  </Typography>
                }
              >
                <Typography.Text style={{whiteSpace:'pre-wrap'}}>{content.Requirement}</Typography.Text>
              </Card>
            </div>
            <div className="col-xs-12 col-sm-12 col-md-12 col-lg-3">
              <Card hoverable className="company-card">
                <div className="d-flex flex-column">
                  <img
                  src={content.Company.value[0].Avatar ? (content.Company.value[0].Avatar.startsWith('http')? content.Company.value[0].Avatar: `${this.context.prefixLink}/${content.Company.value[0].Avatar}`): require('../../../images/logo/logo-shinyama-grayscale.png') } 
                    width={'100%'}
                    height={'150px'}
                    style={{ objectFit: 'cover' }}
                  />
                  <div className="p-2">
                    <Typography className="h7 font-weight-bold mb-2">
                      {' '}
                      {content.Company.value[0].Name}
                    </Typography>
                    <Typography
                      style={{ fontSize: '12px' }}
                      className="d-flex align-items-center text-app-primary"
                    >
                      <i
                        style={{ fontSize: '17px' }}
                        className="mr-1 icon-Location"
                      />
                      {content.Company.value[0].Location}
                    </Typography>
                    <Typography
                      style={{ fontSize: '12px' }}
                      className="d-flex align-items-center text-app-primary"
                    >
                      <i
                        style={{ fontSize: '17px' }}
                        className="mr-1 icon-Contacts"
                      />
                      {content.Company.value[0].Size} người
                    </Typography>
                    <Link to={`/company/${content.Company.value[0].Id}`}>
                      <Button type="primary" className="text-center w-100 mt-3">
                        <b className="w-100 text-center"> XEM CÔNG TY</b>
                      </Button>
                    </Link>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        )}

        <Modal
          style={{ maxWidth: '1080px', minWidth: '50vw' }}
          width={'fit-content'}
          footer={''}
          onCancel={() => this.showConfirmModal(false)}
          visible={confirmModal}
          title={
            <Typography className="text-center  font-weight-bold ">
              NỘP ĐƠN ỨNG TUYỂN
            </Typography>
          }
        >
          {profile && (
            <>
              <div className="d-flex justify-content-between">
                <Typography className="font-weight-bold h4">
                  {profile.FirstName} {profile.LastName}
                </Typography>
                <Typography>{this.context.user.Email}</Typography>
              </div>
            </>
          )}

          <Typography>
            Kỹ năng:
            {content.Skills
                          ? JSON.parse(content.Skills).map(el => (
                              <Tag
                                key={el}
                                color="green"
                                className="font-weight-bold ml-2 mb-1"
                              >
                                {content.SkillsLabel && content.SkillsLabel.find(item=>item.TKey === el)
                                 && content.SkillsLabel.find(item=>item.TKey === el).TValue
                                }
                              </Tag>
                            ))
                          : ''}
          </Typography>
          <Typography> Số năm kinh nghiệm: {content.WorkExperience}</Typography>

          <Typography className="text-center mt-3 text-app-primary">
            Vui lòng chọn CV để nộp đơn
          </Typography>

          <Spin spinning={loading.cv} tip="Đang tải...">
            <Upload.Dragger
              customRequest={({ file, onSuccess }) => {
                setTimeout(() => {
                  onSuccess('ok');
                }, 0);
              }}
              height={'150px'}
              showUploadList={false}
              action={''}
              className="drop-file-avatar mb-4"
              onChange={this.onUpCVFile}
            >
              <Typography className="ant-upload-text">
                Tải hồ sơ của bạn tại đây
              </Typography>
              <i className="icon-Cloud-upload-outline h1 text-app-primary" />
            </Upload.Dragger>
            {loading.uploadCV ? <LinearProgress color="success" /> : ''}
            <Checkbox.Group
              style={{ width: '100%' }}
              onChange={this.onChangeCVCheckList}
            >
              <List
                dataSource={cvList}
                className="w-100"
                renderItem={item => (
                  <div className="d-flex flex-row justify-content-between align-items-center cv-item">
                    <Typography className="d-flex flex-row mt-2 pl-2 ">
                      <Checkbox className="mr-2" value={item.Id} />
                      <i className="icon-Document-outline mr-2 h5 " />
                      <span>{item.Name}</span>
                      <i className="ml-2" style={{ color: '#aeaeae' }}>
                        18/6/2002
                      </i>
                    </Typography>
                    <div>
                      <Tooltip placement="top" title={'Xem'}>
                        <i className="icon-Eye-outline cursor-pointer h4" onClick={()=>this.props.onPreviewModal(true, item)}  />
                      </Tooltip>
                      <Tooltip
                        placement="top"
                        title={'Tải về'}
                        onClick={() =>
                          window.open(`${API_ENDPOINT}/v1/Cvs/view/${item.Id}`)
                        }
                      >
                        <i className="icon-Download-outline cursor-pointer h4" />
                      </Tooltip>
                    </div>
                  </div>
                )}
              />
            </Checkbox.Group>
          </Spin>

          <Button
            type="primary"
            disabled={
              !(this.state.selectedCV && this.state.selectedCV.length > 0)
            }
            onClick={this.submitContent}
            className={`text-center w-100 mt-3 ${true ? '' : 'not-register'}`}
          >
            <b className="w-100 text-center"> NỘP ĐƠN</b>
          </Button>
          {loading.submit && <LinearProgress color="success" />}
        </Modal>
        <Modal width={'80vw'} visible={previewModal} footer={''} title={previewItem && previewItem.Name}
        onCancel ={()=>this.props.onPreviewModal(false, null)}
     ><FileViewerComponent value={previewItem}
 
     /></Modal>
      </div>
    );
  }
}

JobDetailPage.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  jobDetailPage: makeSelectJobDetailPage(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    onEndOfAction: () => {
      dispatch(actions.endOfAction());
    },
    onLoadContent: id => {
      dispatch(actions.loadContent(id));
    },
    onShowConfirmModal: isShowing => {
      dispatch(actions.showConfirmModal(isShowing));
    },
    onGetCVList: id => {
      dispatch(actions.getCV(id));
    },
    onGetProfile: id => {
      dispatch(actions.getProfile(id));
    },
    onUploadCV: cv => {
      dispatch(actions.uploadCV(cv));
    },
    onSubmitContent: content => {
      dispatch(actions.submitContent(content));
    },
    onPreviewModal: (isShowing, id)=>{
      dispatch(actions.showPreviewModal(isShowing, id))
    }
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

const withReducer = injectReducer({ key: 'jobDetailPage', reducer });
const withSaga = injectSaga({ key: 'jobDetailPage', saga });
JobDetailPage.contextType = AuthContext;

export default compose(
  withConnect,
  withReducer,
  withSaga,
  withRouter,
)(JobDetailPage);
