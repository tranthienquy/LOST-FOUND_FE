/*
 *
 * JobDetailPage reducer
 *
 */
import produce from 'immer';
import { DEFAULT_ACTION, LOAD_CONTENT, LOAD_CONTENT_SUCCESS, SHOW_CONFIRM_MODAL,
  CONFIRM,
  CONFIRM_FAILED,
  CONFIRM_SUCCESS,
  GET_CV,
  GET_CV_FAILED,
  GET_CV_SUCCESS,
  GET_PROFILE,
  GET_PROFILE_FAILED,
  GET_PROFILE_SUCCESS,
  GET_SKILL,
  GET_SKILL_SUCCESS,
  GET_SKILL_FAILED, 
  UPLOAD_CV,
  UPLOAD_CV_FAILED,
  UPLOAD_CV_SUCCESS,
  SUBMIT_CONTENT,
  SUBMIT_CONTENT_FAILED,
  SUBMIT_CONTENT_SUCCESS ,
  CHECK_IS_REGISTER,
  CHECK_IS_REGISTER_SUCCESS,
  CHECK_IS_REGISTER_FAILED,
  END_OF_ACTION,
  OPEN_PREVIEW_MODAL
} from './constants';

export const initialState = {
  id: '',
  content: {},
  isRegistered: false,
  loading: {
    isRegistered: true,
    getContent: true,
    cv: true,
    profile: true,
    skill: true,
    uploadCV: false,
    submit: false
  },
  confirmModal: false,
  cvList: [],
  profile: null,
  skillList: [],
  previewModal: false,
  previewItem: null

};

/* eslint-disable default-case, no-param-reassign */
const jobDetailPageReducer = (state = initialState, action) =>
  produce(state,  draft => {
    switch (action.type) {
      case DEFAULT_ACTION:
        break;
        case LOAD_CONTENT:
          draft.loading.getContent = true;
          draft.id = action.id;
          break;
          case END_OF_ACTION:
            for (var element in draft) {
              draft[element] = initialState[element];
            }
            break;
            case OPEN_PREVIEW_MODAL:
        draft.previewModal = action.isShowing
        draft.previewItem = action.item
        break;
        case LOAD_CONTENT_SUCCESS:
          draft.loading.getContent = false;
          console.log(action.payload.data);
        if (action.payload.data) {
          draft.content = action.payload.data;
        }
        break;

        case CHECK_IS_REGISTER:
          draft.isRegistered= false;
          break;
        case CHECK_IS_REGISTER_SUCCESS:
          draft.isRegistered = action.payload.data.message == "exited" ? true : false;
          draft.loading.isRegistered = false;

          break;
        case CHECK_IS_REGISTER_FAILED:
          draft.isRegistered = false;

          draft.loading.isRegistered= false;

          break;
        case SHOW_CONFIRM_MODAL:
          draft.confirmModal = action.isShowing;
          break;
          case CONFIRM:
            draft.loading.confirm = true;
            break;
          case CONFIRM_SUCCESS:
            draft.loading.confirm = false;
            break;
          case CONFIRM_FAILED:
            draft.loading.confirm = true;
  
            break;

            case GET_CV:
              draft.loading.cv = true;
              draft.cvList = [];
              break;
            case GET_CV_SUCCESS:
              draft.loading.cv = false;
              draft.cvList = action.payload.data.value;
              break;
            case GET_CV_FAILED:
              break;
              case GET_PROFILE:
                draft.loading.profile =  true;
                draft.profile = null;
                break;

                case GET_PROFILE_SUCCESS:
                  draft.loading.profile =  false;
                  draft.profile = action.payload.data.value[0];
                  break;
                  case GET_PROFILE_FAILED:
                    
                    break;
                    
      case GET_SKILL:
        draft.loading.skill = action.content ? true : false;
        if (!action.content) {
          draft.skillList = [];
        }
        break;
      case GET_SKILL_SUCCESS:
        draft.loading.skill = false;
        draft.skillList = action.payload.data.value;
        break;
      case GET_SKILL_FAILED:
        break;
        case UPLOAD_CV:
          draft.loading.uploadCV = true;
          break;
        case UPLOAD_CV_SUCCESS:
          draft.loading.uploadCV = false;
          break;
          case SUBMIT_CONTENT:
            draft.loading.submit = true;
            break;
          case SUBMIT_CONTENT_SUCCESS:
            draft.loading.submit = true;
    
            break;
          case SUBMIT_CONTENT_FAILED:
            draft.loading.submit = false;
      
      
    }
  });

export default jobDetailPageReducer;
