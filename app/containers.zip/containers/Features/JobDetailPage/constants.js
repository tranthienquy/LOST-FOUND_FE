/*
 *
 * JobDetailPage constants
 *
 */

export const DEFAULT_ACTION = 'app/JobDetailPage/DEFAULT_ACTION';
export const END_OF_ACTION = 'app/JobDetailPage/END_OF_ACTION';


export const LOAD_CONTENT = 'app/JobDetailPage/LOAD_CONTENT';
export const LOAD_CONTENT_SUCCESS = 'app/JobDetailPage/LOAD_CONTENT_SUCCESS';
export const LOAD_CONTENT_FAILED = 'app/JobDetailPage/LOAD_CONTENT_FAILED';

export const CHECK_IS_REGISTER = 'app/JobDetailPage/CHECK_IS_REGISTER';
export const CHECK_IS_REGISTER_SUCCESS = 'app/JobDetailPage/CHECK_IS_REGISTER_SUCCESS';
export const CHECK_IS_REGISTER_FAILED = 'app/JobDetailPage/CHECK_IS_REGISTER_FAILED';

export const SUBMIT_CONTENT = 'app/JobDetailPage/SUBMIT_CONTENT';
export const SUBMIT_CONTENT_SUCCESS = 'app/JobDetailPage/SUBMIT_CONTENT_SUCCESS';
export const SUBMIT_CONTENT_FAILED = 'app/JobDetailPage/SUBMIT_CONTENT_FAILED';

export const SHOW_CONFIRM_MODAL = 'app/JobDetailPage/SHOW_MODAL_CONFIRM';

export const CONFIRM = 'app/JobDetailPage/CONFIRM';
export const CONFIRM_SUCCESS = 'app/JobDetailPage/CONFIRM_SUCCESS';
export const CONFIRM_FAILED = 'app/JobDetailPage/CONFIRM_FAILED';


export const GET_CV = 'app/JobDetailPage/GET_CV';
export const GET_CV_SUCCESS = 'app/JobDetailPage/GET_CV_SUCCESS';
export const GET_CV_FAILED = 'app/JobDetailPage/GET_CV_FAILED';

export const UPLOAD_CV = 'app/JobDetailPage/UPLOAD_CV';
export const UPLOAD_CV_SUCCESS = 'app/JobDetailPage/UPLOAD_CV_SUCCESS';
export const UPLOAD_CV_FAILED = 'app/JobDetailPage/UPLOAD_CV_FAILED';

export const GET_PROFILE = 'app/JobDetailPage/GET_PROFILE';
export const GET_PROFILE_SUCCESS = 'app/JobDetailPage/GET_PROFILE_SUCCESS';
export const GET_PROFILE_FAILED = 'app/JobDetailPage/GET_PROFILE_FAILED';


export const GET_SKILL = 'app/JobDetailPage/GET_SKILL';
export const GET_SKILL_SUCCESS = 'app/JobDetailPage/GET_SKILL_SUCCESS';
export const GET_SKILL_FAILED = 'app/JobDetailPage/GET_SKILL_FAILED';

export const OPEN_PREVIEW_MODAL = 'app/ProfilePage/OPEN_PREVIEW_MODAL';
