/*
 *
 * JobDetailPage actions
 *
 */

import {
  DEFAULT_ACTION,
  LOAD_CONTENT,
  LOAD_CONTENT_FAILED,
  LOAD_CONTENT_SUCCESS,
  SHOW_CONFIRM_MODAL,
  CONFIRM,
  CONFIRM_FAILED,
  CONFIRM_SUCCESS,
  GET_CV,
  GET_CV_FAILED,
  GET_CV_SUCCESS,
  GET_PROFILE,
  GET_PROFILE_FAILED,
  GET_PROFILE_SUCCESS,
  GET_SKILL,
  GET_SKILL_SUCCESS,
  GET_SKILL_FAILED, 
  UPLOAD_CV,
UPLOAD_CV_FAILED,
UPLOAD_CV_SUCCESS,
SUBMIT_CONTENT,
SUBMIT_CONTENT_FAILED,
SUBMIT_CONTENT_SUCCESS, 
CHECK_IS_REGISTER,
CHECK_IS_REGISTER_SUCCESS,
CHECK_IS_REGISTER_FAILED,
END_OF_ACTION,
OPEN_PREVIEW_MODAL
} from './constants';

export function defaultAction() {
  return {
    type: DEFAULT_ACTION,
  };
}

export const endOfAction = () => {
  return {
    type: END_OF_ACTION,
  };
};

export const loadContent = id => {
  return {
    type: LOAD_CONTENT,
    id,
  };
};
export const loadContentSuccess = data => {
  return {
    type: LOAD_CONTENT_SUCCESS,
    payload: {
      data,
    },
  };
};
export const loadContentFailed = error => {
  return {
    type: LOAD_CONTENT_FAILED,
    error,
  };
};

export const showPreviewModal = (isShowing,item) => {
  return {
    type: OPEN_PREVIEW_MODAL,
    isShowing,
    item
  };
};
export const checkIsRegistered = id => {
  return {
    type: CHECK_IS_REGISTER,
    id,
  };
};
export const checkIsRegisteredSuccess = data => {
  return {
    type: CHECK_IS_REGISTER_SUCCESS,
    payload: {
      data,
    },
  };
};
export const checkIsRegisteredFailed = error => {
  return {
    type: CHECK_IS_REGISTER_FAILED,
    error,
  };
};

export const showConfirmModal = isShowing => {
  return {
    type: SHOW_CONFIRM_MODAL,
    isShowing,
  };
};

export const confirm = profileId => {
  return {
    type: CONFIRM,
    profileId,
  };
};
export const confirmSuccess = data => {
  return {
    type: CONFIRM_SUCCESS,
    payload: {
      data,
    },
  };
};
export const confirmFailed = error => {
  return {
    type: CONFIRM_FAILED,
    error,
  };
};
export const getCV = (id) => {
  return {
    type: GET_CV,
    id
  };
};
export const getCVSuccess = (data) => {
  return {
    type: GET_CV_SUCCESS,
    payload:{
      data
    }
    
  };
};
export const getCVFailed = (err) => {
  return {
    type: GET_CV_FAILED,
    err
  };
};
export const getProfile = (id) => {
  return {
    type: GET_PROFILE,
    id,
  };
};
export const getProfileSuccess = data => {
  return {
    type: GET_PROFILE_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getProfileFailed = () => {
  return {
    type: GET_PROFILE_FAILED,
  };
};


export const getSkillList = (content = '') => {
  return {
    type: GET_SKILL,
    content,
  };
};
export const getSkillListSuccess = data => {
  return {
    type: GET_SKILL_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getSkillListFailed = () => {
  return {
    type: GET_SKILL_FAILED,
  };
};

export const uploadCV = (cv) => {
  return {
    type: UPLOAD_CV,
    cv
  };
};
export const uploadCVSuccess = (data) => {
  return {
    type: UPLOAD_CV_SUCCESS,
    payload:{
      data
    }
    
  };
};
export const uploadCVFailed = (err) => {
  return {
    type: UPLOAD_CV_FAILED,
    err
  };
};
export const submitContent = value => {
  return {
    type: SUBMIT_CONTENT,
    value,
  };
};
export const submitContentSuccess = data => {
  return {
    type: SUBMIT_CONTENT_SUCCESS,
    payload: {
      data,
    },
  };
};
export const submitContentFailed = error => {
  return {
    type: SUBMIT_CONTENT_FAILED,
    error,
  };
};