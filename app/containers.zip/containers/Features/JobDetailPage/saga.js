import { take, call, put, select, takeLatest, delay } from 'redux-saga/effects';
import * as types from './constants';
import * as actions from './actions';
import * as api from 'utils/api';
import { KEY_VALUE } from '../../../utils/api/constants';
import { notification } from 'antd';
import { push } from 'react-router-redux';

function* loadContent({ id }) {
  const resp = yield call(
    api.get,
    `v1/Jobs(${id})`,
  );
  const { data, status } = resp;

  if (status == 200 ) {
    const companyResp =  yield call(
      api.get,
      `v1/Companies(${data.value[0].CompanyID})`,
    );
    if(companyResp.status===200){
      let searchSkillFilter = '';
      yield data.value[0].Skills && JSON.parse(data.value[0].Skills).forEach(item=>{
        searchSkillFilter+=`TKey eq '${encodeURIComponent(item)}' or `;
      })
      searchSkillFilter = yield searchSkillFilter.slice(0, -3);

      const professionResp = yield call(api.postPagination, `v1/KeyValues`, null, null, `TGroup eq ${KEY_VALUE.PROFESSION} and TKey eq '${encodeURIComponent(data.value[0].Professions)}'`, null)
      const skillResp = yield call(api.postPagination, `v1/KeyValues`, null, null, `TGroup eq ${KEY_VALUE.SKILL} and ${searchSkillFilter}`, null)
      const cityResp = yield call(api.postPagination, `v1/KeyValues`, null, null, `TGroup eq ${KEY_VALUE.LOCATION} and TKey eq '${data.value[0].City}'`, null)
      yield delay(1000);
      yield put(actions.loadContentSuccess({...data.value[0], Company: companyResp.data, ProfessionLabel: professionResp.data.value, SkillsLabel: skillResp.data.value,  CityLabel: cityResp.data.value  }));
      yield put(actions.checkIsRegistered(id));
    } 
  } else {
    yield put(actions.loadContentFailed());
  }

}

function* getCVList({ id }) {
  if (id) {
    yield delay(500);

    const resp = yield call(
      api.postPagination,
      `v1/CVs`,
      null,
      null,
      `profileId eq ${id} and Status eq 1`,
      null,
    );
    const { data, status } = resp;
    if (status == 200) {
      yield put(actions.getCVSuccess(data));
    } else {
      yield put(actions.getCVFailed());
    }
  }
}

function* getProfile({ id }) {
  const resp = yield call(api.get, `v1/UserProfiles(${id})`);
  const { data, status } = resp;

  if (status == 200) {
    yield put(actions.getProfileSuccess(data));
    yield console.log(data.value[0]);
    yield put(
      actions.getSkillList(JSON.parse(data.value[0].Skill)),
    );
  } else {
    yield put(actions.getProfileFailed());
  }
}

function* getSkillList({ content }) {
  if (content && content.length > 0) {
    yield delay(500);
    let searchFilter = '';
    if (typeof content == 'string') {
      // Search by TValue
      searchFilter = `contains(tolower(TValue),tolower('${encodeURIComponent(
        content,
      )}'))`;
    } else {
      // Search by TKey Array
      content.forEach(el => {
        searchFilter += `contains(tolower(TKey),tolower('${encodeURIComponent(
          el,
        )}')) or `;
      });
      searchFilter = searchFilter.slice(0, -3);
    }
    const resp = yield call(
      api.postPagination,
      `v1/KeyValues`,
      null,
      null,
      `TGroup eq ${
        KEY_VALUE.SKILL
      } and `+ searchFilter,
      null,
    );
    const { data, status } = resp;
    if (status == 200) {
      yield put(actions.getSkillListSuccess(data));
    } else {
      yield put(actions.getSkillListFailed());
    }
  }
}

function* uploadCV({ cv }) {
  const { profile } = yield select(state => state.jobDetailPage);

  let dataCV = yield new FormData();
  yield dataCV.append('file', cv.originFileObj);
  const resp = yield call(api.post, `v1/Cvs/upload-profile`, {}, dataCV, {
    'Content-Type': 'multipart/form-data',
  });
  const { data, status } = resp;

  if (status == 200) {
    yield delay(2000);
    yield put(actions.uploadCVSuccess(data));
    yield notification.open({
      message: 'Tải CV thành công',
      type: 'success',
    });
    yield put(actions.getCV(profile.Id));
  } else {
    yield put(actions.uploadCVFailed(data));
  }
}

function* submitContent({value}){
  const { cvList, profile, id } = yield select(state => state.jobDetailPage);
  yield console.log(cvList);

  const requestCV = yield []
  yield cvList.forEach(el=>{
    if (value.find(item=>item===el.Id))
    requestCV.push({Id: el.Id, Name: el.Name });
  });
  const requestData = {
    ListCvs: requestCV,
    ProfileId: profile.Id,
    JobId: id
  }
  console.log(requestData)
  const resp = yield call(
    api.post,
    `v1/JobSubmitions`, {}, requestData
  );
  const { data, status } = resp;

  if (status == 201 ) {
    yield delay(2000);
    yield put(actions.submitContentSuccess(data));
    yield notification.open({
      message:"Nộp đơn yêu cầu ứng tuyển thành công",
      type:"success"
    })
    // yield put(push('/job'));
    yield put(actions.showConfirmModal(false));
    yield put(actions.loadContent(id));
  } else {
    yield put(actions.submitContentFailed('password-failed'));
  }
}

function* checkIsRegistered ({id}){
  yield delay(1000);
  const resp = yield call(api.get, `v1/UserProfiles/check-job-submited?jobId=${id}`);
  const { data, status } = resp;

  if (status == 200) {
    yield put(actions.checkIsRegisteredSuccess(data));
  } else {
    yield put(actions.checkIsRegisteredFailed());
  }
}
// Individual exports for testing
export default function* jobDetailPageSaga() {
  // See example in containers/HomePage/saga.js
  yield takeLatest(types.LOAD_CONTENT, loadContent);
  yield takeLatest(types.CHECK_IS_REGISTER, checkIsRegistered);
  yield takeLatest(types.GET_CV, getCVList);
  yield takeLatest(types.GET_PROFILE, getProfile);
  yield takeLatest(types.GET_SKILL, getSkillList);
  yield takeLatest(types.UPLOAD_CV, uploadCV);
  yield takeLatest(types.SUBMIT_CONTENT, submitContent);
 

}
