/**
 *
 * JobDetailSkeleton
 *
 */

import { Card, Skeleton } from 'antd';
import React from 'react';
// import PropTypes from 'prop-types';
// import styled from 'styled-components';

class JobDetailSkeleton extends React.Component {
  render() {
    return (
      <div className="row">
        <div className="d-flex flex-column pr-5 col-xs-12 col-sm-12 col-md-12 col-lg-9">
          <Skeleton active />
          <Card
            size="small"
            className="card-description mt-4"
            title={
              <>
                {' '}
                <Skeleton.Input active style={{ width: '30px' }} />{' '}
                <Skeleton.Input active className="w-75" />
              </>
            }
          >
            <Skeleton active />
          </Card>
        </div>
        <div className="col-xs-12 col-sm-12 col-md-12 col-lg-3">
          <Card hoverable className="company-card">
            <div className="d-flex flex-column">
              <Skeleton.Button
                active
                style={{ width: '100%', height: '150px' }}
              />

              <div className="p-2">
                <Skeleton active />
                <Skeleton.Button active />
              </div>
            </div>
          </Card>
        </div>
      </div>
    );
  }
}

JobDetailSkeleton.propTypes = {};

export default JobDetailSkeleton;
