/**
 *
 * Asynchronously loads the component for JobDetailPage
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
