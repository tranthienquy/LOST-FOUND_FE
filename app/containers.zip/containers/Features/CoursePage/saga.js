import { take, call, put, select, takeLatest, delay } from 'redux-saga/effects';
import * as types from './constants';
import * as actions from './actions';
import * as api from 'utils/api';
import { KEY_VALUE } from '../../../utils/api/constants';


function* getCourseList({content}) {
  const { current, pageSize } = yield select(state => state.coursePage);
  console.log(content);
  let filter = '' ;
  if (content){
    filter=
    (content.Name ? `contains(tolower(Name),tolower('${encodeURIComponent(content.Name)}')) and ` :'')
    +(content.Type ? `Type eq '${content.Type}' and ` :'')
    +(content.Location && content.Location.length>0 ? `Location eq '${content.Location}' and ` :'')
    +(content.FeeType && content.FeeType != undefined ? `FeeType eq '${content.FeeType}' and ` :'')
    +(content.LowFee ? `Fee ge ${content.LowFee} and ` :'')
    +(content.HighFee ? `Fee le ${content.HighFee} and ` :'')
    +(content.showAvailable ? `Duedate gt now() and`: '')
}
if (filter){
  filter= filter.slice(0, -4);
}
  const resp = yield call(api.postPagination,`v1/Courses`, current, pageSize, filter);

  const { data, status } = resp;

  if (status == 200 ) {
    yield delay(2000);
    yield put(actions.getCourseListSuccess(data));
  } else {
    yield put(actions.getCourseListFailed());
  }
}

function* getLocationList(){
  const resp = yield call(
    api.postPagination,
    `v1/KeyValues`,
    null,
    null,
    `TGroup eq ${KEY_VALUE.LOCATION}`,
    null
  );
  const { data, status } = resp;
  if (status == 200) {
    yield put(actions.getLocationListSuccess(data));
  } else {
    yield put(actions.getLocationListFailed());
  }
}

function* getFeeTypeList(){
  const resp = yield call(
    api.postPagination,
    `v1/KeyValues`,
    null,
    null,
    `TGroup eq ${KEY_VALUE.FEETYPE}`,
    null
  );
  const { data, status } = resp;
  if (status == 200) {
    yield put(actions.getFeeTypeSuccess(data));
  } else {
    yield put(actions.getFeeTypeFailed());
  }
}
export default function* coursePageSaga() {
  // See example in containers/HomePage/saga.js
  yield takeLatest(types.GET_CONTENT, getCourseList);
  yield takeLatest(types.GET_LOCATION, getLocationList)
  yield takeLatest(types.GET_FEE_TYPE, getFeeTypeList)

}
