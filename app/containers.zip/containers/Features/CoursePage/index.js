/**
 *
 * CoursePage
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import makeSelectCoursePage from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import './styles.scss';
import {
  Form,
  Input,
  Button,
  Select,
  Typography,
  Pagination,
  Checkbox,
  Modal,
} from 'antd';
import { Helmet } from 'react-helmet';
import CourseListComponent from '../../../components/CourseListComponent';
import * as actions from './actions';
import { getValidRole } from '../../../utils/permissionUtil';
import { USER_ROLE } from '../../../utils/constants';
import AuthContext from '../../../utils/auth';
import { Link } from 'react-router-dom';

class CoursePage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      valueSearch: null,
      showAvailable: false,
    };
  }
  formRef = React.createRef();
  componentWillMount() {
    this.props.onGetCourseList();
    this.props.onGetLocationList();
    this.props.onGetFeeTypeList();
  }
  componentWillUnmount() {
    this.props.onEndOfAction();
  }
  onSubmitSearch = value => {
    this.setState({ valueSearch: value });
    this.props.onPagination(1, this.props.coursePage.pageSize);
    this.props.onGetCourseList({
      ...value,
      showAvailable: this.state.showAvailable,
    });
  };
  onChangePagination = (page, pageSize) => {
    this.props.onPagination(page, pageSize);
    this.props.onGetCourseList({
      ...this.state.valueSearch,
      showAvailable: this.state.showAvailable,
    });
  };
  onChangePageSize = value => {
    this.onChangePagination(this.props.coursePage.current, value);
  };

  onChangeCourseAvailable = async value => {
    await this.setState({ showAvailable: !this.state.showAvailable });
    await this.props.onGetCourseList({
      ...this.state.valueSearch,
      showAvailable: this.state.showAvailable,
    });
  };
  render() {
    const {
      courseList,
      loading,
      current,
      pageSize,
      total,
      locationList,
      feeTypeList,
    } = this.props.coursePage;
    return (
      <div className="course-container">
        <Helmet>
          <title>Đào tạo</title>
        </Helmet>
        <Form
          ref={this.formRef}
          name="basic"
          onFinish={this.onSubmitSearch}
          autoComplete="off"
        >
          <div className="row">
            <div className="col-xs-12 col-sm-12 col-md-6 col-lg-4 pl-4 pr-4 mt-2">
              <Form.Item name="Name">
                <Input
                  placeholder="Tên khóa học"
                  prefix={<i className="icon-Box-outline h5 feature-icon" />}
                />
              </Form.Item>
            </div>
            <div className="col-xs-12 col-sm-12 col-md-6 col-lg-8 pl-4 pr-4 mt-2">
              {/* <Form.Item initialValue={''}>
                <Input
                  placeholder="Kỹ năng"
                  prefix={
                    <i className="icon-Settings-outline h5 feature-icon" />
                  }
                />
              </Form.Item> */}
              <div className="input-group d-flex flex-row flex-nowrap align-items-center">
                <div className="ant-form-item-control-input-content select-input currency-input">
                  <span className="ant-input-affix-wrapper site-input-select-left d-flex align-items-center">
                    <span className="ant-input-prefix">
                      <i className="icon-Wallet-outline h5 feature-icon" />
                    </span>
                    <Form.Item name="FeeType">
                      <Select
                        className=""
                        bordered={false}
                        suffixIcon={<i className="icon-Caret-down h3" />}
                        defaultActiveFirstOption
                        defaultValue={'vnd'}
                      >
                        {feeTypeList.map(item => (
                          <Select.Option
                            key={`options-fee-type-${item.TKey}`}
                            value={item.TKey}
                          >
                            {item.TValue}
                          </Select.Option>
                        ))}
                      </Select>
                    </Form.Item>
                  </span>
                </div>
                <Form.Item
                  name="LowFee"
                  style={{ width: '40%', textAlign: 'center' }}
                >
                  <Input
                    type={'number'}
                    min={0}
                    placeholder="Từ"
                    className="site-input-center"
                    prefix={<span />}
                  />
                </Form.Item>
                <Input
                  className="site-input-center"
                  style={{
                    width: 30,
                    textAlign: 'center',
                    marginLeft: -1,
                    backgroundColor: 'white',
                  }}
                  disabled
                  prefix={'~'}
                />
                <Form.Item
                  name="HighFee"
                  style={{
                    width: '40%',
                    textAlign: 'center',
                    marginLeft: -1,
                  }}
                >
                  <Input
                    type={'number'}
                    className="site-input-right"
                    min={0}
                    prefix={<span />}
                    placeholder="Đến"
                  />
                </Form.Item>
              </div>
            </div>

            <div className="col-xs-12 col-sm-12 col-md-6 col-lg-4 pl-4 pr-4 mt-2">
              <div className=" ant-form-item-control-input-content select-input">
                <span className="ant-input-affix-wrapper d-flex align-items-center">
                  <span className="ant-input-prefix">
                    <i className="icon-Home-outline h5 feature-icon" />
                  </span>
                  <Form.Item name="Type">
                    <Select
                      className="w-100"
                      placeholder="Hình thức"
                      bordered={false}
                      suffixIcon={<i className="icon-Caret-down h3" />}
                      allowClear={true}
                    >
                      <Select.Option value={'Online'}>Online</Select.Option>
                      <Select.Option value={'Offline'}>Offline</Select.Option>
                    </Select>
                  </Form.Item>
                </span>
              </div>
            </div>

            <div className="col-xs-12 col-sm-12 col-md-6 col-lg-4 pl-4 pr-4 mt-2">
            <Form.Item name="Location">
                  <Input
                  placeholder="Địa điểm"
                  prefix={<i className="icon-Cursor-outline h5 feature-icon" />}
                />
                  
                  </Form.Item>
            </div>
            <div className="col-xs-12 col-sm-12 col-md-6 col-lg-4 pl-4 pr-4 mt-2">
              <Form.Item>
                <Button
                  type="primary"
                  htmlType="submit"
                  className="w-100 button-submit"
                >
                  <span className="w-100 text-center d-flex justify-content-center">
                    {' '}
                    <i className="icon-Search mr-1" /> TÌM KIẾM
                  </span>
                </Button>
              </Form.Item>
            </div>
          </div>
        </Form>
        <div />
        <div className="d-flex justify-content-between align-items-center mr-2 mt-1">
          <Checkbox
            onChange={this.onChangeCourseAvailable}
            value={this.state.showAvailable}
            className="ml-3 mt-3"
          >
            <Typography>Chỉ hiển thị các khóa học còn hạn đăng ký</Typography>
          </Checkbox>
          <div className="d-flex flex-row">
            {getValidRole(this.context.user, [USER_ROLE.SHINYAMA]) && (
              <Link to={'/course-candidate'} className="mr-3">
                <Button> <span className="w-100 text-center d-flex justify-content-center">
                    <i className="icon-University-outline mr-1" /> Quản lý học viên
                  </span></Button>
              </Link>
            )}
            {getValidRole(this.context.user, [USER_ROLE.SHINYAMA]) && (
              <Link to={'/course-form/add'}>
                <Button>+ Tạo mới khóa học</Button>
              </Link>
            )}
          </div>
        </div>

        <CourseListComponent loading={loading} value={courseList} />
        <div className="pagination-foot w-100 mt-5 d-flex flex-row flex-wrap justify-content-between">
          <div className="d-flex flex-row align-items-center mb-2">
            <Typography className="mr-1">Kết quả mỗi trang</Typography>
            <Select
              className="select-number-page"
              suffixIcon={
                <i className="icon-Caret-down h3 text-app-primary pr-3" />
              }
              value={pageSize}
              onChange={this.onChangePageSize}
            >
              <Option value="10">10</Option>
              <Option value="20">20</Option>
              <Option value="30">30</Option>
              <Option value="50">50</Option>
              <Option value="100">100</Option>
            </Select>
          </div>

          <Pagination
            current={current}
            total={total}
            pageSize={pageSize}
            showSizeChanger={false}
            onChange={this.onChangePagination}
            showTotal={(total, range) =>
              `Hiển thị ${range[0]}-${range[1]} của ${total}`
            }
          />
        </div>
      </div>
    );
  }
}

CoursePage.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  coursePage: makeSelectCoursePage(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    onEndOfAction: () => {
      dispatch(actions.endOfAction());
    },
    onGetCourseList: content => {
      dispatch(actions.getCourseList(content));
    },
    onGetLocationList: () => {
      dispatch(actions.getLocationList());
    },
    onGetFeeTypeList: () => {
      dispatch(actions.getFeeType());
    },
    onPagination: (current, pageSize) => {
      dispatch(actions.pagination(current, pageSize));
    },
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);
CoursePage.contextType = AuthContext;

const withReducer = injectReducer({ key: 'coursePage', reducer });
const withSaga = injectSaga({ key: 'coursePage', saga });
export default compose(
  withConnect,
  withReducer,
  withSaga,
)(CoursePage);
