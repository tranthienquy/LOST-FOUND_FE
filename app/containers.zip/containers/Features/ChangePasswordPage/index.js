/**
 *
 * ChangePasswordPage
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import makeSelectChangePasswordPage from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import './styles.scss';
import * as actions from './actions';

import { Card, Typography, Input, Button, Form, Spin } from 'antd';
import { Link } from 'react-router-dom';
import { Animated } from 'react-animated-css';
import { LinearProgress } from '@mui/material';
import AuthContext from '../../../utils/auth';


class ChangePasswordPage extends React.Component {
  onSubmitSearch = value => {
    this.props.onChangePassword({...value, Email:this.context.user.Email});
  };
  onFinishFailed = errorInfo =>{

  }
  repeatPassword= (_, value,sss)=>{
    console.log(_, value)
    return Promise.reject(new Error('abcd'));
  }
  render(){
    const {loading,error}= this.props.changePasswordPage;
     return (
      <div className="change-password-container">
      <Animated className="d-flex justify-content-center align-items-center w-100 h-100"
      animationIn="fadeInUp"
                animationOut=""
                isVisible={true}
                animationInDuration={500}
                animationInDelay={0}>
        <Card className="login-card">
          <div
                
                 className="d-flex flex-column justify-content-center"
              >
            <Typography className="text-center head-title font-weight-bold mt-2 mb-5">
              ĐỔI MẬT KHẨU
            </Typography>
            <Form
          name="basic"
          onFinish={this.onSubmitSearch}
          autoComplete="off"
          layout='vertical'
          onFinishFailed={this.onFinishFailed}
        >
          
          <div className="row">
            
          <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <Form.Item
        label="Mật khẩu cũ"
        name="OldPassword"
        rules={[{ required: true, message: 'Vui lòng nhập Mật khẩu' }]}
      >
        <Input type={'password'} />
      </Form.Item>
            <Form.Item
        label="Mật khẩu mới"
        name="NewPassword"
        rules={[{ required: true, message: 'Vui lòng nhập Mật khẩu' }]}
      >
        <Input type={'password'} />
      </Form.Item>
            <Form.Item
            
        label="Nhập lại mật khẩu mới"
        name="RePassword"
        rules={[{ required: true, message: 'Vui lòng nhập lại mật khẩu' },
        ({ getFieldValue }) => ({
          validator(_, value) {
            if (!value || getFieldValue('NewPassword') === value) {
              return Promise.resolve();
            }
            return Promise.reject(new Error('Mật khẩu mới không khớp'));
          },
        }),
      ]}
      >
        <Input type={'password'} />
      </Form.Item>
            </div>
          </div>
         
          <Form.Item className='mb-0'>
            <Button disabled={loading}  size="large" type="primary"  htmlType="submit" className="text-center w-100 mt-3">
              <b className="w-100 text-center"> CẬP NHẬT</b>
            </Button>
            </Form.Item>
            <div style={{height:'10px'}}>
             {loading ?  <LinearProgress color='success' />:""}
                 </div>
            
             </Form>
             {error && <Typography className='text-center' style={{color:'red'}}>{error}</Typography>}   

         </div>
        </Card>
      </Animated>
    </div>
  );
  }
 

 
}

ChangePasswordPage.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  changePasswordPage: makeSelectChangePasswordPage(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    onChangePassword: value=>{
      dispatch(actions.changePassword(value));
    }
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);


const withReducer=  injectReducer({ key: 'changePasswordPage', reducer });
const withSaga=  injectSaga({ key: 'changePasswordPage', saga });

ChangePasswordPage.contextType = AuthContext;

export default compose(withConnect, withReducer, withSaga)(ChangePasswordPage);
