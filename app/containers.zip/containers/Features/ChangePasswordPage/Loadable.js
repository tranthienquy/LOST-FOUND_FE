/**
 *
 * Asynchronously loads the component for ChangePasswordPage
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
