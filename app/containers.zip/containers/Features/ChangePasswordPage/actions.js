/*
 *
 * ChangePasswordPage actions
 *
 */

import { DEFAULT_ACTION, CHANGE_PASSWORD, CHANGE_PASSWORD_FAILED, CHANGE_PASSWORD_SUCCESS } from './constants';

export function defaultAction() {
  return {
    type: DEFAULT_ACTION,
  };
}

export const changePassword = (value) => {
  return {
    type: CHANGE_PASSWORD,
    value
  };
};
export const changePasswordSuccess = data => {
  return {
    type: CHANGE_PASSWORD_SUCCESS,
    payload: {
      data,
    },
  };
};
export const changePasswordFailed = (error) => {
  return {
    type: CHANGE_PASSWORD_FAILED,
    error
  };
};