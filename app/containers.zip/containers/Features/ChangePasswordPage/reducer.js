/*
 *
 * ChangePasswordPage reducer
 *
 */
import produce from 'immer';
import { DEFAULT_ACTION, CHANGE_PASSWORD, CHANGE_PASSWORD_FAILED, CHANGE_PASSWORD_SUCCESS } from './constants';

export const initialState = {
  loading:false,
  error: ''
};

/* eslint-disable default-case, no-param-reassign */
const changePasswordPageReducer = (state = initialState, action) =>
  produce(state,  draft => {
    switch (action.type) {
      case DEFAULT_ACTION:
        break;
        case CHANGE_PASSWORD:
          draft.loading= true;
          break;
        case CHANGE_PASSWORD_SUCCESS:
          draft.loading= false;
       
          break;
        case CHANGE_PASSWORD_FAILED:
          draft.loading= false;
          switch(action.error){
            case 'password-failed': draft.error="Mật khẩu không khớp"; break;
            case 'password-duplicated': draft.error="Vui lòng tạo mật khẩu mới khác mật khẩu cũ"; break;
          }
        
          break;
    }
  });

export default changePasswordPageReducer;
