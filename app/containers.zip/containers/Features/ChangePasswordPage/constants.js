/*
 *
 * ChangePasswordPage constants
 *
 */

export const DEFAULT_ACTION = 'app/ChangePasswordPage/DEFAULT_ACTION';
export const CHANGE_PASSWORD = 'app/ChangePasswordPage/CHANGE_PASSWORD';
export const CHANGE_PASSWORD_SUCCESS = 'app/ChangePasswordPage/CHANGE_PASSWORD_SUCCESS';
export const CHANGE_PASSWORD_FAILED = 'app/ChangePasswordPage/CHANGE_PASSWORD_FAILED';
