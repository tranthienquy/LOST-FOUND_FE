/*
 *
 * RecruitmentRequestPage constants
 *
 */

export const DEFAULT_ACTION = 'app/RecruitmentRequestPage/DEFAULT_ACTION';
export const END_OF_ACTION = 'app/RecruitmentRequestPage/END_OF_ACTION';
