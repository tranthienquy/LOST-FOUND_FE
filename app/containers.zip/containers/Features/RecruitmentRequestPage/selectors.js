import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the recruitmentRequestPage state domain
 */

const selectRecruitmentRequestPageDomain = state =>
  state.recruitmentRequestPage || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by RecruitmentRequestPage
 */

const makeSelectRecruitmentRequestPage = () =>
  createSelector(
    selectRecruitmentRequestPageDomain,
    substate => substate,
  );

export default makeSelectRecruitmentRequestPage;
export { selectRecruitmentRequestPageDomain };
