/**
 *
 * RecruitmentRequestPage
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import makeSelectRecruitmentRequestPage from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import * as actions from './actions';
import RecruitmentRequestRecruiterPage from '../RecruitmentRequestRecruiterPage';
import './styles.scss';
import { Button, Typography } from 'antd';
import { Link } from 'react-router-dom';
class RecruitmentRequestPage extends React.Component {
  componentWillUnmount() {
    this.props.onEndOfAction();
  }

  render() {
    return (
      <div className="recruitment-request-container d-flex flex-column pt-5">
        <Button htmlType='submit'></Button>
          <div className="d-flex justify-content-between ">
            <Typography className="text-app-primary h4 font-weight-bold">
              DANH SÁCH YÊU CẦU TUYỂN DỤNG
            </Typography>
            <Link to={'/recruitment-request-recruiter/add'}>
              <Button> + Tạo mới yêu cầu tuyển dụng </Button>
            </Link>
          </div>
          <div className="d-flex justify-content-end ">
            {/* <Button> Xuất Excel </Button> */}
          </div>
      <RecruitmentRequestRecruiterPage/>
      </div>
    );
  }
}

RecruitmentRequestPage.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  recruitmentRequestPage: makeSelectRecruitmentRequestPage(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    onEndOfAction: () => {
      dispatch(actions.endOfAction());
    },
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

const withReducer = injectReducer({ key: 'recruitmentRequestPage', reducer });
const withSaga = injectSaga({ key: 'recruitmentRequestPage', saga });
export default compose(
  withConnect,
  withReducer,
  withSaga,
)(RecruitmentRequestPage);
