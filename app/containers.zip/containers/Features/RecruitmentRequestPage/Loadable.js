/**
 *
 * Asynchronously loads the component for RecruitmentRequestPage
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
