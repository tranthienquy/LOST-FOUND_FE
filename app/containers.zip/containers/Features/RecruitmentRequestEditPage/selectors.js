import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the recruitmentRequestEditPage state domain
 */

const selectRecruitmentRequestEditPageDomain = state => state.recruitmentRequestEditPage || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by RecruitmentRequestEditPage
 */

const makeSelectRecruitmentRequestEditPage = () =>
  createSelector(
    selectRecruitmentRequestEditPageDomain,
    substate => substate,
  );

export default makeSelectRecruitmentRequestEditPage;
export { selectRecruitmentRequestEditPageDomain };
