/*
 *
 * RecruitmentRequestEditPage constants
 *
 */

export const DEFAULT_ACTION = 'app/RecruitmentRequestEditPage/DEFAULT_ACTION';
export const END_OF_ACTION = 'app/RecruitmentRequestEditPage/END_OF_ACTION';

export const GET_CONTENT = 'app/RecruitmentRequestEditPage/GET_CONTENT';
export const GET_CONTENT_SUCCESS = 'app/RecruitmentRequestEditPage/GET_CONTENT_SUCCESS';
export const GET_CONTENT_FAILED = 'app/RecruitmentRequestEditPage/GET_CONTENT_FAILED';

export const GET_PROFESSION = 'app/RecruitmentRequestEditPage/GET_PROFESSION';
export const GET_PROFESSION_SUCCESS = 'app/RecruitmentRequestEditPage/GET_PROFESSION_SUCCESS';
export const GET_PROFESSION_FAILED = 'app/RecruitmentRequestEditPage/GET_PROFESSION_FAILED';

export const GET_SKILL = 'app/RecruitmentRequestEditPage/GET_SKILL';
export const GET_SKILL_SUCCESS = 'app/RecruitmentRequestEditPage/GET_SKILL_SUCCESS';
export const GET_SKILL_FAILED = 'app/RecruitmentRequestEditPage/GET_SKILL_FAILED';

export const GET_LOCATION = 'app/RecruitmentRequestEditPage/GET_LOCATION';
export const GET_LOCATION_SUCCESS = 'app/RecruitmentRequestEditPage/GET_LOCATION_SUCCESS';
export const GET_LOCATION_FAILED = 'app/RecruitmentRequestEditPage/GET_LOCATION_FAILED';

export const GET_COMPANY = 'app/RecruitmentRequestEditPage/GET_COMPANY';
export const GET_COMPANY_SUCCESS = 'app/RecruitmentRequestEditPage/GET_COMPANY_SUCCESS';
export const GET_COMPANY_FAILED = 'app/RecruitmentRequestEditPage/GET_COMPANY_FAILED';

export const SUBMIT_CONTENT = 'app/RecruitmentRequestEditPage/SUBMIT_CONTENT';
export const SUBMIT_CONTENT_SUCCESS = 'app/RecruitmentRequestEditPage/SUBMIT_CONTENT_SUCCESS';
export const SUBMIT_CONTENT_FAILED = 'app/RecruitmentRequestEditPage/SUBMIT_CONTENT_FAILED';

export const UPLOAD_FILE = 'app/RecruitmentRequestEditPage/UPLOAD_FILE';
export const DELETE_FILE = 'app/RecruitmentRequestEditPage/DELETE_FILE';


export const CLOSE_REQUEST = 'app/RecruitmentRequestEditPage/CLOSE_REQUEST';
export const CLOSE_REQUEST_SUCCESS = 'app/RecruitmentRequestEditPage/CLOSE_REQUEST_SUCCESS';
export const CLOSE_REQUEST_FAILED = 'app/RecruitmentRequestEditPage/CLOSE_REQUEST_FAILED';