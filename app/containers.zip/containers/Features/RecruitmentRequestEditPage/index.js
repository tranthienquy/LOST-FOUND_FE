/**
 *
 * RecruitmentRequestEditPage
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import makeSelectRecruitmentRequestEditPage from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import * as actions from './actions';
import './styles.scss';
import AuthContext from '../../../utils/auth';
import { withRouter, Link } from 'react-router-dom';
import {
  Button,
  Card,
  Typography,
  Tag,
  Modal,
  Form,
  Input,
  Select,
  Skeleton,
  DatePicker,
  List,
  Upload,
  Tooltip
} from 'antd';
import moment from 'moment';
import JobDetailSkeleton from '../JobDetailPage/JobDetailSkeleton';
import { Helmet } from 'react-helmet';
import { LinearProgress } from '@mui/material';

class RecruitmentRequestEditPage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      duplicateCV: false,
    };
  }
  componentWillMount() {
    this.props.onGetCompany(this.context.user.CompanyId);
    this.props.onGetProfessionList()
    const { id } = this.props.match.params;
    if (id) {
      this.props.onGetContent(id);
    }
  }
  componentWillReceiveProps(nextProps) {
    const { id } = nextProps.match.params;
    if (nextProps.match.params !== this.props.match.params) {
      if (id) {
        this.props.onGetContent(id);
      }
    }
  }

  componentWillUnmount() {
    this.props.onEndOfAction();
  }
  componentDidMount() {
    this.props.onGetLocationList();
  }
  onSubmit = value => {
    this.props.onSubmitContent(value);
  };

  onSubmitFailed = error => {};

  searchProfession = value => {
    this.props.onGetProfessionList(value);
  };
  searchSkill = value => {
    this.props.onGetSkillList(value);
  };

  onSubmitFailed = errorInfo => {};
  onUpFile = async value => {
    if (this.state.duplicateCV) {
      this.props.onUploadFile(value.file);
    }
    this.setState({ duplicateCV: !this.state.duplicateCV });
  };

  downloadFile = file => {
    saveAs(file.originFileObj, file.name);
  };
  render() {
    const {
      loading,
      professionList,
      locationList,
      id,
      company,
      skillList,
      content,
      fileList,
    } = this.props.recruitmentRequestEditPage;
    return (
      <div className="job-form-container d-flex flex-column pt-5">
        <Helmet>
          <title>
            {id ? 'Cập nhật yêu cầu tuyển dụng' : 'Tạo yêu cầu tuyển dụng'}
          </title>
        </Helmet>
        <div className="d-flex ">
          <Typography.Text
            className="link-text-on-click"
            type="secondary"
            onClick={() => this.props.history.goBack()}
          >
            <i className="icon-Caret-left" /> Quay lại
          </Typography.Text>
          <Typography className="ml-2">
            {' '}
            /{' '}
            {id
              ? `Chỉnh sửa yêu cầu tuyển dụng mã ${id}`
              : `Tạo mới yêu cầu tuyển dụng`}
          </Typography>
        </div>
        {loading.content && id ? (
          <JobDetailSkeleton />
        ) : (
          <Form
            name="basic"
            onFinish={this.onSubmit}
            autoComplete="off"
            layout="vertical"
            initialValues={content}
            onFinishFailed={this.onSubmitFailed}
            className="ant-general-form"
          >
            <div className="row">
              <div className="d-flex flex-column pr-5 col-xs-12 col-sm-12 col-md-12 col-lg-9">
                <Card
                  size="small"
                  className="card-description mt-4"
                  title={
                    <Typography
                      style={{ fontSize: '24px' }}
                      className=" text-app-primary font-weight-bold mt-2 d-flex align-items-center"
                    >
                      <i
                        style={{ fontSize: '29px' }}
                        className=" mr-2 icon-Star-outline"
                      />
                      THÔNG TIN CHUNG
                    </Typography>
                  }
                >
                  <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                      <Form.Item
                        label="Tên công việc"
                        name="Title"
                        rules={[
                          {
                            required: true,
                            message: 'Vui lòng nhập Tên công ty',
                          },
                        ]}
                      >
                        <Input size="large" />
                      </Form.Item>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                      <Form.Item
                        label="Tag"
                        name="Tag"
                       
                      >
                        <Input size="large" />
                      </Form.Item>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                      <Form.Item
                        label="Ngành nghề"
                        name="Profession"
                        rules={[
                          {
                            required: true,
                            message: 'Vui lòng nhập Ngành nghề',
                          },
                        ]}
                      >
                        <Select
                          onSearch={this.searchProfession}
                          showSearch
                          filterOption={false}
                          notFoundContent={''}
                          suffixIcon={<i className="icon-Caret-down h3" />}
                          
                        >
                          {professionList &&
                            professionList.map(item => (
                              <Select.Option
                                value={item.TKey}
                                key={`options-profession-${item.Id}`}
                              >
                                {item.TValue}
                              </Select.Option>
                            ))}
                          {loading.profession && (
                            <Select.Option disabled>Đang tải...</Select.Option>
                          )}
                        </Select>
                      </Form.Item>
                    </div>
                    <div className="col-xs-12 col-sm-12 col-md-12 col-lg-8">
                      <Form.Item
                        label="Thành phố"
                        name="City"
                      
                        rules={[
                          {
                            required: true,
                            message: 'Vui lòng nhập Thành phố',
                          },
                        ]}
                      >
                        <Select
                          suffixIcon={<i className="icon-Caret-down h3" />}
                          maxTagCount="responsive"
                          mode='multiple'
                        >
                          {locationList &&
                            locationList.map(item => (
                              <Select.Option
                                value={item.TKey}
                                key={`options-nationality-${item.Id}`}
                              >
                                {item.TValue}
                              </Select.Option>
                            ))}
                          {loading.location && (
                            <Select.Option disabled>Đang tải...</Select.Option>
                          )}
                        </Select>
                      </Form.Item>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                      <Form.Item label="Địa điểm làm việc" name="Location">
                        <Input />
                      </Form.Item>
                    </div>
                  </div>
                </Card>

                <Card
                  size="small"
                  className="card-description mt-4"
                  title={
                    <Typography
                      style={{ fontSize: '24px' }}
                      className=" text-app-primary font-weight-bold mt-2 d-flex align-items-center"
                    >
                      <i
                        style={{ fontSize: '29px' }}
                        className=" mr-2 icon-Star-outline"
                      />
                      CÔNG VIỆC
                    </Typography>
                  }
                >
                  <div className="row">
                    
                    <div className="col-xs-12 col-sm-12 col-md-12 col-lg-4">
                      <Form.Item
                        label="Số lượng"
                        name="Quantity"
                      >
                        <Input type={'number'} min={1} />
                      </Form.Item>
                    </div>
                    <div className="col-xs-12 col-sm-12 col-md-12 col-lg-4">
                      <Form.Item
                        label="Số năm kinh nghiệm"
                        name="WorkExperience"
                      >
                        <Input type={'number'} min={1} />
                      </Form.Item>
                    </div>
                    <div className="col-xs-12 col-sm-12 col-md-12 col-lg-4">
                      <Form.Item
                        label="Ngày hết hạn tuyển dụng "
                        name="DueDate"
                        rules={[
                          {
                            required: true,
                            message: 'Vui lòng nhập Ngày hết hạn tuyển dụng',
                          },
                        ]}
                      >
                        <DatePicker className="w-100" />
                      </Form.Item>
                    </div>
                    <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                      <Form.Item
                        label="Kỹ năng"
                        name="Skills"
                        rules={[
                          { required: true, message: 'Vui lòng nhập Kỹ năng' },
                        ]}
                      >
                        <Select
                          mode="multiple"
                          onSearch={this.searchSkill}
                          notFoundContent={''}
                          filterOption={false}
                          suffixIcon={<i className="icon-Caret-down h3" />}
                        >
                          {skillList &&
                            skillList.map(item => (
                              <Select.Option
                                value={item.TKey}
                                key={`options-skill-${item.TKey}`}
                              >
                                {item.TValue}
                              </Select.Option>
                            ))}
                          {loading.skill && (
                            <Select.Option disabled>Đang tải...</Select.Option>
                          )}
                        </Select>
                      </Form.Item>
                    </div>
                  </div>
                </Card>
                <Card
                  size="small"
                  className="card-description mt-4"
                  title={
                    <Typography
                      style={{ fontSize: '24px' }}
                      className=" text-app-primary font-weight-bold mt-2 d-flex align-items-center"
                    >
                      <i
                        style={{ fontSize: '29px' }}
                        className=" mr-2 icon-Box-outline"
                      />
                      TÀI LIỆU THAM KHẢO
                    </Typography>
                  }
                >
                  <Upload.Dragger
                    customRequest={({ file, onSuccess }) => {
                      setTimeout(() => {
                        onSuccess('ok');
                      }, 0);
                    }}
                    height={'200px'}
                    showUploadList={false}
                    action={''}
                    className="drop-file-avatar mb-4"
                    onChange={this.onUpFile}
                  >
                    <Typography className="ant-upload-text">
                      Tải tài liệu đính kèm tại đây
                    </Typography>
                    <i className="icon-Cloud-upload-outline h1 text-app-primary" />
                  </Upload.Dragger>

                  <List
                    dataSource={fileList}
                    className="w-100"
                    renderItem={item => (
                      <div
                        className="d-flex flex-row justify-content-between align-items-center list-item"
                        style={{
                          backgroundColor: item.originFileObj && '#edffe6',
                        }}
                      >
                        <Typography className="d-flex flex-row mt-2 pl-2 ">
                          <i className="icon-Document-outline mr-2 h5 " />
                          <span>
                            {item.originFileObj ? item.name : item.Link}
                          </span>
                          {/* <i className='ml-2' style={{color:'#aeaeae'}}>18/6/2002</i> */}
                        </Typography>
                        <div>
                          {/* <Tooltip placement="top" title={'Xem'}>
                   <i className="icon-Eye-outline cursor-pointer h4" onClick={()=>this.props.onPreviewModal(true, item)} />
                   </Tooltip> */}
                          <Tooltip
                            placement="top"
                            title={'Tải về'}
                            onClick={() => {
                              item.Id
                                ? window.open(
                                    `${this.context.prefixLink}/${item.Link}`,
                                  )
                                : this.downloadFile(item);
                            }}
                          >
                            <i className="icon-Download-outline cursor-pointer h4" />
                          </Tooltip>
                          <Tooltip
                            placement="top"
                            title={'Xóa'}
                            onClick={() => this.props.onDeleteFile(item)}
                          >
                            <i className="icon-Trash-outline cursor-pointer mr-2 h4" />
                          </Tooltip>
                        </div>
                      </div>
                    )}
                  />
                </Card>
                <div className='row'>
                  
                  <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                  <Form.Item className="mb-0">
                  <Button
                    disabled={loading.submit}
                    size="large"
                    type="primary"
                    htmlType="submit"
                    className="text-center w-100 mt-3"
                  >
                    <b className="w-100 text-center">
                      {id
                        ? 'CẬP NHẬT YÊU CẦU TUYỂN DỤNG'
                        : '+  TẠO MỚI YÊU CẦU TUYỂN DỤNG'}
                    </b>
                  </Button> </Form.Item>
                  <div style={{ height: '10px' }}>
                  {loading.submit ? <LinearProgress color="success" /> : ''}
                </div>
                  </div>
                  
                  <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
              
               
                  <Button
                    size="large"
                    type="primary"
                    className="text-center w-100 mt-3"
                    onClick={()=>this.props.onCloseRequest()}
                  >
                      <b className="w-100 text-center">
                  ĐÓNG YÊU CẦU</b>
                  </Button>
                  <div style={{ height: '10px' }}>
                  {loading.closeRequest ? <LinearProgress color="success" /> : ''}
                </div>
                  </div>

                </div>
               
               
              </div>
              <div className="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <Card hoverable className="company-card">
                  {loading.company ? (
                    <Skeleton active />
                  ) : (
                    <div className="d-flex flex-column">
                      {company.Avatar && (
                        <img
                          src={
                            company.Avatar ? (company.Avatar.startsWith('http')? company.Avatar: `${this.context.prefixLink}/${company.Avatar}`): require('../../../images/logo/logo-shinyama-grayscale.png')
                          }
                          width={'100%'}
                          height={'150px'}
                          style={{ objectFit: 'cover' }}
                        />
                      )}

                      <div className="p-2">
                        <Typography className="h7 font-weight-bold mb-2">
                          {company.Name}
                        </Typography>
                        <Typography
                          style={{ fontSize: '12px' }}
                          className="d-flex align-items-center text-app-primary"
                        >
                          <i
                            style={{ fontSize: '17px' }}
                            className="mr-1 icon-Location"
                          />
                          {company.Location}
                        </Typography>
                        <Typography
                          style={{ fontSize: '12px' }}
                          className="d-flex align-items-center text-app-primary"
                        >
                          <i
                            style={{ fontSize: '17px' }}
                            className="mr-1 icon-Contacts"
                          />
                          {company.Size} người
                        </Typography>
                      </div>
                    </div>
                  )}
                </Card>
            
              </div>
            </div>
          </Form>
        )}
      </div>
    );
  }
}

RecruitmentRequestEditPage.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  recruitmentRequestEditPage: makeSelectRecruitmentRequestEditPage(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    onEndOfAction: () => {
      dispatch(actions.endOfAction());
    },
    onGetContent: id => {
      dispatch(actions.getContent(id));
    },
    onSubmitContent: value => {
      dispatch(actions.submitContent(value));
    },
    onGetCompany: id => {
      dispatch(actions.getCompany(id));
    },
    onGetProfessionList: () => {
      dispatch(actions.getProfessionList());
    },
    onGetSkillList: content => {
      dispatch(actions.getSkillList(content));
    },
    onGetLocationList: () => {
      dispatch(actions.getLocationList());
    },
    onUploadFile: file => {
      dispatch(actions.uploadFile(file));
    },
    onDeleteFile: file => {
      dispatch(actions.deleteFile(file));
    },
    onCloseRequest: () => {
      dispatch(actions.closeRequest());
    },
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

const withReducer = injectReducer({
  key: 'recruitmentRequestEditPage',
  reducer,
});
const withSaga = injectSaga({ key: 'recruitmentRequestEditPage', saga });
RecruitmentRequestEditPage.contextType = AuthContext;

export default compose(
  withConnect,
  withReducer,
  withSaga,
  withRouter,
)(RecruitmentRequestEditPage);
