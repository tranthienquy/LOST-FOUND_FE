/**
 *
 * Asynchronously loads the component for RecruitmentRequestEditPage
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
