import {
  take,
  call,
  put,
  select,
  takeLatest,
  delay,
  fork,
  takeEvery,
} from 'redux-saga/effects';
import * as types from './constants';
import * as actions from './actions';
import * as api from 'utils/api';
import { KEY_VALUE } from '../../../utils/api/constants';
import { notification } from 'antd';
import { push } from 'react-router-redux';
import moment from 'moment';


function* getProfessionList() {
  yield delay(500);

  const resp = yield call(
    api.postPagination,
    `v1/KeyValues`,
    null,
    null,
    `TGroup eq ${
      KEY_VALUE.PROFESSION
    }`,
    null,
  );
  const { data, status } = resp;
  if (status == 200) {
    yield put(actions.getProfessionListSuccess(data));
  } else {
    yield put(actions.getProfessionListFailed());
  }
}


function* getSkillList({ content }) {
  if (content && content.length > 0) {
    yield delay(500);
    let searchFilter = '';
    if (typeof content == 'string') {
      // Search by TValue
      searchFilter = `contains(tolower(TValue),tolower('${encodeURIComponent(
        content,
      )}'))`;
    } else {
      // Search by TKey Array
      content.forEach(el => {
        searchFilter += `contains(tolower(TKey),tolower('${encodeURIComponent(
          el,
        )}')) or `;
      });
      searchFilter = searchFilter.slice(0, -3);
    }
    const resp = yield call(
      api.postPagination,
      `v1/KeyValues`,
      null,
      null,
      `TGroup eq ${KEY_VALUE.SKILL} and ` + searchFilter,
      null,
    );
    const { data, status } = resp;
    if (status == 200) {
      yield put(actions.getSkillListSuccess(data));
    } else {
      yield put(actions.getSkillListFailed());
    }
  }
}

function* getLocationList() {
  const resp = yield call(
    api.postPagination,
    `v1/KeyValues`,
    null,
    null,
    `TGroup eq ${KEY_VALUE.LOCATION}`,
    null,
  );
  const { data, status } = resp;
  if (status == 200) {
    yield put(actions.getLocationListSuccess(data));
  } else {
    yield put(actions.getLocationListFailed());
  }
}

function* getContent({ id }) {
  yield delay(1000);
  const resp = yield call(api.get, `v1/Requests(${id})?$expand=FileStorages(filter = status ne 0)`);
  const { data, status } = resp;

  if (status == 200) {
    yield put(actions.getContentSuccess({ ...data }));
    yield put(actions.getSkillList(data.Skills));
  } else {
    yield put(actions.getContentFailed());
  }
}
function* submitContent({ value }) {
  const { id } = yield select(state => state.recruitmentRequestEditPage);

  const requestData = {
    ...value,
    DueDate: moment(value.DueDate).toDate(),
    ListSkill: value.Skills,
    WorkExperience: Number.parseInt(value.WorkExperience),
    City: JSON.stringify(value.City),
  };
  if (id) {
    const resp = yield call(api.put, `v1/Requests(${id})`, {}, requestData);
    const { data, status } = resp;
    console.log(resp);
    if (status == 200) {
      yield removeFiles();
      yield uploadFiles(data.Id);
      yield delay(200);
      yield put(actions.submitContentSuccess(data));
      yield notification.open({
        message: 'Cập nhật yêu cầu thành công',
      });
      yield put(push('/recruitment-request-recruiter'));
    } else {
      yield put(actions.submitContentFailed(''));
    }

  }
}

function* getCompany({ id }) {
  yield delay(500);
  const resp = yield call(api.get, `v1/Companies(${id})`);
  const { data, status } = resp;

  if (status == 200) {
    yield put(actions.getCompanySuccess({ ...data }));
  } else {
    yield put(actions.getCompanyFailed());
  }
}

function* uploadFiles(id) {
  const { fileList } = yield select(state => state.recruitmentRequestEditPage);

  let dataFile = yield new FormData();
  let listNewFiles = yield [];
  yield fileList.forEach(element => {
    if (element.originFileObj) {
      listNewFiles.push(element.originFileObj);
      dataFile.append('files', element.originFileObj);
    }
  });
  if (listNewFiles.length > 0) {
    const resp = yield call(
      api.put,
      `v1/Requests(${id})/upload-multi-file`,
      {},
      dataFile,
      { 'Content-Type': 'multipart/form-data' },
    );
    const { data, status } = resp;

    if (status == 200) {
    } else {
      yield put(actions.submitContentFailed());
    }
  }
}

function* removeFiles() {

  const { removeFileList , id} = yield select(state => state.recruitmentRequestEditPage);
  yield console.log(removeFileList,  removeFileList.map(el=>el.Id) )
  if(removeFileList.length>0){

    const resp = yield call(
      api.put,
      `v1/Requests(${id})/deleteFiles`,
      {},
      removeFileList.map(el=>el.Id),
      { 'Content-Type': 'multipart/form-data' },
    );
    const { data, status } = resp;

    if (status == 200) {
    } else {
      yield put(actions.submitContentFailed());
    }
  }
}

function* closeRequest() {
  const { id} = yield select(state => state.recruitmentRequestEditPage);
  const resp = yield call(api.post, `v1/Requests(${id})/close-request`, {});
    const { data, status } = resp;
    console.log(resp);
    if (status == 200) {
      yield delay(1000);
      yield put(actions.closeRequestSuccess(data));
      yield notification.open({
        message: 'Đóng yêu cầu thành công',
        type:'success'
      });
      yield put(push('/recruitment-request-recruiter'));
    } else {
      yield put(actions.submitContentFailed(''));
    }
}

// Individual exports for testing
export default function* recruitmentRequestEditPageSaga() {
  // See example in containers/HomePage/saga.js
  yield takeLatest(types.GET_PROFESSION, getProfessionList);
  yield takeLatest(types.GET_SKILL, getSkillList);
  yield takeLatest(types.GET_LOCATION, getLocationList);
  yield takeLatest(types.GET_CONTENT, getContent);
  yield takeLatest(types.SUBMIT_CONTENT, submitContent);
  yield takeLatest(types.GET_COMPANY, getCompany);
  yield takeLatest(types.CLOSE_REQUEST, closeRequest);
}
