import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the courseCandidatePage state domain
 */

const selectCourseCandidatePageDomain = state =>
  state.courseCandidatePage || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by CourseCandidatePage
 */

const makeSelectCourseCandidatePage = () =>
  createSelector(
    selectCourseCandidatePageDomain,
    substate => substate,
  );

export default makeSelectCourseCandidatePage;
export { selectCourseCandidatePageDomain };
