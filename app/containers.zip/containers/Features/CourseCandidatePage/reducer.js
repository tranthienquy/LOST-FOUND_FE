/*
 *
 * CourseCandidatePage reducer
 *
 */
import produce from 'immer';
import * as types from './constants';

export const initialState = {
  candidateList: [],
  loading:{
    getContent: true,
    submit: false,
  },
  current: 1,
  pageSize: 10,
  total: 0,
};

/* eslint-disable default-case, no-param-reassign */
const courseCandidatePageReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case types.DEFAULT_ACTION:
        break;
      case types.END_OF_ACTION:
        for (var element in draft) {
          draft[element] = initialState[element];
        }
        break;
        case types.CHANGE_SELECT_VALUE:
          draft.candidateList.find(el=> el.Id=== action.id)[action.name] = action.value;  
        break;
        case types.PAGINATION:
          draft.current = action.current;
          draft.pageSize = action.pageSize;
          break;

        case types.GET_CONTENT:
          draft.loading.getContent = true;
          break;
        case types.GET_CONTENT_SUCCESS:
          draft.loading.getContent = false;
          draft.total = action.payload.data['@odata.count'];
          draft.candidateList = action.payload.data.value;
          break;
        case types.GET_CONTENT_FAILED:
          draft.loading.getContent = false;
          break;

          case types.SUBMIT_CONTENT:
            draft.loading.submit = true;
            break;
          case types.SUBMIT_CONTENT_SUCCESS:
            draft.loading.submit = false;
    
            break;
          case types.SUBMIT_CONTENT_FAILED:
            draft.loading.submit = false;
            break;
    }
  });

export default courseCandidatePageReducer;
