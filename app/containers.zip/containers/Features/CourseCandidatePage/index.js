/**
 *
 * CourseCandidatePage
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import makeSelectCourseCandidatePage from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import * as actions from './actions';
import './styles.scss';
import { Input, Table, Typography, Form, Button, DatePicker, Tabs, Select, Checkbox } from 'antd';
import { Link } from 'react-router-dom';
import { LinearProgress } from '@mui/material';

class CourseCandidatePage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showAvailable: false,
      valueSearch: null, 
     
    };
  }
  formRef = React.createRef();
  componentWillUnmount() {
    this.props.onEndOfAction();
  }
  componentWillMount(){
    this.props.onGetContentList();
  }
  onSelectChange = ()=>{
    this.props.onGetContentList(this.formRef.current.getFieldsValue())
  }
  changeSelectValue = (event, id)=>{
this.props.onChangeSelectValue(id, event.target.name, event.target.checked)
  }
  columns = [
    {
      title: 'Id',
      key: 'Id',
      dataIndex: 'Id',
    },

    {
      title: 'Tên khóa học',
      children: [
        {
          title: (
            <Form.Item name="CourseName">
              <Input  />
            </Form.Item>
          ),
          key: 'Course',
          dataIndex: 'Course',
          render:(value,record)=> <span>{value.Name}</span>
        },
      ],
     
    },
 
    {
      title: 'Hình thức',
      children: [
        {
          title: (
            <Form.Item name="Type">
              <Select
              onChange={this.onSelectChange}
                            suffixIcon={<i className="icon-Caret-down h3" />}
                          >
                            <Select.Option value={'Online'}>
                              Online
                            </Select.Option>
                            <Select.Option value={'Offline'}>
                              Offline
                            </Select.Option>
                          </Select>
            </Form.Item>
          ),
          key: 'Course',
          dataIndex: 'Course',
          render:(value,record)=> <span>{value.Type}</span>

        },
      ],
    },
    {
      title: 'Tên học viên',
      children: [
        {
          title: (
            <Form.Item name="UserProfileName">
              <Input />
            </Form.Item>
          ),
          key: 'UserProfile',
          dataIndex: 'UserProfile',
          render:(value,record)=> <span>{value.FirstName} {value.LastName}</span>

        },
      ],
    },
  
    {
      title: 'Email',
      children: [
        {
          title: (
            <Form.Item name="Email">
              <Input  />
            </Form.Item>
          ),
          key: 'UserProfile',
          dataIndex: 'UserProfile',
          render:(value,record)=> <span>{value.Account.Email} </span>

        },
      ],
    },
    {
      title:'Đã đăng ký',
      key: 'Title',
      dataIndex: 'Title',
      render: ()=><Checkbox style={{cursor:'not-allowed'}} checked={true}/>
    },
    {
      title: 'Đã nộp tiền',
      children: [
        {
          title: (
            <Form.Item name="IsPayFee">
               <Select
                    onChange={this.onSelectChange}
                            suffixIcon={<i className="icon-Caret-down h3" />}
                          >
                            <Select.Option value={true}>
                              Có
                            </Select.Option>
                            <Select.Option value={false}>
                              Không
                            </Select.Option>
                          </Select>
            </Form.Item>
          ),
          key: 'IsPayFee',
          dataIndex: 'IsPayFee',
          width:100,

          render: (value,record)=><span><Checkbox name='IsPayFee' onChange={()=>this.changeSelectValue(event, record.Id )} checked={value}/></span>

        },
      ],
    },
    {
      title: 'Đang học',
      children: [
        {
          title: (
            <Form.Item name="IsLearning">
                      <Select
                           onChange={this.onSelectChange}
                            suffixIcon={<i className="icon-Caret-down h3" />}
                          >
                            <Select.Option value={true}>
                              Có
                            </Select.Option>
                            <Select.Option value={false}>
                              Không
                            </Select.Option>
                          </Select>
            </Form.Item>
          ),
          key: 'IsLearning',
          dataIndex: 'IsLearning',
          width:100,

          render: (value, record)=><span><Checkbox name="IsLearning"  onChange={()=>this.changeSelectValue(event, record.Id )} checked={value}/></span>
        },
      ],
    },
    {
      title: 'Hoàn thành',
      children: [
        {
          title: (
            <Form.Item name="IsFinished">
                     <Select
                          onChange={this.onSelectChange}
                     allowClear={true}
                            suffixIcon={<i className="icon-Caret-down h3" />}
                          >
                            <Select.Option value={true}>
                              Có
                            </Select.Option>
                            <Select.Option value={false}>
                              Không
                            </Select.Option>
                          </Select>
            </Form.Item>
          ),
          width:100,
          key: 'IsFinished',
          dataIndex: 'IsFinished',
          render: (value, record)=><span><Checkbox name='IsFinished' onChange={()=>this.changeSelectValue(event, record.Id )} c checked={value}/></span>

        },
      ],
    },
   
    
  ];
  dataSource = [
    {
      ID: '1',
      Title: (
        <Form.Item name="Title">
          <Input name="Title" />
        </Form.Item>
      ),
    },
  ];
  onSubmit = value => {
    console.log(value);
    this.setState({ valueSearch: value });

    this.props.onGetContentList(value);
  };
  onSubmitFailed = errorInfo => {};
  handleTableChange = (newPagination, filters, sorter)=>{
    console.log(newPagination, filters, sorter );
    this.props.onPagination(newPagination.current, newPagination.pageSize)
    this.props.onGetContentList({...this.state.valueSearch});

} 
onChangeCourseAvailable = async value => {
  await this.setState({ showAvailable: !this.state.showAvailable });
  await this.props.onGetContentList({
    ...this.state.valueSearch,
    showAvailable: this.state.showAvailable,
  });
};
render() {
    const{candidateList, loading, total,current,  pageSize}= this.props.courseCandidatePage;
    return (
      <div className="course-candidate-request-container d-flex flex-column">
     
     <Form
       name="basic"
       onFinish={this.onSubmit}
       autoComplete="off"
       layout="vertical"
       initialValues={{}}
       onFinishFailed={this.onSubmitFailed}
       className="ant-general-form"
       ref={this.formRef} 
     >
       <div className="d-flex justify-content-between ">
         <Typography className="text-app-primary h4 font-weight-bold">
           DANH SÁCH KHÓA HỌC - HỌC VIÊN
         </Typography>
         <Button className='d-flex align-items-center'><i className='icon-Clipboard-alt-outline'></i> <span>Xuất Excel</span>  </Button>
        
       </div>
      <Checkbox
            onChange={this.onChangeCourseAvailable}
            value={this.state.showAvailable}
            className=" mt-3"
          >
            <Typography>Hiển thị các khóa học đã kết thúc</Typography>
          </Checkbox>
      <Button htmlType='submit'></Button>

       <Table
       loading={loading.getContent}
         className="mt-5"
         columns={this.columns}
         dataSource={candidateList}
         sticky={true}
         pagination={{total,current, pageSize}}
         onChange={this.handleTableChange}
         
       >
       </Table>
       <Form.Item className="mb-0">
                <Button
                  disabled={loading.submit}
                  onClick={()=>this.props.onSubmitContent()}
                  size="large"
                  type="primary"
                  htmlType="submit"
                  className="text-center w-100 mt-3"
                >
                  <b className="w-100 text-center">
                   XÁC NHẬN
                  </b>
                </Button>
              </Form.Item>
              <div style={{ height: '10px' }}>
                {loading.submit ? <LinearProgress color="success" /> : ''}
              </div>
     </Form>
   </div>
    );
  }
}

CourseCandidatePage.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  courseCandidatePage: makeSelectCourseCandidatePage(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    onEndOfAction: () => {
      dispatch(actions.endOfAction());
    },
    onGetContentList: content => {
      dispatch(actions.getContentList(content));
    },
    onPagination: (current, pageSize) => {
      dispatch(actions.pagination(current, pageSize));
    },
    onChangeSelectValue: (id, name, value) => {
      dispatch(actions.changeSelectValue(id, name, value));
    },
    onSubmitContent: () => {
      dispatch(actions.submitContent());
    },
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

const withReducer = injectReducer({ key: 'courseCandidatePage', reducer });
const withSaga = injectSaga({ key: 'courseCandidatePage', saga });
export default compose(
  withConnect,
  withReducer,
  withSaga,
)(CourseCandidatePage);
