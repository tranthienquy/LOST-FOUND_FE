/*
 *
 * CourseCandidatePage actions
 *
 */

import { CHANGE_SELECT_VALUE, DEFAULT_ACTION, END_OF_ACTION ,   GET_CONTENT,
  GET_CONTENT_FAILED,
  GET_CONTENT_SUCCESS, PAGINATION, SUBMIT_CONTENT, SUBMIT_CONTENT_FAILED, SUBMIT_CONTENT_SUCCESS} from './constants';

export function defaultAction() {
  return {
    type: DEFAULT_ACTION,
  };
}
export const endOfAction = () => {
  return {
    type: END_OF_ACTION,
  };
};

export const getContentList = (content = null) => {
  return {
    type: GET_CONTENT,
    content,
  };
};
export const getContentListSuccess = data => {
  return {
    type: GET_CONTENT_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getContentListFailed = () => {
  return {
    type: GET_CONTENT_FAILED,
  };
};
export const pagination = (current, pageSize) => {
  return {
    type: PAGINATION,
    current,
    pageSize,
  };
};
export const changeSelectValue = (id, name,value) => {
  return {
    type: CHANGE_SELECT_VALUE,
    id, name, value
  };
};

export const submitContent = value => {
  return {
    type: SUBMIT_CONTENT,
    value,
  };
};
export const submitContentSuccess = data => {
  return {
    type: SUBMIT_CONTENT_SUCCESS,
    payload: {
      data,
    },
  };
};
export const submitContentFailed = error => {
  return {
    type: SUBMIT_CONTENT_FAILED,
    error,
  };
};
