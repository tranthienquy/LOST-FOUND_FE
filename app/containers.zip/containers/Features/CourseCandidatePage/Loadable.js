/**
 *
 * Asynchronously loads the component for CourseCandidatePage
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
