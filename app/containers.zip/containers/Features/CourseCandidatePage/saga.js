import { take, call, put, select, takeLatest, delay, fork, takeEvery } from 'redux-saga/effects';
import * as types from './constants';
import * as actions from './actions';
import * as api from 'utils/api';
import { KEY_VALUE } from '../../../utils/api/constants';
import { notification } from 'antd';
// Individual exports for testing



function* getCandidateList({content}) {
  const { current, pageSize } = yield select(state => state.courseCandidatePage);
  let filter = '' ;
  console.log(content);
  if (content){
  
 
    filter=
    (content.Email ? `contains(tolower(UserProfile/Account/Email),tolower('${encodeURIComponent(content.Email)}')) and ` :'')
    + (content.CourseName ? `contains(tolower(Course/Name),tolower('${encodeURIComponent(content.CourseName)}')) and ` :'')
    + (content.UserProfileName ? `contains(tolower(UserProfile/FirstName),tolower('${encodeURIComponent(content.UserProfileName)}')) or ` :'')
    + (content.UserProfileName ? `contains(tolower(UserProfile/LastName),tolower('${encodeURIComponent(content.UserProfileName)}')) and ` :'')
   + (content.Type ? `Course/Type eq '${encodeURIComponent(content.Type)}' and ` :'')
   + (content.IsPayFee!==undefined ? `IsPayFee eq ${encodeURIComponent(content.IsPayFee)} and ` :'')
   + (content.IsLearning!==undefined ? `IsLearning eq ${encodeURIComponent(content.IsLearning)} and ` :'')
   + (content.IsFinished !==undefined? `IsFinished eq ${encodeURIComponent(content.IsFinished)} and ` :'')
   +(content.showAvailable ? `Course/EndDate lt now() and`: '')

   '';
}
if (filter){
  filter= filter.slice(0, -4);
}
  const resp = yield call(
    api.postPagination,
    `v1/CourseSubmits`,
    current,
    pageSize,
    filter,
    { Course: { $select: 'Id,Name,Type' },
    UserProfile: { $select: 'Id,FirstName, LastName,Account;expand=Account($select=Email)' },
  }
  );
  const { data, status } = resp;
  if (status == 200) {
    yield delay(500);
    yield put(actions.getContentListSuccess(data));
  } else {
    yield put(actions.getContentListFailed());
  }
}

function* submitContent() {
  const {candidateList } = yield select(state => state.courseCandidatePage);

  const resp = yield call(api.put, `v1/CourseSubmit/update-course-submit-status`, {}, 
  candidateList.map(item=>({
    Id: item.Id, IsPayFee: item.IsPayFee,IsLearning: item.IsLearning,IsFinished: item.IsLearning
  }))
  );
  const { data, status } = resp;
  if (status == 200) {
    yield delay(200);
    yield put(actions.submitContentSuccess(data));
    yield notification.open({
      message: 'Cập nhật thành công',
      type:'success'
    });
    // yield put(push('/job'));
  } else {
    yield put(actions.submitContentFailed('password-failed'));
  }
}
export default function* courseCandidatePageSaga() {
  // See example in containers/HomePage/saga.js
  yield takeLatest(types.GET_CONTENT, getCandidateList);
  yield takeLatest(types.SUBMIT_CONTENT, submitContent);


}
