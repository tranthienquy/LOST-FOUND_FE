/*
 *
 * CourseCandidatePage constants
 *
 */

export const DEFAULT_ACTION = 'app/CourseCandidatePage/DEFAULT_ACTION';
export const END_OF_ACTION = 'app/CourseCandidatePage/END_OF_ACTION';
export const GET_CONTENT = 'app/CourseCandidatePage/GET_CONTENT';
export const GET_CONTENT_SUCCESS = 'app/CourseCandidatePage/GET_CONTENT_SUCCESS';
export const GET_CONTENT_FAILED = 'app/CourseCandidatePage/GET_CONTENT_FAILED';
export const PAGINATION = 'app/CourseCandidatePage/PAGINATION';

export const CHANGE_SELECT_VALUE = 'app/CourseCandidatePage/CHANGE_SELECT_VALUE';


export const SUBMIT_CONTENT = 'app/CourseCandidatePage/SUBMIT_CONTENT';
export const SUBMIT_CONTENT_SUCCESS = 'app/CourseCandidatePage/SUBMIT_CONTENT_SUCCESS';
export const SUBMIT_CONTENT_FAILED = 'app/CourseCandidatePage/SUBMIT_CONTENT_FAILED';
