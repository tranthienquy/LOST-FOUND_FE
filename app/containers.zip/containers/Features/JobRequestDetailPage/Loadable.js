/**
 *
 * Asynchronously loads the component for JobRequestDetailPage
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
