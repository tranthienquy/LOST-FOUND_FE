/*
 *
 * JobRequestDetailPage constants
 *
 */

export const DEFAULT_ACTION = 'app/JobRequestDetailPage/DEFAULT_ACTION';
export const END_OF_ACTION = 'app/JobRequestDetailPage/END_OF_ACTION';
