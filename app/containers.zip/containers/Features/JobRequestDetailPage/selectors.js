import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the jobRequestDetailPage state domain
 */

const selectJobRequestDetailPageDomain = state =>
  state.jobRequestDetailPage || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by JobRequestDetailPage
 */

const makeSelectJobRequestDetailPage = () =>
  createSelector(
    selectJobRequestDetailPageDomain,
    substate => substate,
  );

export default makeSelectJobRequestDetailPage;
export { selectJobRequestDetailPageDomain };
