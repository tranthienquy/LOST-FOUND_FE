/*
 * RegisterRecruiterPage Messages
 *
 * This contains all the text for the RegisterRecruiterPage container.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.containers.RegisterRecruiterPage';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'This is the RegisterRecruiterPage container!',
  },
});
