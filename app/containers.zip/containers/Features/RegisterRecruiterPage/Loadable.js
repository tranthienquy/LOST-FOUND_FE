/**
 *
 * Asynchronously loads the component for RegisterRecruiterPage
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
