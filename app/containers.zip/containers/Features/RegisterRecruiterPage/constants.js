/*
 *
 * RegisterRecruiterPage constants
 *
 */

export const DEFAULT_ACTION = 'app/RegisterRecruiterPage/DEFAULT_ACTION';
export const REGISTER = 'app/RegisterRecruiterPage/REGISTER';
export const REGISTER_SUCCESS = 'app/RegisterRecruiterPage/REGISTER_SUCCESS';
export const REGISTER_FAILED = 'app/RegisterRecruiterPage/REGISTER_FAILED';
