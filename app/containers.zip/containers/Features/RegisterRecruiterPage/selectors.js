import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the registerRecruiterPage state domain
 */

const selectRegisterRecruiterPageDomain = state => state.registerRecruiterPage || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by RegisterRecruiterPage
 */

const makeSelectRegisterRecruiterPage = () =>
  createSelector(
    selectRegisterRecruiterPageDomain,
    substate => substate,
  );

export default makeSelectRegisterRecruiterPage;
export { selectRegisterRecruiterPageDomain };
