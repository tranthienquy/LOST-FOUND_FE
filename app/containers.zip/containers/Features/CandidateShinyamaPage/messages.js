/*
 * CandidateShinyamaPage Messages
 *
 * This contains all the text for the CandidateShinyamaPage container.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.containers.CandidateShinyamaPage';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'This is the CandidateShinyamaPage container!',
  },
});
