import { take, call, put, select, takeLatest, delay } from 'redux-saga/effects';
import * as types from './constants';
import * as actions from './actions';
import * as api from 'utils/api';
// import { KEY_VALUE } from '../../utils/api/constants';
import { notification } from 'antd';
import { push } from 'react-router-redux';
import { valueToPercent } from '@mui/base';
import { KEY_VALUE } from '../../../../../utils/api/constants';

function* loadContent({ id }) {
  const resp = yield call(
    api.get,
    `v1/Jobs/${id}`,
  );
  const { data, status } = resp;

  if (status == 200 ) {
    yield put(actions.loadContentSuccess({...data }));
    
  } else {
    yield put(actions.loadContentFailed());
  }
}


function* submitContent({value}){
  // const {  } = yield select(state => state.candidateRecruitmentStatusModal);
console.log(value);
  const requestData = {
    ApplicantId: value.item.CandidateId,
    Type: value.item.Type,
    RequestAssignmentId: value.item.Id,
    Status:value.value.Status,
    ListInfoStatusApplicants:value.value.ListInfoStatusApplicants,

  }
  console.log(requestData)
  const resp = yield call(
    api.post,
    `v1/Requests/save-status-applicant`, {}, requestData
  );
  const { data, status } = resp;

  if (status == 200 ) {
    yield delay(2000);
    yield put(actions.submitContentSuccess(data));
    yield notification.open({
      message:"Cập nhật trạng thái ứng tuyển thành công",
      type:"success"
    })
  } else {
    yield put(actions.submitContentFailed('password-failed'));
  }
}


function* getActionList(){
  const resp = yield call(
    api.postPagination,
    `v1/KeyValues`,
    null,
    null,
    `TGroup eq ${KEY_VALUE.ACTION_TYPE}`,
    null
  );
  const { data, status } = resp;
  if (status == 200) {
    yield put(actions.getActionListSuccess(data));
  } else {
    yield put(actions.getActionListFailed());
  }
}
function* getResultList(){
  const resp = yield call(
    api.postPagination,
    `v1/KeyValues`,
    null,
    null,
    `TGroup eq ${KEY_VALUE.RESULT_TYPE}`,
    null
  );
  const { data, status } = resp;
  if (status == 200) {
    yield put(actions.getResultListSuccess(data));
  } else {
    yield put(actions.getResultListFailed());
  }
}
// Individual exports for testing
export default function* candidateRecruitmentStatusModalSaga() {
  // See example in containers/HomePage/saga.js
  yield takeLatest(types.LOAD_CONTENT, loadContent);
  yield takeLatest(types.SUBMIT_CONTENT, submitContent);
  yield takeLatest(types.GET_ACTION, getActionList)
  yield takeLatest(types.GET_RESULT, getResultList)

}
