/*
 *
 * CandidateCategoryPage actions
 *
 */

import { DEFAULT_ACTION, END_OF_ACTION, SHOW_STATUS_MODAL, GET_CONTENT, GET_CONTENT_FAILED, GET_CONTENT_SUCCESS, PAGINATION, SHOW_CV_MODAL, OPEN_PREVIEW_MODAL } from './constants';

export function defaultAction() {
  return {
    type: DEFAULT_ACTION,
  };
}
export const endOfAction = () => {
  return {
    type: END_OF_ACTION,
  };
};
export const showStatusModal = (isShowing, item) => {
  return {
    type: SHOW_STATUS_MODAL,
    isShowing,
    item
  };
};
export const showCVModal = (isShowing, item) => {
  return {
    type: SHOW_CV_MODAL,
    isShowing,
    item
  };
};

export const getCandidateList = (content = null) => {
  return {
    type: GET_CONTENT,
    content,
  };
};
export const getCandidateListSuccess = data => {
  return {
    type: GET_CONTENT_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getCandidateListFailed = () => {
  return {
    type: GET_CONTENT_FAILED,
  };
};
export const pagination = (current, pageSize) => {
  return {
    type: PAGINATION,
    current,
    pageSize,
  };
};

export const showPreviewModal = (isShowing,item) => {
  return {
    type: OPEN_PREVIEW_MODAL,
    isShowing,
    item
  };
};