/**
 *
 * CandidateCategoryPage
 *
 */

import React from 'react';
import PropTypes, { string } from 'prop-types';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import makeSelectCandidateCategoryPage from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import * as actions from './actions';
import './styles.scss';
import {
  Input,
  Table,
  Typography,
  Form,
  Button,
  DatePicker,
  Modal,
  Select,
  Tooltip,
  Popover,
  List,
  Tabs
} from 'antd';
import { Link, withRouter } from 'react-router-dom';
import CandidateRecruitmentStatusModal from './CandidateRecruitmentStatusModal/Loadable';
import qs from 'query-string';
import AuthContext from '../../../../utils/auth';
import FileViewerComponent from '../../../../components/FileViewerComponent';
import { touchRippleClasses } from '@mui/material';
import { API_ENDPOINT } from '../../../../utils/api/constants';

class CandidateCategoryPage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      valueSearch: null,
    };
  }
  formRef = React.createRef();

  componentWillUnmount() {
    this.props.onEndOfAction();
  }

  componentWillMount() {
    console.log(qs.parse(this.props.location.search));
    this.props.onGetCandidateList({Type:this.props.Type});
  }

  onSubmit = value => {
    console.log(value);
    this.setState({ valueSearch: value });

    this.props.onGetCandidateList({...value,Type:this.props.Type});
  };

  handleTableChange = (newPagination, filters, sorter) => {
    console.log(newPagination, filters, sorter);
    this.props.onPagination(newPagination.current, newPagination.pageSize);
    this.props.onGetCandidateList({ ...this.state.valueSearch,Type:this.props.Type });
  };
  onSelectChange = () => {
    this.props.onGetCandidateList({...this.formRef.current.getFieldsValue(),Type:this.props.Type});
  };
  columns = [
    {
      title: 'ID',

      children: [
        {
          title: (
            <Form.Item name="Id">
              <Input />
            </Form.Item>
          ),
          key: 'Id',
          dataIndex: 'Id',
          width: 70,
        },
      ],
    },

    {
      title: 'Công việc',
      children: [
        {
          title: (
            <Form.Item name="Title">
              <Input />
            </Form.Item>
          ),
          key: 'Title',
          dataIndex: 'Title',
          width:200
        },
      ],
    },

    {
      title: 'Tên ứng viên',
      children: [
        {
          title: (
            <Form.Item name="CandidateName">
              <Input />
            </Form.Item>
          ),
          key: 'CandidateName',
          dataIndex: 'CandidateName',
          width:230,  

        },
      ],
    },
    {
      title: 'Email ứng viên',
      children: [
        {
          title: (
            <Form.Item name="CandidateEmail">
              <Input />
            </Form.Item>
          ),
          key: 'CandidateEmail',
          dataIndex: 'CandidateEmail',
          width:240,  

        },
      ],
    },

    {
      title: 'Người phụ trách',
      children: [
        {
          title: (
            <Form.Item name="Curator">
              <Input />
            </Form.Item>
          ),
          key: 'Curator',
          dataIndex: 'Curator',
          width:160,  

        },
      ],
    },
    {
      title: 'Trạng thái',
      children: [
        {
          title: (
            <Form.Item name="Status">
              <Select
                suffixIcon={<i className="icon-Caret-down h3" />}
                onChange={this.onSelectChange}
              >
                <Select.Option value={'No process'}>No process</Select.Option>
                <Select.Option value={'Processing'}>Processing</Select.Option>
                <Select.Option value={'Success (Qualified)'}>
                  Success (Qualified)
                </Select.Option>
                <Select.Option value={'Success (Not Qualified)'}>
                  Success (Not Qualified)
                </Select.Option>
                <Select.Option value={'Success (Cancel)'}>
                  Success (Cancel)
                </Select.Option>
              </Select>
            </Form.Item>
          ),
          key: 'Status',
          dataIndex: 'Status',
          width:230,  

        },
      ],
    },
    {
      title: 'Thông tin',
      children: [
        {
          key: 'Info',
          dataIndex: 'Info',
          render: (value, record) => (
            <span>
              {record.ListInforApplicantResponses &&
                record.ListInforApplicantResponses.length > 0 &&
                record.ListInforApplicantResponses[
                  record.ListInforApplicantResponses.length - 1
                ].Action}
            </span>
          ),
          width:170,  

        },
      ],
    },
    {
      title: 'Hành động',
      children: [{
        key: 'Action',
        dataIndex: 'Action',
        width: 100,
        render: (value, record) => {
          return (
            <div className="d-flex flex-row">
              <Tooltip title="Chỉnh sửa">
                <Button
                  onClick={() => this.props.onShowStatusModal(true, record)}
                  shape="circle"
                  className="pl-1 mr-2"
                >
                  <i className="icon-Edit-alt-outline" />
                </Button>
              </Tooltip>
              <Popover
                title="Xem CV"
                trigger="click"
                placement="bottomRight"
                content={
                  <List
                    dataSource={record.ListCvs}
                    className="w-100"
                    renderItem={el => (
                      <div
                        className="d-flex flex-row justify-content-between align-items-center list-item"
                        style={{
                          backgroundColor: el.originFileObj && '#edffe6',
                        }}
                      >
                        <Typography className="d-flex flex-row mt-2 pl-2 ">
                          <i className="icon-Document-outline mr-2 h5 " />
                          <span
                            style={{
                              textOverflow: 'ellipsis',
                              overflow: 'hidden',
                              width: 160,
                              height: '1.2em',
                              whiteSpace: 'nowrap',
                            }}
                          >
                            {el.originFileObj ? el.name : el.Link}
                          </span>
                          {/* <i className='ml-2' style={{color:'#aeaeae'}}>18/6/2002</i> */}
                        </Typography>
                        <div>
                          <Tooltip placement="top" title={'Xem'}>
                            <i
                              className="icon-Eye-outline cursor-pointer h4"
                              onClick={() => this.props.onPreviewModal(true, el)}
                            />
                          </Tooltip>
                          <Tooltip
                            placement="top"
                            title={'Tải về'}
                            onClick={() => {
                              window.open(`${API_ENDPOINT}/v1/Cvs/view/${el.Id}`);
                            }}
                          >
                            <i className="icon-Download-outline cursor-pointer h4" />
                          </Tooltip>
                        </div>
                      </div>
                    )}
                  />
                }
              >
                <Tooltip title="Xem CV">
                  <Button shape="circle" className="pl-1">
                    <i className="icon-Eye-outline" />
                  </Button>
                </Tooltip>
              </Popover>
            </div>
          );
        },
      }]
    },
  ];

  onSubmitFailed = errorInfo => {};
  onChangeTable = pagination => {
    console.log(pagination);
  };
  showStatusModal = item => {
    this.props.onShowStatusModal(item);
  };

  render() {
    const {
      showCVModal,
      cv,
      candidateList,
      loading,
      showStatusModal,
      statusItem,
      previewModal,
      previewItem,
      total,current, pageSize
    } = this.props.candidateCategoryPage;
    return (
      <div className="candidate-recruiter-container d-flex flex-column pt-5">
        <Form
          name="basic"
          onFinish={this.onSubmit}
          autoComplete="off"
          layout="vertical"
          initialValues={{}}
          onFinishFailed={this.onSubmitFailed}
          className="ant-general-form"
          ref={this.formRef}
          
        >
          <div className="d-flex justify-content-between ">
            <Typography className="text-app-primary h4 font-weight-bold">
              DANH SÁCH ỨNG VIÊN {this.props.Type && this.props.Type ==="Job"? "(Theo công việc)":"(Theo yêu cầu tuyển dụng)"}
            </Typography>
            {/* <Button> Xuất Zip </Button> */}
          </div>
          <Button htmlType="submit" />
          <Table
            size="small"
            className="mt-5"
            loading={loading}
            columns={this.columns}
            // scroll={{ y: 1000 }}
            dataSource={candidateList}
            pagination={{total,current, pageSize}}
            onChange={this.handleTableChange}
          />
        </Form>
        {showStatusModal && (
          <Modal
            width={'80vw'}
            visible={showStatusModal}
            footer={''}
            title={'TRẠNG THÁI ỨNG TUYỂN'}
            onCancel={() => {
              this.props.onShowStatusModal(false, null);
              this.props.onGetCandidateList({ ...this.state.valueSearch });
            }}
          >
            {statusItem && (
              <CandidateRecruitmentStatusModal
                showModal={showStatusModal}
                value={statusItem}
              />
            )}
          </Modal>
        )}
        <Modal
          width={'80vw'}
          visible={previewModal}
          footer={''}
          title={previewItem && previewItem.Name}
          onCancel={() => this.props.onPreviewModal(false, null)}
        >
          <FileViewerComponent value={previewItem} />
        </Modal>
      </div>
    );
  }
}

CandidateCategoryPage.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  candidateCategoryPage: makeSelectCandidateCategoryPage(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    onEndOfAction: () => {
      dispatch(actions.endOfAction());
    },
    onShowStatusModal: (isShowing, item) => {
      dispatch(actions.showStatusModal(isShowing, item));
    },
    onShowCVModal: (isShowing, cv) => {
      dispatch(actions.showCVModal(isShowing, cv));
    },
    onGetCandidateList: content => {
      dispatch(actions.getCandidateList(content));
    },
    onPreviewModal: (isShowing, id) => {
      dispatch(actions.showPreviewModal(isShowing, id));
    },
    onPagination: (current, pageSize) => {
      dispatch(actions.pagination(current, pageSize));
    },
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

const withReducer = injectReducer({ key: 'candidateCategoryPage', reducer });
const withSaga = injectSaga({ key: 'candidateCategoryPage', saga });
CandidateCategoryPage.contextType = AuthContext;

export default compose(
  withConnect,
  withReducer,
  withSaga,
  withRouter,
)(CandidateCategoryPage);
