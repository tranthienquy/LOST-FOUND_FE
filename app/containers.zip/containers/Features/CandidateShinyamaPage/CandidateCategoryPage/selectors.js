import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the candidateCategoryPage state domain
 */

const selectCandidateCategoryPageDomain = state =>
  state.candidateCategoryPage || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by CandidateCategoryPage
 */

const makeSelectCandidateCategoryPage = () =>
  createSelector(
    selectCandidateCategoryPageDomain,
    substate => substate,
  );

export default makeSelectCandidateCategoryPage;
export { selectCandidateCategoryPageDomain };
