/**
 *
 * Asynchronously loads the component for CandidateCategoryPage
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
