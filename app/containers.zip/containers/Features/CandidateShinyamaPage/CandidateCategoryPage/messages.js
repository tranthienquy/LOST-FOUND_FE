/*
 * CandidateCategoryPage Messages
 *
 * This contains all the text for the CandidateCategoryPage container.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.containers.CandidateCategoryPage';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'This is the CandidateCategoryPage container!',
  },
});
