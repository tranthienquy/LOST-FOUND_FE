/*
 *
 * CandidateCategoryPage constants
 *
 */

export const DEFAULT_ACTION = 'app/CandidateCategoryPage/DEFAULT_ACTION';
export const END_OF_ACTION = 'app/CandidateCategoryPage/END_OF_ACTION';

export const SHOW_STATUS_MODAL = 'app/CandidateCategoryPage/SHOW_STATUS_MODAL';
export const SHOW_CV_MODAL = 'app/CandidateCategoryPage/SHOW_CV_MODAL';
export const GET_CONTENT = 'app/CandidateCategoryPage/GET_CONTENT';
export const GET_CONTENT_SUCCESS = 'app/CandidateCategoryPage/GET_CONTENT_SUCCESS';
export const GET_CONTENT_FAILED = 'app/CandidateCategoryPage/GET_CONTENT_FAILED';
export const PAGINATION = 'app/CandidateCategoryPage/PAGINATION';
export const OPEN_PREVIEW_MODAL = 'app/CandidateCategoryPage/OPEN_PREVIEW_MODAL';
