import { take, call, put, select, takeLatest, delay, fork, takeEvery } from 'redux-saga/effects';
import * as types from './constants';
import * as actions from './actions';
import * as api from 'utils/api';
import { KEY_VALUE } from '../../../utils/api/constants';



function* getCandidateList({content}) {
  const { current, pageSize } = yield select(state => state.candidateShinyamaPage);
  let filter = '' ;
  console.log(content);
  if (content){
    
    
}
if (filter){
  filter= filter.slice(0, -4);
}
  const resp = yield call(
    api.post,
    `v1/Requests/get-list-applicant`,
    {},
    {...content,  NumPage:current, PerPage: pageSize },
    
   
  );
  const { data, status } = resp;
  if (status == 200) {
    yield delay(500);
    yield put(actions.getCandidateListSuccess(data));
  } else {
    yield put(actions.getCandidateListFailed());
  }
}


function* getProfessionList({content}){
  if (content){
    yield delay(500);

  const resp = yield call(
    api.postPagination,
    `v1/KeyValues`,
    null,
    null,
    `TGroup eq ${KEY_VALUE.PROFESSION} and contains(tolower(TValue),tolower('${encodeURIComponent(content)}'))`,
    null
  );
  const { data, status } = resp;
  if (status == 200) {
    yield put(actions.getProfessionListSuccess(data));
  } else {
    yield put(actions.getProfessionListFailed());
  }
}
}


function* getSkillList({content}){

  if (content){
    yield delay(500);

  const resp = yield call(
    api.postPagination,
    `v1/KeyValues`,
    null,
    null,
    `TGroup eq ${KEY_VALUE.SKILL} and contains(tolower(TValue),tolower('${encodeURIComponent(content)}'))`,
    null
  );
  const { data, status } = resp;
  if (status == 200) {
    yield put(actions.getSkillListSuccess(data));
  } else {
    yield put(actions.getSkillListFailed());
  }
}
}

function* getCertificateList({content}){

  if (content){
    yield delay(500);

  const resp = yield call(
    api.postPagination,
    `v1/KeyValues`,
    null,
    null,
    `TGroup eq ${KEY_VALUE.CERTIFICATE} and contains(tolower(TValue),tolower('${encodeURIComponent(content)}'))`,
    null
  );
  const { data, status } = resp;
  if (status == 200) {
    yield put(actions.getCertificateListSuccess(data));
  } else {
    yield put(actions.getCertificateListFailed());
  }
}
}
// Individual exports for testing
export default function* candidateShinyamaPageSaga() {
  // See example in containers/HomePage/saga.js

  yield takeLatest(types.GET_CONTENT, getCandidateList);
  yield takeLatest(types.GET_SKILL, getSkillList);

  yield takeLatest(types.GET_PROFESSION, getProfessionList)
  yield takeLatest(types.GET_SKILL, getSkillList);
  yield takeLatest(types.GET_CERTIFICATE, getCertificateList);

}
