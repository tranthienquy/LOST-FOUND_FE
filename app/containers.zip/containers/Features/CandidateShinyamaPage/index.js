/**
 *
 * CandidateShinyamaPage
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import makeSelectCandidateShinyamaPage from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import * as actions from './actions';
import './styles.scss';
import CandidateCategoryPage from './CandidateCategoryPage';
import { withRouter } from 'react-router-dom';
import {
  Input,
  Table,
  Typography,
  Form,
  Button,
  DatePicker,
  Modal,
  Select,
  Tooltip,
  Popover,
  List,
  Tabs
} from 'antd';
import { API_ENDPOINT } from '../../../utils/api/constants';

class CandidateShinyamaPage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      valueSearch: null,
    };
  }
  formRef = React.createRef();

  componentWillUnmount() {
    this.props.onEndOfAction();
  }

  componentWillMount() {
    this.props.onGetCandidateList({Type:this.props.Type});
  }

  onSubmit = value => {
    console.log(value);
    this.setState({ valueSearch: value });

    this.props.onGetCandidateList({...value,Type:this.props.Type});
  };

  handleTableChange = (newPagination, filters, sorter) => {
    console.log(newPagination, filters, sorter);
    this.props.onPagination(newPagination.current, newPagination.pageSize);
    this.props.onGetCandidateList({ ...this.state.valueSearch,Type:this.props.Type });
  };
  onSelectChange = () => {
    this.props.onGetCandidateList({...this.formRef.current.getFieldsValue(),Type:this.props.Type});
  };

  onChangeTab = key => {
    console.log(key);
  };
  searchProfession = value => {
    this.props.onGetProfessionList(value);
  };
  searchSkill = value => {
    this.props.onGetSkillList(value);
  };
  searchCertificate = value => {
    this.props.onGetCertificateList(value);
  };
  columns = [


    {
      title: 'Tên ứng viên',
      children: [
        {
          title: (
            <Form.Item name="CandidateName">
              <Input />
            </Form.Item>
          ),
          key: 'CandidateName',
          dataIndex: 'CandidateName',
          width:230,  

        },
      ],
    },
    {
      title: 'Email',
      children: [
        {
          title: (
            <Form.Item name="CandidateEmail">
              <Input />
            </Form.Item>
          ),
          key: 'CandidateEmail',
          dataIndex: 'CandidateEmail',
          width:240,  

        },
      ],
    },
    {
      title: 'Số năm kinh nghiệm',
      children: [
        {
          title: '',
          key: 'WorkExperience',
          dataIndex: 'WorkExperience',
          width:240,  

        },
      ],
    },

    {
      title: 'Ngành nghề',
      children: [
        {
          title: ()=> (
            <Form.Item name="Professions">
              <Select
                className="w-100"
                placeholder="Ngành nghề"
                suffixIcon={''}
                showSearch
                onSearch={this.searchProfession}
                filterOption={false}
                onChange={this.onSelectChange}
                loading={
                  this.props.candidateShinyamaPage.loading
                    .professionList
                }
                allowClear={true}
                notFoundContent={''}
              >
                {console.log(
                  this.props.candidateShinyamaPage.professionList,
                )}
                {this.props.candidateShinyamaPage.professionList &&
                  this.props.candidateShinyamaPage.professionList.map(
                    item => (
                      <Select.Option
                        value={item.TKey}
                        key={`options-profession-${item.Id}`}
                      >
                        {item.TValue}
                      </Select.Option>
                    ),
                  )}
                    {this.props.candidateShinyamaPage.loading.professionList && (
                <Select.Option disabled>Đang tải...</Select.Option>
              )}
              </Select>
            </Form.Item>
          ),
          key: 'Professions',
          dataIndex: 'Professions',
        },
      ],
    },
    {
      title: 'Chứng chỉ',
      children: [
        {
          title: ()=> (
            <Form.Item name="Certificate">
            <Select
              className="w-100"
              placeholder="Chứng chỉ"
              onChange={this.onSelectChange}

              suffixIcon={''}
              showSearch
              onSearch={this.searchCertificate}
              filterOption={false}
              loading={this.props.candidateShinyamaPage.loading.certificateList}
              allowClear={true}
              notFoundContent={''}
              mode="multiple"
            >
              {this.props.candidateShinyamaPage.certificateList &&
                this.props.candidateShinyamaPage.certificateList.map(item => (
                  <Select.Option
                    value={item.TKey}
                    key={`options-certificate-${item.Id}`}
                  >
                    {item.TValue}
                  </Select.Option>
                ))}
                  {this.props.candidateShinyamaPage.loading.certificateList && (
                <Select.Option disabled>Đang tải...</Select.Option>
              )}
            </Select>
          </Form.Item>
          ),
          key: 'ListSkill',
          dataIndex: 'ListSkill',
          render: record => record.map(el=><Tag>{el} </Tag>)
        },
      ],
    },
    {
      title: 'Kỹ năng',
      children: [
        {
          title: ()=> (
            <Form.Item name="Skill">
            <Select
              className="w-100"
              placeholder="Kỹ năng"
              onChange={this.onSelectChange}

              suffixIcon={''}
              showSearch
              onSearch={this.searchSkill}
              filterOption={false}
              loading={this.props.candidateShinyamaPage.loading.skillList}
              allowClear={true}
              notFoundContent={''}
              mode="multiple"
            >
              {this.props.candidateShinyamaPage.skillList &&
                this.props.candidateShinyamaPage.skillList.map(item => (
                  <Select.Option
                    value={item.TKey}
                    key={`options-profession-${item.Id}`}
                  >
                    {item.TValue}
                  </Select.Option>
                ))}
                  {this.props.candidateShinyamaPage.loading.skillList && (
                <Select.Option disabled>Đang tải...</Select.Option>
              )}
            </Select>
          </Form.Item>
          ),
          key: 'ListSkill',
          dataIndex: 'ListSkill',
          render: record => record.map(el=><Tag>{el} </Tag>)
        },
      ],
    },

    {
      title: 'Ngày cuối cập nhật',
      children: [
        {
          title:()=> (
            <Form.Item name="CreateAt">
              <DatePicker
                onChange={this.onSelectChange}
                />
            </Form.Item>
          ),
          key: 'CreateAt',
          dataIndex: 'CreateAt',
          render: (value)=><span>   {moment(value).format('DD/MM/YYYY')}</span>
        },
      ],
    },

    {
      title: 'Phân loại',
      children: [
        {
          title:()=> (
            <Form.Item name="Status">
            <Select
              suffixIcon={<i className="icon-Caret-down h3" />}
              onChange={this.onSelectChange}
            >
              <Select.Option value={'No process'}>Applicant</Select.Option>
              <Select.Option value={'Processing'}>Partner</Select.Option>
             
            </Select>
          </Form.Item>
          ),
          key: 'CreateAt',
          dataIndex: 'CreateAt',
          render: (value)=><span>   {moment(value).format('DD/MM/YYYY')}</span>
        },
      ],
    },

  ];

  onSubmitFailed = errorInfo => {};
  onChangeTable = pagination => {
    console.log(pagination);
  };
  showStatusModal = item => {
    this.props.onShowStatusModal(item);
  };
  render() {

    const {
      showCVModal,
      cv,
      candidateList,
      loading,
      showStatusModal,
      statusItem,
      previewModal,
      previewItem,
      total,current, pageSize
    } = this.props.candidateShinyamaPage;
    return (
      
      <div className='candidate-shinyama'>
       <Tabs defaultActiveKey="1" onChange={this.onChangeTab}>
       <Tabs.TabPane tab="Toàn bộ ứng viên" key="1" >
       <Form
          name="basic"
          onFinish={this.onSubmit}
          autoComplete="off"
          layout="vertical"
          initialValues={{}}
          onFinishFailed={this.onSubmitFailed}
          className="ant-general-form"
          ref={this.formRef}
          
        >

<div className="d-flex justify-content-between ">
            <Typography className="text-app-primary h4 font-weight-bold">
              DANH SÁCH ỨNG VIÊN
            </Typography>
            {/* <Button> Xuất Zip </Button> */}
          </div>
          <Button htmlType="submit" />
          <Table
            size="small"
            className="mt-5"
            loading={loading.getContent}
            columns={this.columns}
            // scroll={{ y: 1000 }}
            dataSource={candidateList}
            pagination={{total,current, pageSize}}
            onChange={this.handleTableChange}
          />
          </Form>




       </Tabs.TabPane>
       <Tabs.TabPane tab="Theo yêu cầu tuyển dụng" key="2" >
        <CandidateCategoryPage Type="Request"/>
       </Tabs.TabPane>
       <Tabs.TabPane tab="Theo công việc" key="3" >
       <CandidateCategoryPage  Type="Job"/>
       </Tabs.TabPane>

       </Tabs>
      </div>
    );
  }
}

CandidateShinyamaPage.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  candidateShinyamaPage: makeSelectCandidateShinyamaPage(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    onEndOfAction: () => {
      dispatch(actions.endOfAction());
    },
    onShowStatusModal: (isShowing, item) => {
      dispatch(actions.showStatusModal(isShowing, item));
    },
    onShowCVModal: (isShowing, cv) => {
      dispatch(actions.showCVModal(isShowing, cv));
    },
    onGetCandidateList: content => {
      dispatch(actions.getCandidateList(content));
    },
    onPreviewModal: (isShowing, id) => {
      dispatch(actions.showPreviewModal(isShowing, id));
    },
    onPagination: (current, pageSize) => {
      dispatch(actions.pagination(current, pageSize));
    },
    onGetProfessionList: content => {
      dispatch(actions.getProfessionList(content));
    },
    onGetSkillList: content => {
      dispatch(actions.getSkillList(content));
    },
    onGetCertificateList: content => {
      dispatch(actions.getCertificateList(content));
    },
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

const withReducer = injectReducer({ key: 'candidateShinyamaPage', reducer });
const withSaga = injectSaga({ key: 'candidateShinyamaPage', saga });
export default compose(
  withConnect,
  withReducer,
  withSaga,
  withRouter
)(CandidateShinyamaPage);
