/*
 *
 * CandidateShinyamaPage constants
 *
 */

export const DEFAULT_ACTION = 'app/CandidateShinyamaPage/DEFAULT_ACTION';
export const END_OF_ACTION = 'app/CandidateShinyamaPage/END_OF_ACTION';


export const SHOW_STATUS_MODAL = 'app/CandidateShinyamaPage/SHOW_STATUS_MODAL';
export const SHOW_CV_MODAL = 'app/CandidateShinyamaPage/SHOW_CV_MODAL';
export const GET_CONTENT = 'app/CandidateShinyamaPage/GET_CONTENT';
export const GET_CONTENT_SUCCESS = 'app/CandidateShinyamaPage/GET_CONTENT_SUCCESS';
export const GET_CONTENT_FAILED = 'app/CandidateShinyamaPage/GET_CONTENT_FAILED';
export const PAGINATION = 'app/CandidateShinyamaPage/PAGINATION';
export const OPEN_PREVIEW_MODAL = 'app/CandidateShinyamaPage/OPEN_PREVIEW_MODAL';

export const GET_PROFESSION = 'app/CandidateShinyamaPage/GET_PROFESSION';
export const GET_PROFESSION_SUCCESS = 'app/CandidateShinyamaPage/GET_PROFESSION_SUCCESS';
export const GET_PROFESSION_FAILED = 'app/CandidateShinyamaPage/GET_PROFESSION_FAILED';

export const GET_SKILL = 'app/CandidateShinyamaPage/GET_SKILL';
export const GET_SKILL_SUCCESS = 'app/CandidateShinyamaPage/GET_SKILL_SUCCESS';
export const GET_SKILL_FAILED = 'app/CandidateShinyamaPage/GET_SKILL_FAILED';

export const GET_CERTIFICATE = 'app/CandidateShinyamaPage/GET_CERTIFICATE';
export const GET_CERTIFICATE_SUCCESS = 'app/CandidateShinyamaPage/GET_CERTIFICATE_SUCCESS';
export const GET_CERTIFICATE_FAILED = 'app/CandidateShinyamaPage/GET_CERTIFICATE_FAILED';