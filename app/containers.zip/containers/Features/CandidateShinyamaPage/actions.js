/*
 *
 * CandidateShinyamaPage actions
 *
 */

import {
  DEFAULT_ACTION,
  END_OF_ACTION,
  SHOW_STATUS_MODAL,
  GET_CONTENT,
  GET_CONTENT_FAILED,
  GET_CONTENT_SUCCESS,
  PAGINATION,
  SHOW_CV_MODAL,
  OPEN_PREVIEW_MODAL,
  GET_CERTIFICATE,
  GET_CERTIFICATE_FAILED,
  GET_CERTIFICATE_SUCCESS,
  GET_PROFESSION,
  GET_PROFESSION_FAILED,
  GET_PROFESSION_SUCCESS,
  GET_SKILL,
  GET_SKILL_SUCCESS,
  GET_SKILL_FAILED,
} from './constants';

export function defaultAction() {
  return {
    type: DEFAULT_ACTION,
  };
}
export const endOfAction = () => {
  return {
    type: END_OF_ACTION,
  };
};

export const showStatusModal = (isShowing, item) => {
  return {
    type: SHOW_STATUS_MODAL,
    isShowing,
    item,
  };
};
export const showCVModal = (isShowing, item) => {
  return {
    type: SHOW_CV_MODAL,
    isShowing,
    item,
  };
};

export const getCandidateList = (content = null) => {
  return {
    type: GET_CONTENT,
    content,
  };
};
export const getCandidateListSuccess = data => {
  return {
    type: GET_CONTENT_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getCandidateListFailed = () => {
  return {
    type: GET_CONTENT_FAILED,
  };
};
export const pagination = (current, pageSize) => {
  return {
    type: PAGINATION,
    current,
    pageSize,
  };
};

export const showPreviewModal = (isShowing, item) => {
  return {
    type: OPEN_PREVIEW_MODAL,
    isShowing,
    item,
  };
};

export const getProfessionList = (content = '') => {
  return {
    type: GET_PROFESSION,
    content,
  };
};
export const getProfessionListSuccess = data => {
  return {
    type: GET_PROFESSION_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getProfessionListFailed = () => {
  return {
    type: GET_PROFESSION_FAILED,
  };
};

export const getSkillList = (content = '') => {
  return {
    type: GET_SKILL,
    content,
  };
};
export const getSkillListSuccess = data => {
  return {
    type: GET_SKILL_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getSkillListFailed = () => {
  return {
    type: GET_SKILL_FAILED,
  };
};
export const getCertificateList = (content = '') => {
  return {
    type: GET_CERTIFICATE,
    content,
  };
};
export const getCertificateListSuccess = data => {
  return {
    type: GET_CERTIFICATE_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getCertificateListFailed = () => {
  return {
    type: GET_CERTIFICATE_FAILED,
  };
};
