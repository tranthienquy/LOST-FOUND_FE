import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the candidateShinyamaPage state domain
 */

const selectCandidateShinyamaPageDomain = state =>
  state.candidateShinyamaPage || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by CandidateShinyamaPage
 */

const makeSelectCandidateShinyamaPage = () =>
  createSelector(
    selectCandidateShinyamaPageDomain,
    substate => substate,
  );

export default makeSelectCandidateShinyamaPage;
export { selectCandidateShinyamaPageDomain };
