/**
 *
 * CourseFormPage
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import makeSelectCourseFormPage from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import * as actions from './actions';
import './styles.scss';
import CourseDetailSkeleton from '../CourseDetailPage/CourseDetailSkeleton';
import {
  Button,
  Card,
  Typography,
  Tag,
  Modal,
  Form,
  Input,
  Select,
  Skeleton,
  DatePicker,
  Upload,
  Popover,
  Image,
  List,
  Tooltip,
} from 'antd';
import { Helmet } from 'react-helmet';
import { LinearProgress } from '@mui/material';
import { withRouter } from 'react-router-dom';
import { getBase64 } from '../../../utils/imageUtil';
import AuthContext from '../../../utils/auth';
import { API_ENDPOINT } from '../../../utils/api/constants';
import { saveAs } from 'file-saver';

class CourseFormPage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      duplicateAv: false,
      imagePreview: null,
      duplicateCV: false,
    };
  }
  componentWillUnmount() {
    this.props.onEndOfAction();
  }
  onSubmit = value => {
    this.props.onSubmitContent(value);
  };
  onSubmitFailed = error => {};

  componentWillMount() {
    const { id } = this.props.match.params;
    if (id) {
      this.props.onGetContent(id);
    }
    this.props.onGetDurationTypeList();
    this.props.onGetFeeTypeList();
  }
  componentWillReceiveProps = async nextProps => {
    const { id } = nextProps.match.params;
    if (nextProps.match.params !== this.props.match.params) {
      if (id) {
        this.props.onGetContent(id);
      }
    }
    if (nextProps.courseFormPage.image != this.props.courseFormPage.image) {
      const base64 = await getBase64(
        nextProps.courseFormPage.image.originFileObj,
      );
      await this.setState({
        imagePreview: base64,
      });
    }
  };
  onchangeFile = async value => {
    this.setState({ duplicateAv: !this.state.duplicateAv });
    if (this.state.duplicateAv) {
      return;
    }
    const base64 = await getBase64(value.file.originFileObj);
    if (base64.startsWith('data:image/')) {
      this.props.onChangeAvatar(value.file);
    }
    //   await this.setState({
    //     imagePreview: base64
    //   })
  };

  onUpFile = async value => {
    if (this.state.duplicateCV) {
      this.props.onUploadFile(value.file);
    }
    this.setState({ duplicateCV: !this.state.duplicateCV });
  };

  downloadFile = file => {
    saveAs(file.originFileObj, file.name);
  };
  render() {
    const {
      loading,
      imageURL,
      content,
      id,
      feeTypeList,
      fileList,
      durationTypeList,
      image,
    } = this.props.courseFormPage;
    const { imagePreview } = this.state;
    return (
      <div className="course-detail-container d-flex flex-column pt-5">
        <Helmet>
          <title>{id ? 'Cập nhật khóa học' : 'Tạo mới khóa học'}</title>
        </Helmet>
        <div className="d-flex justify-content-between">
          <Typography.Text
            className="link-text-on-click"
            type="secondary"
            onClick={() => this.props.history.goBack()}
          >
            <i className="icon-Caret-left" /> Quay lại
          </Typography.Text>
        </div>

        {loading.content && id ? (
          <CourseDetailSkeleton />
        ) : (
          <React.Fragment>
            <Form
              name="basic"
              onFinish={this.onSubmit}
              autoComplete="off"
              layout="vertical"
              initialValues={content}
              onFinishFailed={this.onSubmitFailed}
              className="ant-general-form"
            >
              <Card
                className="w-100 introduction-card mt-4"
                title={
                  <Typography
                    style={{ fontSize: '24px' }}
                    className=" text-app-primary font-weight-bold mt-2 d-flex align-items-center"
                  >
                    <i
                      style={{ fontSize: '29px' }}
                      className=" mr-2 icon-Checked-box-outline"
                    />
                    THÔNG TIN CHUNG
                  </Typography>
                }
              >
                <div className="row">
                  <div className="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                    {image || imageURL ? (
                      <Popover
                        content={
                          <Upload
                            showUploadList={false}
                            onChange={this.onchangeFile}
                          >
                            <Button danger>Thay đổi</Button>
                          </Upload>
                        }
                      >
                        <Image
                          src={
                            imagePreview ||
                            (imageURL
                              ? imageURL.startsWith('http')
                                ? imageURL
                                : `${this.context.prefixLink}/${imageURL}`
                              : require('../../../images/logo/logo-shinyama-grayscale.png'))
                          }
                          height={350}
                          width={'100%'}
                        />
                      </Popover>
                    ) : (
                      <Upload.Dragger
                        customRequest={({ file, onSuccess }) => {
                          setTimeout(() => {
                            onSuccess('ok');
                          }, 0);
                        }}
                        height={'100%'}
                        onChange={this.onchangeFile}
                        showUploadList={false}
                        action={''}
                        className="drop-file-avatar"
                      >
                        <Typography className="ant-upload-text">
                          Thêm hình ảnh
                        </Typography>
                        <i className="icon-Image-outline h1" />
                      </Upload.Dragger>
                    )}
                  </div>
                  <div className="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                    <div class="row">
                      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <Form.Item
                          label="Tên khóa học"
                          name="Name"
                          rules={[
                            {
                              required: true,
                              message: 'Vui lòng nhập Tên khóa học',
                            },
                          ]}
                        >
                          <Input size="large" />
                        </Form.Item>
                      </div>
                      <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                        <Form.Item
                          label="Hình thức học"
                          name="Type"
                          rules={[
                            {
                              required: true,
                              message: 'Vui lòng nhập Hình thức học',
                            },
                          ]}
                        >
                          <Select
                            suffixIcon={<i className="icon-Caret-down h3" />}
                          >
                            <Select.Option value={'Online'}>
                              Online
                            </Select.Option>
                            <Select.Option value={'Offline'}>
                              Offline
                            </Select.Option>
                          </Select>
                        </Form.Item>
                      </div>
                      <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                        <Form.Item
                          label={<span><span className='form-item-required mr-1'>*</span>Thời lượng</span>}
                          rules={[
                            {
                              required: true,
                              message: 'Vui lòng nhập Ngày sinh',
                            },
                          ]}
                        >
                          <Input.Group compact className="w-100">
                            <Form.Item
                              name="Duration"
                              noStyle
                              rules={[
                                {
                                  required: true,
                                  message: 'Vui lòng nhập Thời lượng',
                                },
                              ]}
                            >
                              <Input
                                style={{
                                  width: '60%',
                                  borderTopLeftRadius: 5,
                                  borderBottomLeftRadius: 5,
                                }}
                                type="number"
                                min={1}
                              />
                            </Form.Item>
                            <Form.Item
                              name="DurationType"
                              noStyle
                              rules={[
                                {
                                  required: true,
                                  message: 'Vui lòng nhập Loại thời lượng',
                                },
                              ]}
                            >
                              <Select
                                suffixIcon={
                                  <i className="icon-Caret-down h3" />
                                }
                                style={{ width: '40%' }}
                              >
                                {durationTypeList &&
                                  durationTypeList.map(item => (
                                    <Select.Option
                                      value={item.TKey}
                                      key={`options-duration-type-${item.TKey}`}
                                    >
                                      {item.TValue}
                                    </Select.Option>
                                  ))}
                                {loading.durationType && (
                                  <Select.Option disabled>
                                    Đang tải...
                                  </Select.Option>
                                )}
                              </Select>
                            </Form.Item>
                          </Input.Group>
                        </Form.Item>
                      </div>
                      <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                        <Form.Item 
                        
                        label={<span><span className='form-item-required mr-1'>*</span>Học phí</span>}
                        
                        >
                          <Input.Group compact className="w-100">
                            <Form.Item
                              name="Fee"
                              noStyle
                              rules={[
                                {
                                  required: true,
                                  message: 'Vui lòng nhập Học phí',
                                },
                              ]}
                            >
                              <Input
                                type={'number'}
                                min={0}
                                style={{
                                  width: '60%',
                                  borderTopLeftRadius: 5,
                                  borderBottomLeftRadius: 5,
                                }}
                              />
                            </Form.Item>
                            <Form.Item
                              name="FeeType"
                              noStyle
                              rules={[
                                {
                                  required: true,
                                  message: 'Vui lòng chọn Tiền tệ',
                                },
                              ]}
                            >
                              <Select
                                suffixIcon={
                                  <i className="icon-Caret-down h3" />
                                }
                                style={{ width: '40%' }}
                              >
                                {feeTypeList &&
                                  feeTypeList.map(item => (
                                    <Select.Option
                                      value={item.TKey}
                                      key={`options-fee-type-${item.TKey}`}
                                    >
                                      {item.TValue}
                                    </Select.Option>
                                  ))}
                                {loading.feeType && (
                                  <Select.Option disabled>
                                    Đang tải...
                                  </Select.Option>
                                )}
                              </Select>
                            </Form.Item>
                          </Input.Group>
                        </Form.Item>
                      </div>
                      <div className="col-xs-12 col-sm-12 col-md-12 col-lg-4">
                        <Form.Item
                          label="Thời gian học"
                          name="StudyDate"
                          rules={[
                            {
                              required: true,
                              message: 'Vui lòng nhập Thời gian học',
                            },
                          ]}
                        >
                          <DatePicker.RangePicker className="w-100" />
                        </Form.Item>
                      </div>
                      <div className="col-xs-12 col-sm-12 col-md-12 col-lg-4">
                        <Form.Item
                          label="Hạn chót đăng ký"
                          name="DueDate"
                          rules={[
                            {
                              required: true,
                              message: 'Vui lòng nhập Hạn chót đăng ký',
                            },
                          ]}
                        >
                          <DatePicker className="w-100" />
                        </Form.Item>
                      </div>
                      <div className="col-xs-12 col-sm-12 col-md-12 col-lg-4">
                        <Form.Item label="Địa điểm học" name="Location">
                          <Input />
                        </Form.Item>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              <Card
                size="small"
                className="card-description mt-4"
                title={
                  <Typography
                    style={{ fontSize: '24px' }}
                    className=" text-app-primary font-weight-bold mt-2 d-flex align-items-center"
                  >
                    <i
                      style={{ fontSize: '29px' }}
                      className=" mr-2 icon-Checked-box-outline"
                    />
                      <span className='mr-1' style={{color:'red', fontSize:15}}>*</span>
                    MỤC TIÊU KHÓA HỌC
                  </Typography>
                }
              >
                <Form.Item
                  name="Objective"
                  rules={[
                    {
                      required: true,
                      message: 'Vui lòng nhập Mục tiêu khóa học',
                    },
                  ]}
                >
                  <Input.TextArea rows={5} />
                </Form.Item>
              </Card>
              <Card
                size="small"
                className="card-description mt-4"
                title={
                  <Typography
                    style={{ fontSize: '24px' }}
                    className=" text-app-primary font-weight-bold mt-2 d-flex align-items-center"
                  >
                    <i
                      style={{ fontSize: '29px' }}
                      className=" mr-2 icon-Book-open-outline"
                    />
                    CHI TIẾT CHƯƠNG TRÌNH HỌC
                  </Typography>
                }
              >
                <Form.Item name="Description">
                  <Input.TextArea rows={5} />
                </Form.Item>
              </Card>
              <Card
                size="small"
                className="card-description mt-4"
                title={
                  <Typography
                    style={{ fontSize: '24px' }}
                    className=" text-app-primary font-weight-bold mt-2 d-flex align-items-center"
                  >
                    <i
                      style={{ fontSize: '29px' }}
                      className=" mr-2 icon-Box-outline"
                    />
                    TÀI LIỆU THAM KHẢO
                  </Typography>
                }
              >
                <Upload.Dragger
                  customRequest={({ file, onSuccess }) => {
                    setTimeout(() => {
                      onSuccess('ok');
                    }, 0);
                  }}
                  height={'200px'}
                  showUploadList={false}
                  action={''}
                  className="drop-file-avatar mb-4"
                  onChange={this.onUpFile}
                >
                  <Typography className="ant-upload-text">
                    Tải tài liệu đính kèm tại đây
                  </Typography>
                  <i className="icon-Cloud-upload-outline h1 text-app-primary" />
                </Upload.Dragger>

                <List
                  dataSource={fileList}
                  className="w-100"
                  renderItem={item => (
                    <div
                      className="d-flex flex-row justify-content-between align-items-center list-item"
                      style={{
                        backgroundColor: item.originFileObj && '#edffe6',
                      }}
                    >
                      <Typography className="d-flex flex-row mt-2 pl-2 ">
                        <i className="icon-Document-outline mr-2 h5 " />
                        <span>
                          {item.originFileObj ? item.name : item.Link}
                        </span>
                        {/* <i className='ml-2' style={{color:'#aeaeae'}}>18/6/2002</i> */}
                      </Typography>
                      <div>
                        {/* <Tooltip placement="top" title={'Xem'}>
                   <i className="icon-Eye-outline cursor-pointer h4" onClick={()=>this.props.onPreviewModal(true, item)} />
                   </Tooltip> */}
                        <Tooltip
                          placement="top"
                          title={'Tải về'}
                          onClick={() => {
                            item.Id
                              ? window.open(
                                  `${this.context.prefixLink}/${item.Link}`,
                                )
                              : this.downloadFile(item);
                          }}
                        >
                          <i className="icon-Download-outline cursor-pointer h4" />
                        </Tooltip>
                        <Tooltip
                          placement="top"
                          title={'Xóa'}
                          onClick={() => this.props.onDeleteFile(item)}
                        >
                          <i className="icon-Trash-outline cursor-pointer mr-2 h4" />
                        </Tooltip>
                      </div>
                    </div>
                  )}
                />
              </Card>

              <Form.Item className="mb-0">
                <Button
                  disabled={loading.submit}
                  size="large"
                  type="primary"
                  htmlType="submit"
                  className="text-center w-100 mt-3"
                >
                  <b className="w-100 text-center">
                    {' '}
                    {id ? 'CẬP NHẬT KHÓA HỌC' : '+  TẠO MỚI KHÓA HỌC'}
                  </b>
                </Button>
              </Form.Item>
              <div style={{ height: '10px' }}>
                {loading.submit ? <LinearProgress color="success" /> : ''}
              </div>
            </Form>
          </React.Fragment>
        )}
      </div>
    );
  }
}

CourseFormPage.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  courseFormPage: makeSelectCourseFormPage(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    onEndOfAction: () => {
      dispatch(actions.endOfAction());
    },
    onGetContent: id => {
      dispatch(actions.getContent(id));
    },
    onSubmitContent: value => {
      dispatch(actions.submitContent(value));
    },
    onGetDurationTypeList: () => {
      dispatch(actions.getDurationType());
    },
    onGetFeeTypeList: () => {
      dispatch(actions.getFeeType());
    },
    onChangeAvatar: image => {
      dispatch(actions.changeAvatar(image));
    },
    onUploadFile: file => {
      dispatch(actions.uploadFile(file));
    },
    onDeleteFile: file => {
      dispatch(actions.deleteFile(file));
    },
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

const withReducer = injectReducer({ key: 'courseFormPage', reducer });
const withSaga = injectSaga({ key: 'courseFormPage', saga });
CourseFormPage.contextType = AuthContext;

export default compose(
  withConnect,
  withReducer,
  withSaga,
  withRouter,
)(CourseFormPage);
