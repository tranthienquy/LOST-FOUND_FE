import {
  take,
  call,
  put,
  select,
  takeLatest,
  delay,
  fork,
  takeEvery,
} from 'redux-saga/effects';
import * as types from './constants';
import * as actions from './actions';
import * as api from 'utils/api';
import { KEY_VALUE } from '../../../utils/api/constants';
import { notification } from 'antd';
import moment from 'moment';
import { push } from 'react-router-redux';

// Individual exports for testing
function* getDurationTypeList() {
  const resp = yield call(
    api.postPagination,
    `v1/KeyValues`,
    null,
    null,
    `TGroup eq ${KEY_VALUE.DURATION_TYPE}`,
    null,
  );
  const { data, status } = resp;
  if (status == 200) {
    yield put(actions.getDurationTypeSuccess(data));
  } else {
    yield put(actions.getDurationTypeFailed());
  }
}
function* getFeeTypeList() {
  const resp = yield call(
    api.postPagination,
    `v1/KeyValues`,
    null,
    null,
    `TGroup eq ${KEY_VALUE.FEETYPE}`,
    null,
  );
  const { data, status } = resp;
  if (status == 200) {
    yield put(actions.getFeeTypeSuccess(data));
  } else {
    yield put(actions.getFeeTypeFailed());
  }
}

function* getContent({ id }) {
  yield delay(1000);
  const resp = yield call(api.get, `v1/Courses(${id})?$expand=FileStorages(filter = status ne 0)`);
  const { data, status } = resp;

  if (status == 200) {
    yield put(actions.getContentSuccess({ ...data }));
  } else {
    yield put(actions.getContentFailed());
  }
}

function* submitContent({ value }) {
  const { image, id } = yield select(state => state.courseFormPage);
  const requestData = {
    ...value,
    DueDate: moment(value.DueDate).toDate(),
    StartDate: moment(value.StudyDate[0]).toDate(),
    EndDate: moment(value.StudyDate[1]).toDate(),
  };
  yield console.log(value);
  if (id) {
    const resp = yield call(api.put, `v1/Courses(${id})`, {}, requestData);
    const { data, status } = resp;

    if (status == 200) {
      yield removeFiles();
      yield uploadFiles(data.Id);
      if (image) {
        yield uploadAvatar(data.Id, image);
      }
      yield delay(2000);

      yield put(actions.submitContentSuccess(data));
      yield notification.open({
        message: id
          ? 'Cập nhật khóa học thành công'
          : 'Tạo mới khóa học thành công',
          type:"success"
      });

      yield put(push(`/course/${id}`));

    } else {
      yield put(actions.submitContentFailed('password-failed'));
    }
  } else {
    const resp = yield call(api.post, `v1/Courses`, {}, requestData);
    const { data, status } = resp;

    if (status == 200) {
      yield uploadFiles(data.Id);
      if (image) {
        yield uploadAvatar(data.Id, image);
      }
      yield delay(2000);

      yield put(actions.submitContentSuccess(data));
      yield notification.open({
        message: id
          ? 'Cập nhật khóa học thành công'
          : 'Tạo mới khóa học thành công',
      });

      yield put(push(`/course/${data.Id}`));
    } else {
      yield put(actions.submitContentFailed('password-failed'));
    }
  }
}

function* uploadAvatar(id, image) {
  let dataImage = yield new FormData();
  yield dataImage.append('imageFile', image.originFileObj);
  const resp = yield call(
    api.put,
    `v1/Courses(${id})/update-image`,
    {},
    dataImage,
    { 'Content-Type': 'multipart/form-data' },
  );
  const { data, status } = resp;

  if (status == 200) {
  } else {
    yield put(actions.submitContentFailed());
  }
}

function* uploadFiles(id) {
  const { fileList } = yield select(state => state.courseFormPage);

  let dataFile = yield new FormData();
  let listNewFiles = yield [];
  yield fileList.forEach(element => {
    if (element.originFileObj) {
      listNewFiles.push(element.originFileObj);
      dataFile.append('files', element.originFileObj);
    }
  });
  if (listNewFiles.length > 0) {
    const resp = yield call(
      api.put,
      `v1/Courses(${id})/upload-multi-file`,
      {},
      dataFile,
      { 'Content-Type': 'multipart/form-data' },
    );
    const { data, status } = resp;

    if (status == 200) {
    } else {
      yield put(actions.submitContentFailed());
    }
  }
}

function* removeFiles() {

  const { removeFileList , id} = yield select(state => state.courseFormPage);
  yield console.log(removeFileList,  removeFileList.map(el=>el.Id) )
  if(removeFileList.length>0){

    const resp = yield call(
      api.put,
      `v1/Courses(${id})/deleteFiles`,
      {},
      removeFileList.map(el=>el.Id),
      { 'Content-Type': 'multipart/form-data' },
    );
    const { data, status } = resp;

    if (status == 200) {
    } else {
      yield put(actions.submitContentFailed());
    }
  }

}

export default function* courseFormPageSaga() {
  // See example in containers/HomePage/saga.js
  yield takeLatest(types.GET_CONTENT, getContent);

  yield takeLatest(types.SUBMIT_CONTENT, submitContent);
  yield takeLatest(types.GET_DURATION_TYPE, getDurationTypeList);
  yield takeLatest(types.GET_FEE_TYPE, getFeeTypeList);
}
