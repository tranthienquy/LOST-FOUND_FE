/*
 *
 * CourseDetailPage constants
 *
 */

export const DEFAULT_ACTION = 'app/CourseDetailPage/DEFAULT_ACTION';
export const CHECK_IS_REGISTER = 'app/CourseDetailPage/CHECK_IS_REGISTER';
export const CHECK_IS_REGISTER_SUCCESS = 'app/CourseDetailPage/CHECK_IS_REGISTER_SUCCESS';
export const CHECK_IS_REGISTER_FAILED = 'app/CourseDetailPage/CHECK_IS_REGISTER_FAILED';

export const LOAD_CONTENT = 'app/CourseDetailPage/LOAD_CONTENT';
export const LOAD_CONTENT_SUCCESS = 'app/CourseDetailPage/LOAD_CONTENT_SUCCESS';
export const LOAD_CONTENT_FAILED = 'app/CourseDetailPage/LOAD_CONTENT_FAILED';
export const COUNT_DOWN = 'app/CourseDetailPage/COUNT_DOWN';
export const END_OF_ACTION = 'app/CourseDetailPage/END_OF_ACTION';

export const SHOW_CONFIRM_MODAL = 'app/CourseDetailPage/SHOW_CONFIRM_MODAL';

export const CONFIRM = 'app/CourseDetailPage/CONFIRM';
export const CONFIRM_SUCCESS = 'app/CourseDetailPage/CONFIRM_SUCCESS';
export const CONFIRM_FAILED = 'app/CourseDetailPage/CONFIRM_FAILED';

export const GET_PROFILE = 'app/CourseDetailPage/GET_PROFILE';
export const GET_PROFILE_SUCCESS = 'app/CourseDetailPage/GET_PROFILE_SUCCESS';
export const GET_PROFILE_FAILED = 'app/CourseDetailPage/GET_PROFILE_FAILED';