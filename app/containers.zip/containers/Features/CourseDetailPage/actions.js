/*
 *
 * CourseDetailPage actions
 *
 */

import {
  COUNT_DOWN,
  DEFAULT_ACTION,
  END_OF_ACTION,
  LOAD_CONTENT,
  LOAD_CONTENT_FAILED,
  LOAD_CONTENT_SUCCESS,
  SHOW_CONFIRM_MODAL,
  CONFIRM,
  CONFIRM_FAILED,
  CONFIRM_SUCCESS,
  CHECK_IS_REGISTER,
CHECK_IS_REGISTER_SUCCESS,
CHECK_IS_REGISTER_FAILED,
GET_PROFILE,
GET_PROFILE_FAILED,
GET_PROFILE_SUCCESS,
} from './constants';

export function defaultAction() {
  return {
    type: DEFAULT_ACTION,
  };
}

export const loadContent = id => {
  return {
    type: LOAD_CONTENT,
    id,
  };
};
export const loadContentSuccess = data => {
  return {
    type: LOAD_CONTENT_SUCCESS,
    payload: {
      data,
    },
  };
};
export const loadContentFailed = error => {
  return {
    type: LOAD_CONTENT_FAILED,
    error,
  };
};
export const checkIsRegistered = id => {
  return {
    type: CHECK_IS_REGISTER,
    id,
  };
};
export const checkIsRegisteredSuccess = data => {
  return {
    type: CHECK_IS_REGISTER_SUCCESS,
    payload: {
      data,
    },
  };
};
export const checkIsRegisteredFailed = error => {
  return {
    type: CHECK_IS_REGISTER_FAILED,
    error,
  };
};
export const countDown = () => {
  return {
    type: COUNT_DOWN,
  };
};
export const endOfAction = () => {
  return {
    type: END_OF_ACTION,
  };
};
export const showConfirmModal = isShowing => {
  return {
    type: SHOW_CONFIRM_MODAL,
    isShowing,
  };
};


export const confirm = (content) => {
  return {
    type: CONFIRM,
    content
  
  };
};
export const confirmSuccess = data => {
  return {
    type: CONFIRM_SUCCESS,
    payload: {
      data,
    },
  };
};
export const confirmFailed = error => {
  return {
    type: CONFIRM_FAILED,
    error,
  };
};
export const getProfile = (id) => {
  return {
    type: GET_PROFILE,
    id,
  };
};
export const getProfileSuccess = data => {
  return {
    type: GET_PROFILE_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getProfileFailed = () => {
  return {
    type: GET_PROFILE_FAILED,
  };
};