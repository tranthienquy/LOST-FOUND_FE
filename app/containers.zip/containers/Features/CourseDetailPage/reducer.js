/*
 *
 * CourseDetailPage reducer
 *
 */
import produce from 'immer';
import {
  COUNT_DOWN,
  DEFAULT_ACTION,
  LOAD_CONTENT,
  LOAD_CONTENT_SUCCESS,
  END_OF_ACTION,
  SHOW_CONFIRM_MODAL,
  CONFIRM,
  CONFIRM_FAILED,
  CONFIRM_SUCCESS,
  CHECK_IS_REGISTER,
  CHECK_IS_REGISTER_SUCCESS,
  CHECK_IS_REGISTER_FAILED,
  GET_PROFILE,
  GET_PROFILE_FAILED,
  GET_PROFILE_SUCCESS,
} from './constants';

export const initialState = {
  id: '',
  content: {},
  isRegistered: false,
  profile: null,

  loading: {
    getContent: false,
    isRegistered: true,
    confirm: false,
    profile: true,

  },
  countDown: {
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  },
  isRegister:true,
  isExpired: false,
  endOfAction: false,
  confirmModal: false,
};

/* eslint-disable default-case, no-param-reassign */
const courseDetailPageReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case DEFAULT_ACTION:
        break;
      case LOAD_CONTENT:
        draft.loading.getContent = true;
        draft.id = action.id;
        draft.endOfAction= false;
        break;
      case LOAD_CONTENT_SUCCESS:
        if (action.payload.data) {
          draft.content = action.payload.data.value[0];
        }
        break;

        
        case CHECK_IS_REGISTER:
          draft.isRegistered= false;
          break;
        case CHECK_IS_REGISTER_SUCCESS:
          draft.isRegistered = action.payload.data.message == "exited" ? true : false;
          draft.loading.isRegistered = false;
        draft.loading.getContent = false;


          break;
        case CHECK_IS_REGISTER_FAILED:
          draft.isRegistered = false;

          draft.loading.isRegistered= false;
        draft.loading.getContent = false;


          break;
      case COUNT_DOWN:
        var timeleft = new Date(draft.content.DueDate) - new Date().getTime();
        if(timeleft<0){
          draft.isRegister=false;
          draft.isExpired =true;
          break;
        }
        var days = Math.floor(timeleft / (1000 * 60 * 60 * 24));
        var hours = Math.floor(
          (timeleft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60),
        );
        var minutes = Math.floor((timeleft % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((timeleft % (1000 * 60)) / 1000);
        draft.countDown={days, hours, minutes, seconds};
        break;

        case END_OF_ACTION:
           for (var element in draft){
             draft[element]= initialState[element];
           }
           draft.endOfAction=true;
          break;
          case SHOW_CONFIRM_MODAL:
        draft.confirmModal = action.isShowing;
        break;
        case CONFIRM:
          draft.loading.confirm = true;
          break;
        case CONFIRM_SUCCESS:
          draft.loading.confirm = false;

          break;
        case CONFIRM_FAILED:
          draft.loading.confirm = true;

          break;

          case GET_PROFILE:
            draft.loading.profile =  true;
            draft.profile = null;
            break;

            case GET_PROFILE_SUCCESS:
              draft.loading.profile =  false;
              draft.profile = action.payload.data.value[0];
              break;
              case GET_PROFILE_FAILED:
                
                break;
    }
  });

export default courseDetailPageReducer;
