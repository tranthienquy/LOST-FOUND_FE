/**
 *
 * CourseDetailPage
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import makeSelectCourseDetailPage from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import './styles.scss';
import { Helmet } from 'react-helmet';
import {
  Button,
  Card,
  Modal,
  Typography,
  notification,
  List,
  Tooltip,
  Form,
  Input,
} from 'antd';
import { Link, useHistory, withRouter } from 'react-router-dom';
import CourseDetailSkeleton from './CourseDetailSkeleton';
import * as actions from './actions';
import moment from 'moment';
import numeral from 'numeral';
import AuthContext from '../../../utils/auth';
import { LinearProgress } from '@mui/material';
import { Animated } from 'react-animated-css';
import * as api from 'utils/api';
import { KEY_VALUE } from '../../../utils/api/constants';
import { getValidRole } from '../../../utils/permissionUtil';
import { USER_ROLE } from '../../../utils/constants';

class CourseDetailPage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      feeTypeList: [],
      durationTypeList: [],
    };
    api
      .postPagination(
        `v1/KeyValues`,
        null,
        null,
        `TGroup eq ${KEY_VALUE.FEETYPE}`,
        null,
      )
      .then(res => {
        this.setState({ feeTypeList: res.data.value });
      });
    api
      .postPagination(
        `v1/KeyValues`,
        null,
        null,
        `TGroup eq ${KEY_VALUE.DURATION_TYPE}`,
        null,
      )
      .then(res => {
        this.setState({ durationTypeList: res.data.value });
      });
  }
  componentWillMount() {
    const { id } = this.props.match.params;
    if (id) {
      this.props.onLoadContent(id);
    }
  }
  componentWillReceiveProps(nextProps) {
    const { id } = nextProps.match.params;
    if (nextProps.match.params !== this.props.match.params) {
      if (id) {
        this.props.onLoadContent(id);
      }
    }
  }
  componentWillUnmount() {
    this.props.onEndOfAction();
  }
  showConfirmModal = isShowing => {
    if (!this.context.user) {
      this.props.history.replace('/login');
      notification.open({
        message: 'Vui lòng đăng nhập để tham gia khóa học',
        type: 'info',
      });
      return;
    }
    this.props.onShowConfirmModal(isShowing);
    this.props.onGetProfile(this.context.user.Id);
  };
  onSubmit = value => {
    console.log(value);
    this.props.onConfirmCourse({ id: this.context.user.Id, ...value });
    // this.props.onRegister(value);
  };
  onSubmitFailed = errorInfo => {};

  render() {
    const {
      id,
      content,
      loading,
      profile,
      countDown,
      isRegister,
      isExpired,
      confirmModal,
      isRegistered,
    } = this.props.courseDetailPage;
    return (
      <div className="course-detail-container d-flex flex-column pt-5">
        <Helmet>
          <title>Khóa học</title>
        </Helmet>

        <div className="d-flex justify-content-between">
          <Typography.Text
            className="link-text-on-click"
            type="secondary"
            onClick={() => this.props.history.goBack()}
          >
            <i className="icon-Caret-left" /> Quay lại
          </Typography.Text>
          {getValidRole(this.context.user, [USER_ROLE.SHINYAMA]) && (
            <Link to={`/course-form/edit/${id}`}>
              {' '}
              <Button className="text-center d-flex align-items-center  mt-3">
                <i className="icon-Edit-outline mr-2" />{' '}
                <b className="w-100 text-center"> CHỈNH SỬA</b>
              </Button>
            </Link>
          )}
        </div>
        {loading.getContent ? (
          <CourseDetailSkeleton />
        ) : (
          <React.Fragment>
            <Card className="w-100 introduction-card mt-4">
              <div className="row">
                <div className="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                  <img
                    src={
                      content.Image
                        ? content.Image.startsWith('http')
                          ? content.Image
                          : `${this.context.prefixLink}/${content.Image}`
                        : require('../../../images/logo/logo-shinyama-grayscale.png')
                    }
                    width={'100%'}
                    height={'190px'}
                  />
                </div>
                <div className="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                  <Typography className="font-weight-bold h4 mt-4">
                    {content.Name}
                  </Typography>
                  <div className="d-flex flex-row flex-wrap">
                    <Typography
                      style={{ fontSize: '16px' }}
                      className="text-app-primary mt-2 mr-3 d-flex align-items-center"
                    >
                      <i
                        style={{ fontSize: '25px' }}
                        className=" mr-2 icon-Location-outline"
                      />
                      {content.Location}
                    </Typography>
                    <Typography
                      style={{ fontSize: '16px' }}
                      className="text-app-primary mt-2 mr-3 d-flex align-items-center"
                    >
                      <i
                        style={{ fontSize: '25px' }}
                        className=" mr-2 icon-Play-outline"
                      />
                      {content.Type}
                    </Typography>
                    <Typography
                      style={{ fontSize: '16px' }}
                      className="text-app-primary mt-2 mr-3 d-flex align-items-center"
                    >
                      <i
                        style={{ fontSize: '25px' }}
                        className=" mr-2 icon-Clock-outline"
                      />
                      Thời gian học:{' '}
                      {moment(content.StartDate).format('DD/MM/YYYY')} -{' '}
                      {moment(content.EndDate).format('DD/MM/YYYY')}
                    </Typography>
                    <Typography
                      style={{ fontSize: '16px' }}
                      className="text-app-primary mt-2 mr-3 d-flex align-items-center"
                    >
                      <i
                        style={{ fontSize: '25px' }}
                        className=" mr-2 icon-Sand-watch-outline"
                      />
                      Thời lượng: {content.Duration}{' '}
                      {this.state.durationTypeList.find(
                        el => el.TKey == content.DurationType,
                      ) &&
                        this.state.durationTypeList.find(
                          el => el.TKey == content.DurationType,
                        ).TValue}
                    </Typography>
                  </div>
                  <Typography className="mt-3 text-app-primary font-weight-bold h4">
                    {numeral(content.Fee).format('0,0 ')}{' '}
                    {this.state.feeTypeList.find(
                      el => el.TKey == content.FeeType,
                    ) &&
                      this.state.feeTypeList.find(
                        el => el.TKey == content.FeeType,
                      ).TValue}
                  </Typography>

                  {!loading.isRegistered && !isRegistered && (
                    <Button
                      size="large"
                      type="primary"
                      className={`text-center w-100 mt-3 ${
                        isRegister ? '' : 'not-register'
                      }`}
                      disabled={!isRegister}
                      onClick={() => this.showConfirmModal(true)}
                    >
                      <i className="icon-University-outline icon-left mr-2" />{' '}
                      <b className="w-100 text-center">
                        {' '}
                        {!isExpired ? 'ĐĂNG KÝ NGAY' : 'HẾT HẠN ĐĂNG KÝ'}{' '}
                      </b>
                    </Button>
                  )}

                  {!loading.isRegistered && isRegistered && (
                    <Animated animationIn="fadeIn" animationInDuration={500}>
                      <Typography className="text-app-primary h4 font-weight-bold mt-3 d-flex align-items-center">
                        <i className="icon-Check-outline " /> ĐÃ ĐĂNG KÝ
                      </Typography>
                    </Animated>
                  )}

                  <Typography
                    style={{ fontSize: '17px' }}
                    className="mt-3 font-weight-bold text-app-primary mt-2 mr-3 d-flex align-items-center"
                  >
                    <i
                      style={{ fontSize: '20px' }}
                      className=" mr-2 icon-Sand-watch-outline"
                    />
                    THỜI GIAN CÒN LẠI
                  </Typography>
                  <div className="d-flex flex-row mt-3">
                    <div className="watch-count d-flex flex-column justify-content-center align-items-center mr-3">
                      <Typography className="watch-count__number">
                        {countDown.days ? countDown.days : '0'}
                      </Typography>
                      <Typography className="watch-count__currency">
                        NGÀY
                      </Typography>
                    </div>
                    <div className="watch-count d-flex flex-column justify-content-center align-items-center mr-3">
                      <Typography className="watch-count__number">
                        {countDown.hours ? countDown.hours : '0'}
                      </Typography>
                      <Typography className="watch-count__currency">
                        GIỜ
                      </Typography>
                    </div>
                    <div className="watch-count d-flex flex-column justify-content-center align-items-center mr-3">
                      <Typography className="watch-count__number">
                        {countDown.minutes ? countDown.minutes : '0'}
                      </Typography>
                      <Typography className="watch-count__currency">
                        PHÚT
                      </Typography>
                    </div>
                    <div className="watch-count d-flex flex-column justify-content-center align-items-center mr-3">
                      <Typography className="watch-count__number">
                        {countDown.seconds ? countDown.seconds : '0'}
                      </Typography>
                      <Typography className="watch-count__currency">
                        GIÂY
                      </Typography>
                    </div>
                  </div>
                </div>
              </div>
            </Card>

            <div className="row">
              <div className="d-flex flex-column pr-5 col-xs-12 col-sm-12 col-md-12 col-lg-9">
                <Card
                  size="small"
                  className="card-description mt-4"
                  title={
                    <Typography
                      style={{ fontSize: '24px' }}
                      className=" text-app-primary font-weight-bold mt-2 d-flex align-items-center"
                    >
                      <i
                        style={{ fontSize: '29px' }}
                        className=" mr-2 icon-Checked-box-outline"
                      />
                      MỤC TIÊU KHÓA HỌC
                    </Typography>
                  }
                >
                  <Typography.Text style={{ whiteSpace: 'pre-wrap' }}>
                    {content.Objective}
                  </Typography.Text>
                </Card>
                <Card
                  size="small"
                  className="card-description mt-4"
                  title={
                    <Typography
                      style={{ fontSize: '24px' }}
                      className=" text-app-primary font-weight-bold mt-2 d-flex align-items-center"
                    >
                      <i
                        style={{ fontSize: '29px' }}
                        className=" mr-2 icon-Book-open-outline"
                      />
                      CHI TIẾT CHƯƠNG TRÌNH HỌC
                    </Typography>
                  }
                >
                  <Typography.Text style={{ whiteSpace: 'pre-wrap' }}>
                    {content.Description}
                  </Typography.Text>
                </Card>
                <Card
                  size="small"
                  className="card-description mt-4"
                  title={
                    <Typography
                      style={{ fontSize: '24px' }}
                      className=" text-app-primary font-weight-bold mt-2 d-flex align-items-center"
                    >
                      <i
                        style={{ fontSize: '29px' }}
                        className=" mr-2 icon-Box-outline"
                      />
                      TÀI LIỆU THAM KHẢO
                    </Typography>
                  }
                >
                  <List
                    dataSource={content.FileStorages}
                    className="w-100"
                    renderItem={item => (
                      <div
                        className="d-flex flex-row justify-content-between align-items-center list-item"
                        style={{
                          backgroundColor: item.originFileObj && '#edffe6',
                        }}
                      >
                        <Typography className="d-flex flex-row mt-2 pl-2 ">
                          <i className="icon-Document-outline mr-2 h5 " />
                          <span>
                            {item.originFileObj ? item.name : item.Link}
                          </span>
                          {/* <i className='ml-2' style={{color:'#aeaeae'}}>18/6/2002</i> */}
                        </Typography>
                        <div>
                          {/* <Tooltip placement="top" title={'Xem'}>
                   <i className="icon-Eye-outline cursor-pointer h4" onClick={()=>this.props.onPreviewModal(true, item)} />
                   </Tooltip> */}
                          <Tooltip
                            placement="top"
                            title={'Tải về'}
                            onClick={() => {
                              window.open(
                                `${this.context.prefixLink}/${item.Link}`,
                              );
                            }}
                          >
                            <i className="icon-Download-outline cursor-pointer h4" />
                          </Tooltip>
                        </div>
                      </div>
                    )}
                  />
                </Card>
              </div>
              <div className="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <Card hoverable className="course-card mt-4">
                  <div className="d-flex flex-column">
                    <img
                      src={
                        content.Image
                          ? content.Image.startsWith('http')
                            ? content.Image
                            : `${this.context.prefixLink}/${content.Image}`
                          : require('../../../images/logo/logo-shinyama-grayscale.png')
                      }
                      width={'100%'}
                      height={'150px'}
                      style={{ objectFit: 'cover' }}
                    />
                    <div className="p-2">
                      <Typography className="h7 font-weight-bold mb-2">
                        {content.Name}
                      </Typography>
                      <Typography
                        style={{ fontSize: '12px' }}
                        className="d-flex align-items-center text-app-primary"
                      >
                        <i
                          style={{ fontSize: '17px' }}
                          className="mr-1 icon-Sand-watch"
                        />{' '}
                        Ngày hết hạn:{' '}
                        {moment(content.DueDate).format('DD/MM/YYYY')}
                      </Typography>
                      <Typography
                        style={{ fontSize: '12px' }}
                        className="d-flex align-items-center text-app-primary"
                      >
                        <i
                          style={{ fontSize: '17px' }}
                          className="mr-1 icon-Location"
                        />
                        Địa điểm: {content.Location}
                      </Typography>
                      <Typography
                        style={{ fontSize: '12px' }}
                        className="d-flex align-items-center text-app-primary"
                      >
                        <i
                          style={{ fontSize: '17px' }}
                          className="mr-1 icon-Play"
                        />{' '}
                        Hình thức: {content.Type}
                      </Typography>
                      {!loading.isRegistered && !isRegistered && (
                        <Button
                          type="primary"
                          className={`text-center w-100 mt-3 ${
                            isRegister ? '' : 'not-register'
                          }`}
                          disabled={!isRegister}
                          onClick={() => this.showConfirmModal(true)}
                        >
                          <i className="icon-University-outline icon-left mr-2" />{' '}
                          <b className="w-100 text-center">
                            {' '}
                            {!isExpired
                              ? 'ĐĂNG KÝ NGAY'
                              : 'HẾT HẠN ĐĂNG KÝ'}{' '}
                          </b>
                        </Button>
                      )}
                      {!loading.isRegistered && isRegistered && (
                        <Animated
                          animationIn="fadeIn"
                          animationInDuration={500}
                        >
                          <Typography className="text-app-primary font-weight-bold mt-3 d-flex align-items-center">
                            <i className="icon-Check-outline h5" /> ĐÃ ĐĂNG KÝ
                          </Typography>
                        </Animated>
                      )}
                    </div>
                  </div>
                </Card>
              </div>
            </div>
          </React.Fragment>
        )}

        <Modal
          style={{ maxWidth: '1080px', minWidth: '50vw' }}
          width={'fit-content'}
          footer={''}
          onCancel={() => this.showConfirmModal(false)}
          visible={confirmModal}
          title={
            <Typography className="text-center  font-weight-bold ">
              XÁC NHẬN ĐĂNG KÝ KHÓA HỌC
            </Typography>
          }
        >
            {!loading.profile && profile && (
           <Form
                name="basic"
                onFinish={this.onSubmit}
                autoComplete="off"
                layout="vertical"
                initialValues={{
                  FirstName: profile.FirstName,
                  LastName: profile.LastName,
                  Email: this.context.user.Email,
                }}
                onFinishFailed={this.onSubmitFailed}
                className="ant-general-form"
              >
          <Card className="w-100 introduction-card mt-4">
          
             
                <div className="row">
                  <div className="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                    <img
                      src={
                        content.Image
                          ? content.Image.startsWith('http')
                            ? content.Image
                            : `${this.context.prefixLink}/${content.Image}`
                          : require('../../../images/logo/logo-shinyama-grayscale.png')
                      }
                      width={'100%'}
                      height={'190px'}
                    />
                  </div>
                  <div className="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                    <Typography className="font-weight-bold h4 mt-4">
                      {content.Name}
                    </Typography>

                    <>
                      <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
                          <Form.Item
                            label="Tên"
                            name="FirstName"
                            rules={[
                              { required: true, message: 'Vui lòng nhập Tên' },
                            ]}
                          >
                            <Input size="large" />
                          </Form.Item>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
                          <Form.Item
                            label="Họ"
                            name="LastName"
                            rules={[
                              { required: true, message: 'Vui lòng nhập Họ' },
                            ]}
                          >
                            <Input size="large" />
                          </Form.Item>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                          <Form.Item
                            label="Email"
                            name="Email"
                            rules={[
                              {
                                required: true,
                                message: 'Vui lòng nhập Email',
                              },
                              {
                                type: 'email',
                                message: 'Email không đúng định dạng',
                              },
                            ]}
                          >
                            <Input size="large" />
                          </Form.Item>
                        </div>
                      </div>
                    </>
                  </div>
                </div>
                
           
          </Card>
          <Form.Item>
            <Button
              type="primary"
              htmlType="submit"
              className={`text-center w-100 mt-3 ${
                isRegister ? '' : 'not-register'
              }`}
              disabled={!isRegister}
            >
              <i className="icon-University-outline icon-left mr-2" />{' '}
              <b className="w-100 text-center">
                {' '}
                {!isExpired ? 'ĐĂNG KÝ NGAY' : 'HẾT HẠN ĐĂNG KÝ'}{' '}
              </b>
            </Button>
          </Form.Item>
          {loading.confirm ? <LinearProgress color="success" /> : ''}
          </Form>
  )}
        </Modal>
      </div>
    );
  }
}

CourseDetailPage.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  courseDetailPage: makeSelectCourseDetailPage(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    onLoadContent: id => {
      dispatch(actions.loadContent(id));
    },
    onEndOfAction: () => {
      dispatch(actions.endOfAction());
    },
    onShowConfirmModal: isShowing => {
      dispatch(actions.showConfirmModal(isShowing));
    },
    onConfirmCourse: content => {
      dispatch(actions.confirm(content));
    },
    onGetProfile: id => {
      dispatch(actions.getProfile(id));
    },
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);
const withReducer = injectReducer({ key: 'courseDetailPage', reducer });
const withSaga = injectSaga({ key: 'courseDetailPage', saga });
CourseDetailPage.contextType = AuthContext;

export default compose(
  withConnect,
  withReducer,
  withSaga,
  withRouter,
)(CourseDetailPage);
