import { take, call, put, select, takeLatest, delay } from 'redux-saga/effects';
import * as types from './constants';
import * as actions from './actions';
import * as api from 'utils/api';
import { notification } from 'antd';
import { push } from 'react-router-redux';


// Individual exports for testing
function* loadContent({ id }) {
  const resp = yield call(
    api.get,
    `v1/Courses(${id})?$expand=FileStorages(filter = status ne 0)`,
  );
  const { data, status } = resp;

  if (status == 200 ) {
    yield delay(1000);
    yield put(actions.loadContentSuccess(data));
    yield put(actions.checkIsRegistered(id));

    yield countDown();
  } else {
    yield put(actions.loadContentFailed());
  }

}
function* countDown(){

  while(true){
    yield put(actions.countDown());
    yield delay(1000);
    const { endOfAction } = yield select(state => state.courseDetailPage);
    if (endOfAction) break;
  }
}

function* confirmCousre({content}){
  if(!content){
    yield notification.open({
      message:"Vui lòng đăng nhập để tham khoa khóa học"
    })
    return
  }
  const { Id } = yield select(state => state.courseDetailPage.content);
  const requestBody ={
    // profileId,
    CourseId: Id,
    ...content
  }
  const resp = yield call(
    api.post,
    `v1/CourseSubmit/submit`, {}, requestBody
  );
  const { data, status } = resp;
  if (status == 201 ) {
    yield delay(2000);
    yield put(actions.confirmSuccess(data));
    yield notification.open({
      message:"Đăng ký khóa học thành công",
      type:"success"
    })
    yield put(actions.loadContent(Id));
    yield put(actions.showConfirmModal(false));
  } else {
    yield put(actions.confirmFailed());
  }
}

function* checkIsRegistered ({id}){
  yield delay(1000);
  const resp = yield call(api.get, `v1/UserProfiles/check-course-submited?courseId=${id}`);
  const { data, status } = resp;

  if (status == 200) {
    yield put(actions.checkIsRegisteredSuccess(data));
  } else {
    yield put(actions.checkIsRegisteredFailed());
  }
}


function* getProfile({ id }) {
  const resp = yield call(api.get, `v1/UserProfiles(${id})`);
  const { data, status } = resp;

  if (status == 200) {
    yield put(actions.getProfileSuccess(data));
    yield console.log(data.value[0]);
  } else {
    yield put(actions.getProfileFailed());
  }
}

export default function* courseDetailPageSaga() {
  // See example in containers/HomePage/saga.js
  yield takeLatest(types.LOAD_CONTENT, loadContent);
  yield takeLatest(types.CHECK_IS_REGISTER, checkIsRegistered);

  yield takeLatest(types.CONFIRM, confirmCousre);
  yield takeLatest(types.GET_PROFILE, getProfile);

}
