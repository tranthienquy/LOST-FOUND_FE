/*
 *
 * RecruitmentRequestShinyamaPage reducer
 *
 */
import produce from 'immer';
import * as types from './constants';

export const initialState = {

  professionList: [],
  skillList: [],
  content:[],
  shinyamaList:[],
  loading: {
skillList: false,
professionList: false,
getContent:true,
shinyamaList: false
  },
  current: 1,
  pageSize: 10,
  total: 0,
};

/* eslint-disable default-case, no-param-reassign */
const recruitmentRequestShinyamaPageReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case types.DEFAULT_ACTION:
        break;
      case types.END_OF_ACTION:
        for (var element in draft) {
          draft[element] = initialState[element];
        }
        break;

        case types.CHANGE_SELECT_VALUE:
        console.log(action);
          draft.content.find(el=> el.RequestId=== action.id)[action.name] = action.value;  
        break;

        case types.GET_PROFESSION:
          draft.loading.professionList = action.content ? true : false;
          if (!action.content) {
            draft.professionList = [];
          }
          break;
        case types.GET_PROFESSION_SUCCESS:
          draft.loading.professionList = false;
          draft.professionList = action.payload.data.value;
          break;
        case types.GET_PROFESSION_FAILED:
          break;

          case types.GET_SHINYAMA:
            draft.loading.shinyamaList = action.content ? true : false;
            if (!action.content) {
              draft.shinyamaList = [];
            }
            break;
          case types.GET_SHINYAMA_SUCCESS:
            draft.loading.shinyamaList = false;
            draft.shinyamaList = action.payload.data;
            break;
          case types.GET_SHINYAMA_FAILED:
            break;
    
  
        case types.GET_SKILL:
          draft.loading.skillList = action.content ? true : false;
          if (!action.content) {
            draft.skillList = [];
          }
          break;
        case types.GET_SKILL_SUCCESS:
          draft.loading.skillList = false;
          draft.skillList = action.payload.data.value;
          break;
        case types.GET_SKILL_FAILED:
          break;
          case types.GET_CONTENT:
            draft.loading.getContent = true;
            break;
          case types.GET_CONTENT_SUCCESS:
            draft.loading.getContent = false;
            draft.content = action.payload.data.results;
            draft.total = action.payload.data.total;
            break;
          case types.GET_CONTENT_FAILED:
            draft.loading.getContent = false;
            break;
            case types.PAGINATION:
              draft.current = action.current;
              draft.pageSize = action.pageSize;
              break;
              case types.SUBMIT_CONTENT:
                draft.loading.submit = true;
                break;
              case types.SUBMIT_CONTENT_SUCCESS:
                draft.loading.submit = false;
        
                break;
              case types.SUBMIT_CONTENT_FAILED:
                draft.loading.submit = false;
                break;
    }
  });

export default recruitmentRequestShinyamaPageReducer;
