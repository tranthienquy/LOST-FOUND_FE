/**
 *
 * RecruitmentRequestShinyamaPage
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import makeSelectRecruitmentRequestShinyamaPage from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import * as actions from './actions';
import './styles.scss';
import {
  Input,
  Table,
  Typography,
  Form,
  Button,
  DatePicker,
  Tabs,
  Select,
  Tag,
} from 'antd';
import { Link } from 'react-router-dom';
import RecruitmentRequestRecruiterPage from '../RecruitmentRequestRecruiterPage';
import { LinearProgress } from '@mui/material';
import AuthContext from '../../../utils/auth';
import { getValidRole } from '../../../utils/permissionUtil';
import { USER_ROLE } from '../../../utils/constants';
class RecruitmentRequestShinyamaPage extends React.Component {
  componentWillUnmount() {
    this.props.onEndOfAction();
  }
  searchProfession = value => {
    this.props.onGetProfessionList(value);
  };
  searchSkill = value => {
    this.props.onGetSkillList(value);
  };
  componentWillMount(){
    console.log(this.context.user);
    if (getValidRole(this.context.user, [USER_ROLE.SHINYAMA_MANAGER]) ){
          this.props.onGetContentList();
    this.props.onGetShinyamaList();
    }

  }

  handleTableChange = (newPagination, filters, sorter)=>{
    console.log(newPagination, filters, sorter );
    this.props.onPagination(newPagination.current, newPagination.pageSize)
    this.props.onGetContentList();

} 

  dataSource = [
    {
      ID: '1',
      Titlesad: (
        <Form.Item name="Title">
          <Input name="Title" />
        </Form.Item>
      ),
    },
  ];
  onSubmit = value => {
    console.log(value);
  };
  onSubmitFailed = errorInfo => {};
  onChangeTab = key => {
    console.log(key);
  };
  changeSelectValue = (event, id)=>{
    console.log(event, id)
    this.props.onChangeSelectValue(id, 'ShinyamaId', event)
      }
 
  column2= [
    {
      title: 'ID',
      key: 'RequestId',
      dataIndex: 'RequestId',
      width: 40
    },
    {
      title: 'Yêu cầu tuyển dụng',
      key: 'Title',
      dataIndex: 'Title',
    },
    {
      title: 'Liên hệ',
      key: 'RecuiterEmail',
      dataIndex: 'RecuiterEmail',
    },
    {
      title: 'Ngành nghề',
      key: 'Profession',
      dataIndex: 'Profession',
    },   {
      title: 'Kỹ năng',
      key: 'ListSkill',
      dataIndex: 'ListSkill',
      render: (value, record)=> value.map(el=> (<Tag>{el}</Tag>))
    },
    {
      title: 'Số lượng',
      key: 'Quantity',
      dataIndex: 'Quantity',
      width:80

    },
    {
      title: 'Ngày yêu cầu',
      key: 'CreateDate',
      dataIndex: 'CreateDate',
      width:100
    },
    {
      title: 'Ngày hết hạn',
      key: 'DueDate',
      dataIndex: 'DueDate',
      width:100

    },
    {
      title: 'Người phụ trách (Shinyama)',
      key: 'ShinyamaId',
      dataIndex: 'ShinyamaId',
      render: (value, record) => <span>  <Select 
      onChange={(value)=>this.changeSelectValue(value, record.RequestId )}
              suffixIcon={<i className="icon-Caret-down h3" />}
              value={value}
            >
              {this.props.recruitmentRequestShinyamaPage.shinyamaList.map(el=><Select.Option key={`shinyama-${el.Id}`} value={el.Id}>{el.Name}</Select.Option>)}
     
            </Select></span>

    },
    {
      title: 'Trạng thái',
      key: 'Info',
      dataIndex: 'Info',
    },
 
  ]
  render() {
    const {
      loading,
      professionList,
      skillList,shinyamaList,
      content,total,current, pageSize
    } = this.props.recruitmentRequestShinyamaPage;
    return (
      <div className="recruitment-request-container d-flex flex-column pt-5">
       
      
          <Button htmlType='submit'></Button>
          <div className="d-flex justify-content-between ">
            <Typography className="text-app-primary h4 font-weight-bold">
              DANH SÁCH YÊU CẦU TUYỂN DỤNG
            </Typography> 
            <div className='d-flex flex-row'>
             <Link to={'/send-partner-request'} className="mr-2">
              <Button><i className='icon-Send-outline'></i>Gửi yêu cầu tuyển dụng cho đối tác </Button>
            </Link>
            <Link to={'/recruitment-request-shinyama/add'}>
              <Button> + Tạo mới yêu cầu tuyển dụng </Button>
            </Link>
          </div>
          </div>
          <div className="d-flex justify-content-end ">
            {/* <Button> Xuất Excel </Button> */}
          </div>
          <Tabs defaultActiveKey="1" onChange={this.onChangeTab}>
          {getValidRole(this.context.user, [USER_ROLE.SHINYAMA_MANAGER]) && (
          <Tabs.TabPane tab="Yêu cầu tuyển dụng mới" key="1" >
        <Table
            className="mt-5"
            size='small'
            columns={this.column2}
            scroll={{ x: 2000, y: 1000 }}
            dataSource={content}
         onChange={this.handleTableChange}
         pagination={{total,current, pageSize}}
         loading={loading.getContent}
          >

          </Table>

          <Button
              size="large"
              type="primary"
              htmlType="submit"
              className="text-center w-100 mt-3"
              onClick={()=>this.props.onSubmitContent()}
            >
              <b className="w-100 text-center">XÁC NHẬN</b>
            </Button>

            <div style={{ height: '10px' }}>
                {loading.submit ? <LinearProgress color="success" /> : ''}
              </div>
          </Tabs.TabPane>)}
          <Tabs.TabPane tab="Yêu cầu tuyển dụng đã phân công" key="2" >
      <RecruitmentRequestRecruiterPage/>
          

            </Tabs.TabPane>
        </Tabs>

         
       
      </div>
    );
  }
}

RecruitmentRequestShinyamaPage.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  recruitmentRequestShinyamaPage: makeSelectRecruitmentRequestShinyamaPage(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    onEndOfAction: () => {
      dispatch(actions.endOfAction());
    },
    onGetProfessionList: content => {
      dispatch(actions.getProfessionList(content));
    },
    onGetShinyamaList: content => {
      dispatch(actions.getShinyamaList(content));
    },
    onGetSkillList: content => {
      dispatch(actions.getSkillList(content));
    },
    onGetContentList: content => {
      dispatch(actions.getContent(content));
    },
    onPagination: (current, pageSize) => {
      dispatch(actions.pagination(current, pageSize));
    },
    onChangeSelectValue: (id, name, value) => {
      dispatch(actions.changeSelectValue(id, name, value));
    },
    onSubmitContent: () => {
      dispatch(actions.submitContent());
    },
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

const withReducer = injectReducer({
  key: 'recruitmentRequestShinyamaPage',
  reducer,
});
RecruitmentRequestShinyamaPage.contextType = AuthContext;
const withSaga = injectSaga({ key: 'recruitmentRequestShinyamaPage', saga });
export default compose(
  withConnect,
  withReducer,
  withSaga,
)(RecruitmentRequestShinyamaPage);
