import { take, call, put, select, takeLatest, delay, fork, takeEvery } from 'redux-saga/effects';
import * as types from './constants';
import * as actions from './actions';
import * as api from 'utils/api';
import { KEY_VALUE } from '../../../utils/api/constants';
import { notification } from 'antd';
// Individual exports for testing

function* getProfessionList({content}){
  if (content){
    yield delay(500);

  const resp = yield call(
    api.postPagination,
    `v1/KeyValues`,
    null,
    null,
    `TGroup eq ${KEY_VALUE.PROFESSION} and contains(tolower(TValue),tolower('${encodeURIComponent(content)}'))`,
    null
  );
  const { data, status } = resp;
  if (status == 200) {
    yield put(actions.getProfessionListSuccess(data));
  } else {
    yield put(actions.getProfessionListFailed());
  }
}
}


function* getSkillList({content}){

  if (content){
    yield delay(500);

  const resp = yield call(
    api.postPagination,
    `v1/KeyValues`,
    null,
    null,
    `TGroup eq ${KEY_VALUE.SKILL} and contains(tolower(TValue),tolower('${encodeURIComponent(content)}'))`,
    null
  );
  const { data, status } = resp;
  if (status == 200) {
    yield put(actions.getSkillListSuccess(data));
  } else {
    yield put(actions.getSkillListFailed());
  }
}
}
function* getContent ({content}){
  const { current, pageSize } = yield select(state => state.recruitmentRequestShinyamaPage);
  let filter = '' ;
  

  const resp = yield call(
    api.get,
    `v1/Requests/get-new-request-for-manager`,
    {...content, NumPage:current, PerPage: pageSize},
  );
  const { data, status } = resp;
  if (status == 200) {
    yield delay(500);
    yield put(actions.getContentSuccess(data));
  } else {
    yield put(actions.getContentFailed());
  }
}
function* getShinyamaList ({content}){
  const { current, pageSize } = yield select(state => state.recruitmentRequestShinyamaPage);
  let filter = '' ;
  

  const resp = yield call(
    api.get,
    `v1/UserProfiles/get-listShinyama`,
    {...content, NumPage:1, PerPage: 10000},
  );
  const { data, status } = resp;
  if (status == 200) {
    yield delay(500);
    yield put(actions.getShinyamaListSuccess(data));
  } else {
    yield put(actions.getShinyamaListFailed());
  }
}
function* submitContent() {
  const {content } = yield select(state => state.recruitmentRequestShinyamaPage);
  const requestdata = content.map(item=> ({RequestId: item.RequestId, ShinyamaId: item.ShinyamaId}))
  const resp = yield call(api.post, `v1/Requests/assign-shinyama`, {}, 
 requestdata.filter(item=>item.ShinyamaId)
  );
  const { data, status } = resp;
  if (status == 200) {
    yield delay(200);
    yield put(actions.submitContentSuccess(data));
    yield notification.open({
      message: 'Cập nhật thành công',
      type:'success'
    });
    yield put(actions.getContent());
    // yield put(push('/job'));
  } else {
    yield put(actions.submitContentFailed('password-failed'));
  }
}
export default function* recruitmentRequestShinyamaPageSaga() {
  // See example in containers/HomePage/saga.js
  yield takeLatest(types.GET_PROFESSION, getProfessionList)
  yield takeLatest(types.GET_SHINYAMA, getShinyamaList)
  yield takeLatest(types.GET_SKILL, getSkillList)
  yield takeLatest(types.GET_CONTENT, getContent)
  yield takeLatest(types.SUBMIT_CONTENT, submitContent)
}
