/*
 * RecruitmentRequestShinyamaPage Messages
 *
 * This contains all the text for the RecruitmentRequestShinyamaPage container.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.containers.RecruitmentRequestShinyamaPage';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'This is the RecruitmentRequestShinyamaPage container!',
  },
});
