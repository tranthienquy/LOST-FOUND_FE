/*
 *
 * RecruitmentRequestShinyamaPage actions
 *
 */

import {
  DEFAULT_ACTION,
  END_OF_ACTION,
  GET_PROFESSION,
  GET_PROFESSION_FAILED,
  GET_PROFESSION_SUCCESS,
  GET_SKILL,
  GET_SKILL_SUCCESS,
  GET_SKILL_FAILED,
  GET_CONTENT,
  GET_CONTENT_SUCCESS,
  GET_CONTENT_FAILED,
  GET_SHINYAMA,
  GET_SHINYAMA_SUCCESS,
  GET_SHINYAMA_FAILED,
  PAGINATION,
  CHANGE_SELECT_VALUE,
  SUBMIT_CONTENT, SUBMIT_CONTENT_FAILED, SUBMIT_CONTENT_SUCCESS
} from './constants';

export function defaultAction() {
  return {
    type: DEFAULT_ACTION,
  };
}
export const endOfAction = () => {
  return {
    type: END_OF_ACTION,
  };
};
export const changeSelectValue = (id, name,value) => {
  return {
    type: CHANGE_SELECT_VALUE,
    id, name, value
  };
};


export const getProfessionList = (content = '') => {
  return {
    type: GET_PROFESSION,
    content,
  };
};
export const getProfessionListSuccess = data => {
  return {
    type: GET_PROFESSION_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getProfessionListFailed = () => {
  return {
    type: GET_PROFESSION_FAILED,
  };
};
export const getShinyamaList = (content = '') => {
  return {
    type: GET_SHINYAMA,
    content,
  };
};
export const getShinyamaListSuccess = data => {
  return {
    type: GET_SHINYAMA_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getShinyamaListFailed = () => {
  return {
    type: GET_SHINYAMA_FAILED,
  };
};

export const getSkillList = (content = '') => {
  return {
    type: GET_SKILL,
    content,
  };
};
export const getSkillListSuccess = data => {
  return {
    type: GET_SKILL_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getSkillListFailed = () => {
  return {
    type: GET_SKILL_FAILED,
  };
};
export const getContent = (content = '') => {
  return {
    type: GET_CONTENT,
    content,
  };
};
export const getContentSuccess = data => {
  return {
    type: GET_CONTENT_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getContentFailed = () => {
  return {
    type: GET_CONTENT_FAILED,
  };
};

export const pagination = (current, pageSize) => {
  return {
    type: PAGINATION,
    current,
    pageSize,
  };
};

export const submitContent = value => {
  return {
    type: SUBMIT_CONTENT,
    value,
  };
};
export const submitContentSuccess = data => {
  return {
    type: SUBMIT_CONTENT_SUCCESS,
    payload: {
      data,
    },
  };
};
export const submitContentFailed = error => {
  return {
    type: SUBMIT_CONTENT_FAILED,
    error,
  };
};
