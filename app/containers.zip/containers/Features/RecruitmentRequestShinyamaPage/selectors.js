import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the recruitmentRequestShinyamaPage state domain
 */

const selectRecruitmentRequestShinyamaPageDomain = state =>
  state.recruitmentRequestShinyamaPage || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by RecruitmentRequestShinyamaPage
 */

const makeSelectRecruitmentRequestShinyamaPage = () =>
  createSelector(
    selectRecruitmentRequestShinyamaPageDomain,
    substate => substate,
  );

export default makeSelectRecruitmentRequestShinyamaPage;
export { selectRecruitmentRequestShinyamaPageDomain };
