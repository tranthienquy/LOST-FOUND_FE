import {
  take,
  call,
  put,
  select,
  takeLatest,
  delay,
  fork,
  takeEvery,
} from 'redux-saga/effects';
import * as types from './constants';
import * as actions from './actions';
import * as api from 'utils/api';
import { API_ENDPOINT, KEY_VALUE } from '../../../utils/api/constants';
import { notification } from 'antd';
import moment from 'moment';
import { saveAs } from 'file-saver';


function* getProfessionList() {
    yield delay(500);

    const resp = yield call(
      api.postPagination,
      `v1/KeyValues`,
      null,
      null,
      `TGroup eq ${
        KEY_VALUE.PROFESSION
      }`,
      null,
    );
    const { data, status } = resp;
    if (status == 200) {
      yield put(actions.getProfessionListSuccess(data));
    } else {
      yield put(actions.getProfessionListFailed());
    }
}

function* getSkillList({ content }) {
  if (content && content.length > 0) {
    yield delay(500);
    let searchFilter = '';
    if (typeof content == 'string') {
      // Search by TValue
      searchFilter = `contains(tolower(TValue),tolower('${encodeURIComponent(
        content,
      )}'))`;
    } else {
      // Search by TKey Array
      content.forEach(el => {
        searchFilter += `contains(tolower(TKey),tolower('${encodeURIComponent(
          el,
        )}')) or `;
      });
      searchFilter = searchFilter.slice(0, -3);
    }
    const resp = yield call(
      api.postPagination,
      `v1/KeyValues`,
      null,
      null,
      `TGroup eq ${
        KEY_VALUE.SKILL
      } and `+ searchFilter,
      null,
    );
    const { data, status } = resp;
    if (status == 200) {
      yield put(actions.getSkillListSuccess(data));
    } else {
      yield put(actions.getSkillListFailed());
    }
  }
}



function* getCertificateList({ content }) {
  console.log(content);
  if (content && content.length > 0) {
    yield delay(500);
    let searchFilter = '';
    if (typeof content == 'string') {
      // Search by TValue
      searchFilter = `contains(tolower(TValue),tolower('${encodeURIComponent(
        content,
      )}'))`;
    } else {
      // Search by TKey Array
      content.forEach(el => {
        searchFilter += `contains(tolower(TKey),tolower('${encodeURIComponent(
          el,
        )}')) or `;
      });
      searchFilter = searchFilter.slice(0, -3);
    }
    const resp = yield call(
      api.postPagination,
      `v1/KeyValues`,
      null,
      null,
      `TGroup eq ${KEY_VALUE.CERTIFICATE} and ` + searchFilter,
      null,
    );
 
    const { data, status } = resp;
    if (status == 200) {
      yield put(actions.getCertificateListSuccess(data));
    } else {
      yield put(actions.getCertificateListFailed());
    }
  }
}












export default function* categoryManagementPageSaga() {
  // See example in containers/HomePage/saga.js\

  yield takeLatest(types.GET_PROFESSION, getProfessionList);
  yield takeLatest(types.GET_SKILL, getSkillList);
  yield takeLatest(types.GET_CERTIFICATE, getCertificateList);
}
