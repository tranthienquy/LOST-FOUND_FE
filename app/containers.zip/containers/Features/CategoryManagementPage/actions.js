/*
 *
 * CategoryManagementPage actions
 *
 */

import { DEFAULT_ACTION, END_OF_ACTION ,GET_CERTIFICATE,
  GET_CERTIFICATE_SUCCESS,
  GET_CERTIFICATE_FAILED,
  GET_PROFESSION,
  GET_PROFESSION_FAILED,
  GET_PROFESSION_SUCCESS,
  GET_SKILL,
  GET_SKILL_SUCCESS,
  GET_SKILL_FAILED,} from './constants';

export function defaultAction() {
  return {
    type: DEFAULT_ACTION,
  };
}
export const endOfAction = () => {
  return {
    type: END_OF_ACTION,
  };
};


export const getProfessionList = (content = '') => {
  return {
    type: GET_PROFESSION,
    content,
  };
};
export const getProfessionListSuccess = data => {
  return {
    type: GET_PROFESSION_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getProfessionListFailed = () => {
  return {
    type: GET_PROFESSION_FAILED,
  };
};

export const getCertificateList = (content = '') => {
  return {
    type: GET_CERTIFICATE,
    content,
  };
};
export const getCertificateListSuccess = data => {
  return {
    type: GET_CERTIFICATE_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getCertificateListFailed = () => {
  return {
    type: GET_CERTIFICATE_FAILED,
  };
};

export const getSkillList = (content = '') => {
  return {
    type: GET_SKILL,
    content,
  };
};
export const getSkillListSuccess = data => {
  return {
    type: GET_SKILL_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getSkillListFailed = () => {
  return {
    type: GET_SKILL_FAILED,
  };
};