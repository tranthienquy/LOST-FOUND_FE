/*
 *
 * CategoryManagementPage constants
 *
 */

export const DEFAULT_ACTION = 'app/CategoryManagementPage/DEFAULT_ACTION';
export const END_OF_ACTION = 'app/CategoryManagementPage/END_OF_ACTION';


export const GET_PROFESSION = 'app/CategoryManagementPage/GET_PROFESSION';
export const GET_PROFESSION_SUCCESS = 'app/CategoryManagementPage/GET_PROFESSION_SUCCESS';
export const GET_PROFESSION_FAILED = 'app/CategoryManagementPage/GET_PROFESSION_FAILED';

export const GET_SKILL = 'app/CategoryManagementPage/GET_SKILL';
export const GET_SKILL_SUCCESS = 'app/CategoryManagementPage/GET_SKILL_SUCCESS';
export const GET_SKILL_FAILED = 'app/CategoryManagementPage/GET_SKILL_FAILED';

export const GET_CERTIFICATE = 'app/CategoryManagementPage/GET_CERTIFICATE';
export const GET_CERTIFICATE_SUCCESS = 'app/CategoryManagementPage/GET_CERTIFICATE_SUCCESS';
export const GET_CERTIFICATE_FAILED = 'app/CategoryManagementPage/GET_CERTIFICATE_FAILED';
