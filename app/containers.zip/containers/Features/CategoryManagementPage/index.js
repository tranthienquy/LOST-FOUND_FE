/**
 *
 * CategoryManagementPage
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import makeSelectCategoryManagementPage from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import * as actions from './actions';
import './styles.scss';
import { Card } from 'antd';

class CategoryManagementPage extends React.Component {
  componentWillUnmount() {
    this.props.onEndOfAction();
  }
  componentWillMount(){
    this.props.onGetProfessionList();
  }

 
  render() {
    return (
      <div className='category-management-container'>
        <FormattedMessage {...messages.header} />
        
        <div class="row">
          <div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
            <Card title="Ngành nghề"></Card>
          </div>
          <div class="col-xs-2 col-sm-2 col-md-2 col-lg-2 d-flex justify-content-center align-items-center">
           <i className='icon-Caret-right' style={{fontSize:30}}></i>

          </div>
          <div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
          <Card title="Ngành nghề"></Card>

          </div>
        </div>
        
      </div>
    );
  }
}

CategoryManagementPage.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  categoryManagementPage: makeSelectCategoryManagementPage(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    onEndOfAction: () => {
      dispatch(actions.endOfAction());
    },
    onGetProfessionList: () => {
      dispatch(actions.getProfessionList());
    },
    onGetSkillList: content => {
      dispatch(actions.getSkillList(content));
    },
    onGetCertificateList: content => {
      dispatch(actions.getCertificateList(content));
    },
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

const withReducer = injectReducer({ key: 'categoryManagementPage', reducer });
const withSaga = injectSaga({ key: 'categoryManagementPage', saga });
export default compose(
  withConnect,
  withReducer,
  withSaga,
)(CategoryManagementPage);
