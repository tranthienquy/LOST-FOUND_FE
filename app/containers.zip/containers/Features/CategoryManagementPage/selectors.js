import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the categoryManagementPage state domain
 */

const selectCategoryManagementPageDomain = state =>
  state.categoryManagementPage || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by CategoryManagementPage
 */

const makeSelectCategoryManagementPage = () =>
  createSelector(
    selectCategoryManagementPageDomain,
    substate => substate,
  );

export default makeSelectCategoryManagementPage;
export { selectCategoryManagementPageDomain };
