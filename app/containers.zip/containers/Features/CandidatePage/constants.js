/*
 *
 * CandidatePage constants
 *
 */

export const DEFAULT_ACTION = 'app/CandidatePage/DEFAULT_ACTION';
export const END_OF_ACTION = 'app/CandidatePage/END_OF_ACTION';
export const GET_CONTENT = 'app/CandidatePage/GET_CONTENT';
export const GET_CONTENT_SUCCESS = 'app/CandidatePage/GET_CONTENT_SUCCESS';
export const GET_CONTENT_FAILED = 'app/CandidatePage/GET_CONTENT_FAILED';
export const PAGINATION = 'app/CandidatePage/PAGINATION';

export const GET_COMPANY = 'app/CandidatePage/GET_COMPANY';
export const GET_COMPANY_SUCCESS = 'app/CandidatePage/GET_COMPANY_SUCCESS';
export const GET_COMPANY_FAILED = 'app/CandidatePage/GET_COMPANY_FAILED';

export const GET_KEY_VALUE = 'app/CandidatePage/GET_KEY_VALUE';
export const GET_KEY_VALUE_SUCCESS = 'app/CandidatePage/GET_KEY_VALUE_SUCCESS';
export const GET_KEY_VALUE_FAILED = 'app/CandidatePage/GET_KEY_VALUE_FAILED';

export const GET_LOCATION = 'app/CandidatePage/GET_LOCATION';
export const GET_LOCATION_SUCCESS = 'app/CandidatePage/GET_LOCATION_SUCCESS';
export const GET_LOCATION_FAILED = 'app/CandidatePage/GET_LOCATION_FAILED';

export const GET_PROFESSION = 'app/CandidatePage/GET_PROFESSION';
export const GET_PROFESSION_SUCCESS = 'app/CandidatePage/GET_PROFESSION_SUCCESS';
export const GET_PROFESSION_FAILED = 'app/CandidatePage/GET_PROFESSION_FAILED';

export const GET_SKILL = 'app/CandidatePage/GET_SKILL';
export const GET_SKILL_SUCCESS = 'app/CandidatePage/GET_SKILL_SUCCESS';
export const GET_SKILL_FAILED = 'app/CandidatePage/GET_SKILL_FAILED';

