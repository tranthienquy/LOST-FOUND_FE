import { take, call, put, select, takeLatest, delay, fork, takeEvery } from 'redux-saga/effects';
import * as types from './constants';
import * as actions from './actions';
import * as api from 'utils/api';
import { KEY_VALUE } from '../../../utils/api/constants';

function* getCandidateList({content}) {
  const { current, pageSize } = yield select(state => state.candidatePage);
  console.log(content);
  let filter = '' ;
  if (content){
    let skillFilter='';
    if(content.Skills && content.Skills.length >0) {
      skillFilter += yield "("
      yield content.Skills.forEach(el=>{
        skillFilter += `contains(tolower(Skill),tolower('${encodeURIComponent(el)}')) or `
      })
      skillFilter = yield skillFilter.slice(0, -3);
      skillFilter += yield ") and"
    }
    filter=
    (content.Title ? `contains(tolower(FirstName),tolower('${encodeURIComponent(content.Title)}')) and ` :'')
   + (content.Professions ? `contains(Profession,'${encodeURIComponent(content.Professions)}') and ` :'')
   + (content.Title ? `contains(tolower(FirstName),tolower('${encodeURIComponent(content.Title)}')) and ` :'')
   + (content.partnerID  ? `partnerID  eq ${content.partnerID } and `: '')
   +( content.CompanyID ? `CompanyID eq ${content.CompanyID.value} and `:'')
   + skillFilter;
}
if (filter){
  filter= filter.slice(0, -4);
}
console.log(filter);
  const resp = yield call(
    api.postPagination,
    `v1/UserProfiles`,
    current,
    pageSize,
    filter,
{Account:{$select:'Email'}, Cvs: {$select:'Id, Link, Name'} }
  );
  const { data, status } = resp;
  if (status == 200) {
    yield delay(2000);
    yield put(actions.getCandidateListSuccess(data));
  } else {
    yield put(actions.getCandidateListFailed());
  }
}

function* getCompany({content}){
  if (content){
     yield delay(500);
  const resp = yield call(
    api.postPagination,
    `v1/Companies`,
    1,
    10,
    content ? `contains(tolower(Name),tolower('${encodeURIComponent(content)}'))`: null,
    null
  );
  const { data, status } = resp;
  if (status == 200) {
    yield put(actions.getCompanyListSuccess(data));
  } else {
    yield put(actions.getCompanyListFailed());
  }
  }
 
}


function* getProfessionList({content}){
  if (content){
    yield delay(500);

  const resp = yield call(
    api.postPagination,
    `v1/KeyValues`,
    null,
    null,
    `TGroup eq ${KEY_VALUE.PROFESSION} and contains(tolower(TValue),tolower('${encodeURIComponent(content)}'))`,
    null
  );
  const { data, status } = resp;
  if (status == 200) {
    yield put(actions.getProfessionListSuccess(data));
  } else {
    yield put(actions.getProfessionListFailed());
  }
}
}


function* getSkillList({content}){

  if (content){
    yield delay(500);

  const resp = yield call(
    api.postPagination,
    `v1/KeyValues`,
    null,
    null,
    `TGroup eq ${KEY_VALUE.SKILL} and contains(tolower(TValue),tolower('${encodeURIComponent(content)}'))`,
    null
  );
  const { data, status } = resp;
  if (status == 200) {
    yield put(actions.getSkillListSuccess(data));
  } else {
    yield put(actions.getSkillListFailed());
  }
}
}

function* getLocationList(){
  const resp = yield call(
    api.postPagination,
    `v1/KeyValues`,
    null,
    null,
    `TGroup eq ${KEY_VALUE.LOCATION}`,
    null
  );
  const { data, status } = resp;
  if (status == 200) {
    yield put(actions.getLocationListSuccess(data));
  } else {
    yield put(actions.getLocationListFailed());
  }
}
// Individual exports for testing
export default function* candidatePageSaga() {
  // See example in containers/HomePage/saga.js
  yield takeLatest(types.GET_CONTENT, getCandidateList);
  yield takeLatest(types.GET_COMPANY, getCompany);
  yield takeLatest(types.GET_LOCATION, getLocationList)
  yield takeLatest(types.GET_PROFESSION, getProfessionList)
  yield takeLatest(types.GET_SKILL, getSkillList)

}
