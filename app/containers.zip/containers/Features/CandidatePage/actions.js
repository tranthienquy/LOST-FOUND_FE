/*
 *
 * CandidatePage actions
 *
 */

import {
  DEFAULT_ACTION,
  END_OF_ACTION,
  GET_CONTENT,
  GET_CONTENT_FAILED,
  GET_CONTENT_SUCCESS,
  PAGINATION,
  GET_COMPANY,
  GET_COMPANY_FAILED,
  GET_COMPANY_SUCCESS,
  GET_KEY_VALUE,
  GET_KEY_VALUE_SUCCESS,
  GET_KEY_VALUE_FAILED,
  GET_LOCATION,
  GET_LOCATION_FAILED,
  GET_LOCATION_SUCCESS,
  GET_PROFESSION,
  GET_PROFESSION_FAILED,
  GET_PROFESSION_SUCCESS,
  GET_SKILL,
  GET_SKILL_SUCCESS,
  GET_SKILL_FAILED

} from './constants';

export function defaultAction() {
  return {
    type: DEFAULT_ACTION,
  };
}
export const endOfAction = () => {
  return {
    type: END_OF_ACTION,
  };
};
export const getCandidateList = (content = null) => {
  return {
    type: GET_CONTENT,
    content,
  };
};
export const getCandidateListSuccess = data => {
  return {
    type: GET_CONTENT_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getCandidateListFailed = () => {
  return {
    type: GET_CONTENT_FAILED,
  };
};
export const pagination = (current, pageSize) => {
  return {
    type: PAGINATION,
    current,
    pageSize,
  };
};

export const getCompanyList = (content = '') => {
  return {
    type: GET_COMPANY,
    content,
  };
};
export const getCompanyListSuccess = data => {
  return {
    type: GET_COMPANY_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getCompanyListFailed = () => {
  return {
    type: GET_COMPANY_FAILED,
  };
};

export const getKeyValueList = (name) => {
  return {
    type: GET_KEY_VALUE,
    name,
  };
};
export const getKeyValueListSuccess = (name,data) => {
  return {
    type: GET_KEY_VALUE_SUCCESS,
    payload: {
      name,data,
    },
  };
};
export const getKeyValueListFailed = () => {
  return {
    type: GET_KEY_VALUE_FAILED,
  };
};

export const getLocationList = () => {
  return {
    type: GET_LOCATION,
  };
};
export const getLocationListSuccess = data => {
  return {
    type: GET_LOCATION_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getLocationListFailed = () => {
  return {
    type: GET_LOCATION_FAILED,
  };
};


export const getProfessionList = (content = '') => {
  return {
    type: GET_PROFESSION,
    content,
  };
};
export const getProfessionListSuccess = data => {
  return {
    type: GET_PROFESSION_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getProfessionListFailed = () => {
  return {
    type: GET_PROFESSION_FAILED,
  };
};

export const getSkillList = (content = '') => {
  return {
    type: GET_SKILL,
    content,
  };
};
export const getSkillListSuccess = data => {
  return {
    type: GET_SKILL_SUCCESS,
    payload: {
      data,
    },
  };
};
export const getSkillListFailed = () => {
  return {
    type: GET_SKILL_FAILED,
  };
};