/**
 *
 * CandidatePage
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import makeSelectCandidatePage from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import './styles.scss';
import * as actions from './actions';
import { Form, Input, Button, Select, Typography, Pagination } from 'antd';
import { Helmet } from 'react-helmet';
import CandidateListComponent from '../../../components/CandidateListComponent';
import * as api from 'utils/api';
import { KEY_VALUE } from '../../../utils/api/constants';
import { USER_ROLE } from '../../../utils/constants';
import AuthContext from '../../../utils/auth';
import { getValidRole } from '../../../utils/permissionUtil';
import { Link } from 'react-router-dom';

class CandidatePage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      valueSearch: null,
      skillSuggestList: [],
      skillSearch:'',
      professionSuggestList: [],
      professionSearch:''
    };
  }
  formRef = React.createRef();

  onSubmitSearch = value => {
    this.setState({ valueSearch: value });
    this.props.onPagination(1, this.props.candidatePage.pageSize);
    this.props.onGetCandidateList({partnerID : this.context.user.Id,...value});
  };
  componentWillMount() {
    api.postPagination( `v1/KeyValues`, 1, 4, `TGroup eq ${KEY_VALUE.SKILL} `, null ).then(res=>{
      this.setState ({skillSuggestList: res.data.value})
    })
    api.postPagination( `v1/KeyValues`, 1, 4, `TGroup eq ${KEY_VALUE.PROFESSION} `, null ).then(res=>{
      this.setState ({professionSuggestList: res.data.value})
    })
    this.props.onGetCandidateList({partnerID : this.context.user.Id});
    this.props.onGetLocationList();

  }

  onChangePagination = (page, pageSize) => {
    this.props.onPagination(page, pageSize);
    this.props.onGetCandidateList({...this.state.valueSearch, partnerID : this.context.user.Id});
  };
  onChangePageSize = value => {
    this.onChangePagination(this.props.candidatePage.current, value);
  };

  componentWillUnmount() {
    this.props.onEndOfAction();
  }

  searchCompany = value => {
    console.log(value);
    this.props.onGetCompanyList(value);
  };
  searchProfession = value => {
    this.setState({professionSearch:value})
    this.props.onGetProfessionList(value);
  };
  searchSkill = value => {
    this.setState({skillSearch:value})
    this.props.onGetSkillList(value);
  };
  onFillSuggestSkill = value =>{
    this.formRef.current.setFieldsValue({
      Skills: [value.TKey]
    })
  }
  onFillSuggestProfession = value =>{
    this.formRef.current.setFieldsValue({
      Professions: value.TKey
    })
  }

  render() {
    const {
      candidateList,
      loading,
      current,
      pageSize,
      total,
      companyList,
      companyLoading,
      locationList,
      skillList,
      professionLoading,
      professionList,
      skillLoading,
    } = this.props.candidatePage;
    const {skillSuggestList, skillSearch, professionSearch, professionSuggestList} = this.state;
    
    return (
      <div className="job-container">
        <Helmet>
          <title>Ứng viên</title>
        </Helmet>
        <Form name="basic" onFinish={this.onSubmitSearch} autoComplete="off"   ref={this.formRef} >
          <div className="row">
            <div className="col-xs-12 col-sm-12 col-md-6 col-lg-4 pl-4 pr-4 mt-2">
              <div className="ant-form-item-control-input-content select-input">
                <span className="ant-input-affix-wrapper d-flex align-items-center">
                  <span className="ant-input-prefix">
                    <i className="icon-Box-outline h5 feature-icon" />
                  </span>
                  <Form.Item name="Professions">
                    <Select
                      className="w-100"
                      placeholder="Ngành nghề"
                      bordered={false}
                      suffixIcon={''}
                      showSearch
                      onSearch={this.searchProfession}
                      filterOption={false}
                      loading={professionLoading}
                      allowClear={true}
                      notFoundContent={''}
                   
                    >
                       {professionList &&
                        professionList.map(item => (
                          <Select.Option
                            value={item.TKey}
                            key={`options-profession-${item.Id}`}
                          >
                           
                            {item.TValue}
                          </Select.Option>
                        ))}
                         {professionList.length==0 && !professionLoading && !professionSearch && professionSuggestList &&
                       <>
                        <Select.Option disabled><i className='text-app-primary'>Gợi ý dành cho bạn</i></Select.Option>
                     {  professionSuggestList.map(item => (
                          <Select.Option
                            value={item.TKey}
                            key={`options-company-${item.TKey}`}
                          >
                          
                            {item.TValue}
                          </Select.Option>
                        ))}
                        </>
                        }
                      {professionLoading && (
                        <Select.Option disabled>Đang tải...</Select.Option>
                      )}
                    </Select>
                  </Form.Item>

                </span>
                {professionSuggestList && professionSuggestList.map(el => 
                       <span onClick={()=>this.onFillSuggestProfession(el)} className="link-text-on-click small-size-hint mr-2 ">
                       {el.TValue}
                     </span>
                      )}
              </div>
            </div>

         
            <div className="col-xs-12 col-sm-12 col-md-6 col-lg-4 pl-4 pr-4 mt-2">
              <div className="ant-form-item-control-input-content select-input">
                <span className="ant-input-affix-wrapper d-flex align-items-center search-field">
                  <span className="ant-input-prefix">
                    <i className="icon-Settings-outline h5 feature-icon" />
                  </span>
                  <Form.Item name="Skills">
                    <Select
                      className="w-100"
                      placeholder="Kỹ năng"
                      bordered={false}
                      suffixIcon={''}
                      showSearch
                      onSearch={this.searchSkill}
                      filterOption={false}
                      loading={skillLoading}
                      allowClear={true}
                      notFoundContent={''}
                      mode="multiple"
                    >
                      {skillList &&
                        skillList.map(item => (
                          <Select.Option
                            value={item.TKey}
                            key={`options-company-${item.TKey}`}
                          >
                          
                            {item.TValue}
                          </Select.Option>
                        ))}
                      {skillList.length==0 && !skillLoading && !skillSearch && skillSuggestList &&
                       <>
                        <Select.Option disabled><i className='text-app-primary'>Gợi ý dành cho bạn</i></Select.Option>
                     {  skillSuggestList.map(item => (
                          <Select.Option
                            value={item.TKey}
                            key={`options-company-${item.TKey}`}
                          >
                          
                            {item.TValue}
                          </Select.Option>
                        ))}
                        </>
                        }
                      {skillLoading && (
                        <Select.Option disabled>Đang tải...</Select.Option>
                      )}
                    </Select>
                  </Form.Item>

                </span>
                {skillSuggestList && skillSuggestList.map(el => 
                       <span onClick={()=>this.onFillSuggestSkill(el)} className="link-text-on-click small-size-hint mr-2 ">
                       {el.TValue}
                     </span>
                      )}
              </div>
            </div>
            <div className="col-xs-12 col-sm-12 col-md-6 col-lg-4 pl-4 pr-4 mt-2">
              <div className="ant-form-item-control-input-content select-input">
                <span className="ant-input-affix-wrapper d-flex align-items-center search-field">
                  <span className="ant-input-prefix">
                    <i className="icon-Cursor-outline h5 feature-icon" />
                  </span>
                  <Form.Item name="Location">
                    <Select
                      className="w-100"
                      placeholder="Địa điểm"
                      bordered={false}
                      suffixIcon={<i className="icon-Caret-down h3" />}
                      allowClear={true}
                      filterOption={(input, option) =>
                        option.children
                          .toLowerCase()
                          .includes(input.toLowerCase())
                      }
                      showSearch
                      mode="multiple"
                      maxTagCount='responsive'
                    >
                      {locationList.map(item => (
                        <Select.Option key={`options-location-${item.TKey}`} value={item.Id}>
                          {item.TValue}
                        </Select.Option>
                      ))}
                
                    </Select>
                  </Form.Item>
                </span>
              </div>
            </div>
            <div className="col-xs-12 col-sm-12 col-md-6 col-lg-4 pl-4 pr-4 mt-2">
              <div className="ant-form-item-control-input-content select-input">
                <span className="ant-input-affix-wrapper d-flex align-items-center search-field">
                  <span className="ant-input-prefix">
                    <i className="icon-Sort-outline h5 feature-icon" />
                  </span>
                  <Form.Item name="Sort">
                    <Select
                      className="w-100"
                      placeholder="Sắp xếp theo"
                      bordered={false}
                      suffixIcon={<i className="icon-Caret-down h3" />}
                      allowClear={true}
                     
                    >
                      
                      <Select.Option  value={'item.Id'}>
                          Liên quan
                        </Select.Option>
                      <Select.Option  value={'item.Id'}>
                         Số năm kinh nghiệm (nhiều)
                        </Select.Option>
                      <Select.Option  value={'item.Id'}>
                         Mức lương kì vọng
                        </Select.Option>
                      <Select.Option  value={'item.Id'}>
                       Lần cập nhật cuối
                        </Select.Option>
                          
                
                    </Select>
                  </Form.Item>
                </span>
              </div>
            </div>
          

            <div className="col-xs-12 col-sm-12 col-md-6 col-lg-4 pl-4 pr-4 mt-2">
              <Form.Item name="Title" initialValue={''}>
                <Input
                  placeholder="Tên ứng viên"
                  prefix={
                    <i className="icon-User-outline h5 feature-icon" />
                  }
                />
              </Form.Item>
            </div>
            <div className="col-xs-12 col-sm-12 col-md-6 col-lg-4 pl-4 pr-4 mt-2">
              <Form.Item>
                <Button
                  type="primary"
                  htmlType="submit"
                  className="w-100 button-submit"
                >
                  <span className="w-100 text-center d-flex justify-content-center">
                    {' '}
                    <i className="icon-Search mr-1" /> TÌM KIẾM
                  </span>
                </Button>
              </Form.Item>
            </div>
          </div>
        </Form>
        <div />
        <div className='d-flex justify-content-end mr-2 mt-1'>{getValidRole(this.context.user, [USER_ROLE.PARTNER]) && 
        <Link to={'/candidate/add'}>
        <Button
        
        >+ Tạo mới ứng viên</Button></Link>}</div>
        <CandidateListComponent loading={loading} value={candidateList} />
        <div className="pagination-foot w-100 mt-5 d-flex flex-row flex-wrap justify-content-between">
          <div className="d-flex flex-row align-items-center mb-2">
            <Typography className="mr-1">Kết quả mỗi trang</Typography>
            <Select
              className="select-number-page"
              value={pageSize}
              onChange={this.onChangePageSize}
              suffixIcon={
                <i className="icon-Caret-down h3 text-app-primary pr-3" />
              }
            >
              <Option value="10">10</Option>
              <Option value="20">20</Option>
              <Option value="30">30</Option>
              <Option value="50">50</Option>
              <Option value="100">100</Option>
            </Select>
          </div>

          <Pagination
            current={current}
            total={total}
            pageSize={pageSize}
            onChange={this.onChangePagination}
            showTotal={(total, range) =>
              `Hiển thị ${range[0]}-${range[1]} của ${total}`
            }
          />
        </div>
      </div>
    );
  }
}

CandidatePage.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  candidatePage: makeSelectCandidatePage(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    onEndOfAction: () => {
      dispatch(actions.endOfAction());
    },
    onGetCandidateList: content => {
      dispatch(actions.getCandidateList(content));
    },
    onGetCompanyList: content => {
      dispatch(actions.getCompanyList(content));
    },
    onGetKeyValueList: name => {
      dispatch(actions.getKeyValueList(name));
    },
    onPagination: (current, pageSize) => {
      dispatch(actions.pagination(current, pageSize));
    },
    onGetLocationList: () => {
      dispatch(actions.getLocationList());
    },
    onGetProfessionList: content => {
      dispatch(actions.getProfessionList(content));
    },
    onGetSkillList: content => {
      dispatch(actions.getSkillList(content));
    },
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

const withReducer = injectReducer({ key: 'candidatePage', reducer });
const withSaga = injectSaga({ key: 'candidatePage', saga });
CandidatePage.contextType = AuthContext;
export default compose(
  withConnect,
  withReducer,
  withSaga,
)(CandidatePage);
