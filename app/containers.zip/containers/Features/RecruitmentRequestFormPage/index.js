/**
 *
 * RecruitmentRequestFormPage
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import makeSelectRecruitmentRequestFormPage from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import * as actions from './actions';
import './styles.scss';
import { Link } from 'react-router-dom';
import {
  Button,
  Card,
  Typography,
  Tag,
  Modal,
  Form,
  Input,
  Select,
  Skeleton,
  DatePicker,
  Upload,
} from 'antd';

import {
  Paper,
  TableContainer,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  LinearProgress,
} from '@mui/material';
class RecruitmentRequestFormPage extends React.Component {
  componentWillUnmount() {
    this.props.onEndOfAction();
  }
  formRef = React.createRef();
  componentWillMount() {
    this.props.onGetProfessionList();
    this.props.onGetLocationList();


  }

  searchProfession = value => {
    // this.props.onGetProfessionList(value);
  };
  searchSkill = value => {
    this.props.onGetSkillList(value);
  };


  onSubmit = value => {
    this.props.onSubmitContent(value.requests);
  };
  onSubmitFailed = errorInfo => {};
  duplicateFields = ()=>{
    const {requests}= this.formRef.current.getFieldsValue();
    if (requests.length>0){
        this.formRef.current.setFieldsValue({
      requests:[...requests, requests[requests.length-1]]
    })
    }
  
  }
  render() {
    const {professionList, skillList, loading, locationList}= this.props.recruitmentRequestFormPage;
    return (
      <div className="recruitment-request-form-container d-flex flex-column pt-5">
        <Form
          name="basic"
          onFinish={this.onSubmit}
          autoComplete="off"
          layout="vertical"
          initialValues={{}}
          onFinishFailed={this.onSubmitFailed}
          className="ant-general-form"
          ref={this.formRef}
        >
          <div className="d-flex justify-content-between ">
            <Typography className="text-app-primary h4 font-weight-bold">
              TẠO MỚI YÊU CẦU TUYỂN DỤNG
            </Typography>
          </div>

          {/* <Form.List name="users"> */}

          <TableContainer component={Paper}  style={{ width: '100%' }} >
            <Table  aria-label="simple table" style={{minWidth:'1800px'}}  stickyHeader>
              <TableHead>
                <TableRow>
                  <TableCell  width={300}>Tên công việc</TableCell>
                  <TableCell  width={300}>Tag</TableCell>
                  <TableCell  width={400}>Thành phố</TableCell>
                  <TableCell  width={400}>Địa điểm</TableCell>
                  <TableCell  width={300}>Ngành nghề</TableCell>
                  <TableCell width={300}>Kỹ năng</TableCell>
                  <TableCell  width={300}>Số năm kinh nghiệm</TableCell>
                  <TableCell  width={300}>Số lượng</TableCell>
                  <TableCell width={250}>Ngày hết hạn</TableCell>
                  <TableCell  width={700}>Tài liệu tham khảo</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                <Form.List name="requests">
                  {(fields, { add, remove }) => (
                    <>
                      {fields.map(({ key, name, ...restField }) => (
                        <TableRow
                        key={`form-array-${key}`}
                        sx={{
                            '&:last-child td, &:last-child th': { border: 0 },
                          }}
                        >
                         
                          <TableCell>
                            <Form.Item
                              {...restField}
                              name={[name, 'Title']}
                              rules={[
                                {
                                  required: true,
                                  message: 'Vui lòng nhập Tên công việc',
                                },
                              ]}
                            >
                              <Input placeholder='Tên công việc' />
                            </Form.Item>
                          </TableCell>
                          <TableCell>
                            <Form.Item
                              {...restField}
                              name={[name, 'Tag']}
                             
                            >
                              <Input  placeholder='Tag' />
                            </Form.Item>
                          </TableCell>
                          <TableCell>
                            <Form.Item
                              {...restField}
                              name={[name, 'City']}
                              rules={[
                                {
                                  required: true,
                                  message: 'Vui lòng nhập Thành phố',
                                },
                              ]}
                            >
                               <Select
                      className="w-100"
                      placeholder="Thành phố"
                      suffixIcon={<i className="icon-Caret-down h3" />}
                      allowClear={true}
                      filterOption={(input, option) =>
                        option.children
                          .toLowerCase()
                          .includes(input.toLowerCase())
                      }
                      showSearch
                      mode="multiple"
                      maxTagCount='responsive'
                    >
                      {locationList.map(item => (
                        <Select.Option key={`options-location-${item.TKey}`} value={item.TKey}>
                          {item.TValue}
                        </Select.Option>
                      ))}
                
                    </Select>
                            </Form.Item>
                          </TableCell>
                          <TableCell>
                            <Form.Item
                              {...restField}
                              name={[name, 'Location']}
                              rules={[
                                {
                                  required: true,
                                  message: 'Vui lòng nhập Địa điểm',
                                },
                              ]}
                            >
                              <Input placeholder='Địa điểm'  />
                            </Form.Item>
                          </TableCell>
                          <TableCell>
                          <Form.Item name={[name, 'Profession']}  rules={[
                                {
                                  required: true,
                                  message: 'Vui lòng nhập Ngành nghề',
                                },
                              ]}>
              <Select
                className="w-100"
                placeholder="Ngành nghề"
                suffixIcon={<i className="icon-Caret-down h3" /> }
                showSearch
                onSearch={this.searchProfession}
                filterOption={(input, option) =>
                  option.children
                    .toLowerCase()
                    .includes(input.toLowerCase())
                }
                loading={
                 loading
                    .professionList
                }
                allowClear={true}
                notFoundContent={''}
              >
              
                {professionList &&
                 professionList.map(
                    item => (
                      <Select.Option
                        value={item.TKey}
                        key={`options-profession-${item.Id}`}
                      >
                        {item.TValue}
                      </Select.Option>
                    ),
                  )}
                    {loading.professionList && (
                <Select.Option disabled>Đang tải...</Select.Option>
              )}
              </Select>
            </Form.Item>
                            </TableCell>
                          <TableCell>
                            <Form.Item
                              {...restField}
                              name={[name, 'ListSkill']}
                              rules={[
                                {
                                  required: true,
                                  message: 'Vui lòng nhập Kỹ năng',
                                },
                              ]}
                            >
                              <Select
                 mode="multiple"
               onSearch={this.searchSkill}
               notFoundContent={''}
               filterOption={false}
               maxTagCount='responsive'
                                placeholder="Kỹ năng"
                 suffixIcon={<i className="icon-Caret-down h3" />}
               >
                 {skillList &&
                 skillList.map(item => (
                   <Select.Option
                     value={item.TKey}
                     key={`options-skill-${item.TKey}`}
                   >
                   
                     {item.TValue}
                   </Select.Option>
                 ))}
               {loading.skillList && (
                 <Select.Option disabled>Đang tải...</Select.Option>
               )}
               </Select>
                            </Form.Item>
                          </TableCell>
                          <TableCell>
                            <Form.Item
                              {...restField}
                              name={[name, 'WorkExperience']}
                             
                            >
                              <Input type="number" min={1} placeholder="Số năm kinh nghiệm"  />
                            </Form.Item>
                          </TableCell>
                          <TableCell>
                            <Form.Item
                              {...restField}
                              name={[name, 'Quantity']}
                              rules={[
                                {
                                  required: true,
                                  message: 'Vui lòng nhập Số lượng',
                                },
                              ]}
                            >
                              <Input  type="number"  min={1} placeholder="Số lượng"/>
                            </Form.Item>
                          </TableCell>
                        
                          <TableCell>    <Form.Item   name={[name, 'DueDate']}
                            rules={[
                              {
                                required: true,
                                message: 'Vui lòng chọn ngày hết hạn',
                              },
                            ]}>
                          <DatePicker  placeholder='Chọn'/>
          </Form.Item></TableCell>
                          <TableCell>    <Form.Item   name={[name, 'UploadFile']} >
                          <Upload
                             customRequest={({ file, onSuccess }) => {
                              setTimeout(() => {
                                onSuccess('ok');
                              }, 0);
                            }}
                          >  <Button>+ Tải tệp</Button></Upload>
          </Form.Item></TableCell>
                        </TableRow>
                      ))}
                        <TableRow>
                        <TableCell colSpan={2} > 
                      <Form.Item >
                        <div className="d-flex flex-row">
                        <Button type="dashed" className='mr-2' onClick={() => add()} block>
                          + Thêm dòng
                        </Button>
                        <Button type="dashed" onClick={this.duplicateFields} block>
                         Sao chép từ dòng liền trước
                        </Button></div>
                      </Form.Item></TableCell></TableRow>
                    </>
                  )}
                </Form.List>
              </TableBody>
            </Table>
          </TableContainer>
          <Form.Item className="mb-0">
            <Button
              size="large"
              type="primary"
              htmlType="submit"
              className="text-center w-100 mt-3"
            >
              <b className="w-100 text-center">+ TẠO MỚI</b>
            </Button>
          </Form.Item>
          <div style={{height:'10px'}}>
      {loading.submit ?  <LinearProgress color='success' />:""}
          </div>
        </Form>
      </div>
    );
  }
}

RecruitmentRequestFormPage.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  recruitmentRequestFormPage: makeSelectRecruitmentRequestFormPage(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    onEndOfAction: () => {
      dispatch(actions.endOfAction());
    },
    onGetProfessionList: content => {
      dispatch(actions.getProfessionList(content));
    },
    onGetSkillList: content => {
      dispatch(actions.getSkillList(content));
    },
    onSubmitContent: content => {
      dispatch(actions.submitContent(content));
    },
    onGetLocationList: () => {
      dispatch(actions.getLocationList());
    },
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

const withReducer = injectReducer({
  key: 'recruitmentRequestFormPage',
  reducer,
});
const withSaga = injectSaga({ key: 'recruitmentRequestFormPage', saga });
export default compose(
  withConnect,
  withReducer,
  withSaga,
)(RecruitmentRequestFormPage);
