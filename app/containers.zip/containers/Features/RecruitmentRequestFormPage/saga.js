import { take, call, put, select, takeLatest, delay, fork, takeEvery, all } from 'redux-saga/effects';
import * as types from './constants';
import * as actions from './actions';
import * as api from 'utils/api';
import { KEY_VALUE } from '../../../utils/api/constants';
import moment from 'moment';
import { notification } from 'antd';
import { push, goBack } from 'react-router-redux';

// Individual exports for testing

function* getProfessionList(){
  yield delay(500);

  const resp = yield call(
    api.postPagination,
    `v1/KeyValues`,
    null,
    null,
    `TGroup eq ${
      KEY_VALUE.PROFESSION
    }`,
    null,
  );
  const { data, status } = resp;
  if (status == 200) {
    yield put(actions.getProfessionListSuccess(data));
  } else {
    yield put(actions.getProfessionListFailed());
  }
}


function* getSkillList({content}){

  if (content){
    yield delay(500);

  const resp = yield call(
    api.postPagination,
    `v1/KeyValues`,
    null,
    null,
    `TGroup eq ${KEY_VALUE.SKILL} and contains(tolower(TValue),tolower('${encodeURIComponent(content)}'))`,
    null
  );
  const { data, status } = resp;
  if (status == 200) {
    yield put(actions.getSkillListSuccess(data));
  } else {
    yield put(actions.getSkillListFailed());
  }
}
}
function* submitContent({value}){
  const {content} = yield select(state => state.recruitmentRequestFormPage);
  console.log(value);
  const requestData=yield value.map(item=>({
    ...item,
    DueDate: moment(item.DueDate).toDate(),
    City:JSON.stringify(item.City),

  }))
  yield all (requestData.map(item=>call( submitEachElement,item)));
      yield notification.open({
      message:"Tạo mới yêu cầu tuyển dụng thành công",
      type:'success'
    })
    yield put(goBack());

  // yield console.log(requestData);
  // const resp = yield call(
  //   api.post,
  //   `v1/Requests`, {}, requestData
  // );
  // const { data, status } = resp;

  // if (status == 200 ) {
  //   yield delay(2000);
  //   yield put(actions.submitContentSuccess(data));
  //   yield notification.open({
  //     // message:"Cập nhật hồ sơ công ty thành công"
  //   })
  //   // yield put(push('/'));
  // } else {
  //   yield put(actions.submitContentFailed('password-failed'));
  // }
}

function* submitEachElement(item){
  yield console.log(item);
  const resp = yield call(
    api.post,
    `v1/Requests`, {}, item
  );
  const { data, status } = resp;
  console.log(resp);
    if (status == 201 ) {
      if (item.UploadFile)
      yield  uploadFiles(data.Id, item.UploadFile.fileList);
    }
}

function* uploadFiles(id, fileList) {

  let dataFile = yield new FormData();
  let listNewFiles = yield [];
  yield fileList.forEach(element => {
    if (element.originFileObj) {
      listNewFiles.push(element.originFileObj);
      dataFile.append('files', element.originFileObj);
    }
  });
  if (listNewFiles.length > 0) {
    const resp = yield call(
      api.put,
      `v1/Requests(${id})/upload-multi-file`,
      {},
      dataFile,
      { 'Content-Type': 'multipart/form-data' },
    );
    const { data, status } = resp;

    if (status == 200) {
    } else {
      yield put(actions.submitContentFailed());
    }
  }
}
function* getLocationList(){
  const resp = yield call(
    api.postPagination,
    `v1/KeyValues`,
    null,
    null,
    `TGroup eq ${KEY_VALUE.LOCATION}`,
    null
  );
  const { data, status } = resp;
  if (status == 200) {
    yield put(actions.getLocationListSuccess(data));
  } else {
    yield put(actions.getLocationListFailed());
  }
}
export default function* recruitmentRequestFormPageSaga() {
  // See example in containers/HomePage/saga.js
  yield takeLatest(types.GET_PROFESSION, getProfessionList)
  yield takeLatest(types.GET_SKILL, getSkillList)
  yield takeLatest(types.SUBMIT_CONTENT, submitContent);
  yield takeLatest(types.GET_LOCATION, getLocationList)


}
