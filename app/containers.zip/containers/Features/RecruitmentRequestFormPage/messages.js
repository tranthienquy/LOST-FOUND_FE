/*
 * RecruitmentRequestFormPage Messages
 *
 * This contains all the text for the RecruitmentRequestFormPage container.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.containers.RecruitmentRequestFormPage';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'This is the RecruitmentRequestFormPage container!',
  },
});
