/*
 *
 * RecruitmentRequestFormPage constants
 *
 */

export const DEFAULT_ACTION = 'app/RecruitmentRequestFormPage/DEFAULT_ACTION';
export const END_OF_ACTION = 'app/RecruitmentRequestFormPage/END_OF_ACTION';

export const GET_PROFESSION = 'app/RecruitmentRequestFormPage/GET_PROFESSION';
export const GET_PROFESSION_SUCCESS = 'app/RecruitmentRequestFormPage/GET_PROFESSION_SUCCESS';
export const GET_PROFESSION_FAILED = 'app/RecruitmentRequestFormPage/GET_PROFESSION_FAILED';

export const GET_SKILL = 'app/RecruitmentRequestFormPage/GET_SKILL';
export const GET_SKILL_SUCCESS = 'app/RecruitmentRequestFormPage/GET_SKILL_SUCCESS';
export const GET_SKILL_FAILED = 'app/RecruitmentRequestFormPage/GET_SKILL_FAILED';

export const SUBMIT_CONTENT = 'app/RecruitmentRequestFormPage/SUBMIT_CONTENT';
export const SUBMIT_CONTENT_SUCCESS = 'app/RecruitmentRequestFormPage/SUBMIT_CONTENT_SUCCESS';
export const SUBMIT_CONTENT_FAILED = 'app/RecruitmentRequestFormPage/SUBMIT_CONTENT_FAILED';


export const GET_LOCATION = 'app/RecruitmentRequestFormPage/GET_LOCATION';
export const GET_LOCATION_SUCCESS = 'app/RecruitmentRequestFormPage/GET_LOCATION_SUCCESS';
export const GET_LOCATION_FAILED = 'app/RecruitmentRequestFormPage/GET_LOCATION_FAILED';