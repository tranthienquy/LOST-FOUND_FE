import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the recruitmentRequestFormPage state domain
 */

const selectRecruitmentRequestFormPageDomain = state =>
  state.recruitmentRequestFormPage || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by RecruitmentRequestFormPage
 */

const makeSelectRecruitmentRequestFormPage = () =>
  createSelector(
    selectRecruitmentRequestFormPageDomain,
    substate => substate,
  );

export default makeSelectRecruitmentRequestFormPage;
export { selectRecruitmentRequestFormPageDomain };
