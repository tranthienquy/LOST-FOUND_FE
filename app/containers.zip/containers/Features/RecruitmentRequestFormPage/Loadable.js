/**
 *
 * Asynchronously loads the component for RecruitmentRequestFormPage
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
