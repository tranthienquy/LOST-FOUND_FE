/*
 *
 * CandidateDetailPage constants
 *
 */

export const DEFAULT_ACTION = 'app/CandidateDetailPage/DEFAULT_ACTION';
export const END_OF_ACTION = 'app/CandidateDetailPage/END_OF_ACTION';
