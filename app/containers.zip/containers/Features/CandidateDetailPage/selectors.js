import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the candidateDetailPage state domain
 */

const selectCandidateDetailPageDomain = state =>
  state.candidateDetailPage || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by CandidateDetailPage
 */

const makeSelectCandidateDetailPage = () =>
  createSelector(
    selectCandidateDetailPageDomain,
    substate => substate,
  );

export default makeSelectCandidateDetailPage;
export { selectCandidateDetailPageDomain };
