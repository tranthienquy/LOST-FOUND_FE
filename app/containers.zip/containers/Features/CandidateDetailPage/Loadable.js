/**
 *
 * Asynchronously loads the component for CandidateDetailPage
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
