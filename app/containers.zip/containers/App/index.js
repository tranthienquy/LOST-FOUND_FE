/**
 *
 * App.js
 *
 * This component is the skeleton around the actual pages, and should only
 * contain code that should be seen on all pages. (e.g. navigation bar)
 *
 */

import React from 'react';
import { Switch, Route, withRouter, BrowserRouter } from 'react-router-dom';
import AuthContext from '../../utils/auth';
import MainLayout from '../../components/MainLayout';
import RouteList from './routes';

import HomePage from 'containers/HomePage/Loadable';
import NotFoundPage from 'containers/NotFoundPage/Loadable';
import { Helmet } from 'react-helmet';
import GlobalStyle from '../../global-styles';
import ScrollToTop from './ScrollToTop';
import './styles.scss';
import * as api from 'utils/api';

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      contextValue: null,
      loading: true,
      prefixLink: '',
      setContext: value => {
        this.setState({ contextValue: value });
      },
    };
  }
  componentWillMount() {
    api.get('v1/FileStorages/get-prefix-link').then(res => {
      if (res.status == 200) {
        this.setState({ prefixLink: res.data });
      }
    });
    if (document.cookie && document.cookie !== 'null') {
      api.get('v1/UserProfiles/get-current-profile').then(res => {
        this.setState({ loading: false });
        if (res.status == 200) {
          this.setState({ contextValue: { ...res.data } });
        }
      });
    } else this.setState({ loading: false });
  }

  render() {
    return (
      <div>
        <AuthContext.Provider
          value={{ loading: this.state.loading, user: this.state.contextValue, prefixLink:this.state.prefixLink }}
        >
          <Helmet titleTemplate="%s | Shinyama" defaultTitle="Shinyama" />
          <ScrollToTop />
          <MainLayout>
            <RouteList className="route-main" />
          </MainLayout>
          <GlobalStyle />
        </AuthContext.Provider>
      </div>
    );
  }
}
export default withRouter(App);
