/**
 *
 * JobListComponent
 *
 */

import React from 'react';
// import PropTypes from 'prop-types';
// import styled from 'styled-components';

import { FormattedMessage } from 'react-intl';
import messages from './messages';
import './styles.scss';
import { Typography, Card, Tag, Skeleton, Empty, Button } from 'antd';
import { Link } from 'react-router-dom';
import moment from 'moment';
import _ from 'lodash';
import * as api from 'utils/api';
import { KEY_VALUE } from '../../utils/api/constants';
import AuthContext from '../../utils/auth';
import { getValidRole } from '../../utils/permissionUtil';
import { USER_ROLE } from '../../utils/constants';

class JobListComponent extends React.Component {
constructor(props){
  super(props);
  this.state= {
    skillList: [],
    cityList: [],
  }
}
  componentWillReceiveProps(nextProps){
    if (nextProps.value !== this.props.value) {
      console.log("aa");
      if(nextProps.value && nextProps.value.length>0){
        let skillArray = [];
        let cityArray = [];
        nextProps.value.forEach(element => {
          skillArray= skillArray.concat(JSON.parse(element.Skills))
          cityArray.push(element.City)
        });
        let searchFilter = '';
        let searchCityFilter = '';
        _.uniq(skillArray).forEach(el => {
          searchFilter += `contains(tolower(TKey),tolower('${encodeURIComponent(
            el,
          )}')) or `;
        });
        _.uniq(cityArray).forEach(el => {
          searchCityFilter += `contains(tolower(TKey),tolower('${encodeURIComponent(
            el,
          )}')) or `;
        });
        searchFilter = searchFilter.slice(0, -3);
        searchCityFilter = searchCityFilter.slice(0, -3);
        api.postPagination( `v1/KeyValues`, null, null, `TGroup eq ${KEY_VALUE.SKILL} and `+ searchFilter, null ).then(res=>{
          this.setState ({skillList: res.data.value})
        })
        api.postPagination( `v1/KeyValues`, null, null, `TGroup eq ${KEY_VALUE.LOCATION} and `+ searchCityFilter, null ).then(res=>{
          this.setState ({cityList: res.data.value})
        })
      }
    }
  }

  getJobList =(items)=>{
    if (!items) return '';
    const {skillList, cityList} = this.state;
    if (items.length==0 ) return<div style={{height:'35vh'}} className='w-100 d-flex align-items-center justify-content-center'><Empty description="Không có dữ liệu"/></div> 
    return  items.map(item=>(
       <div key={`job-${item.Id}`} className="col-xs-12 col-sm-12 col-md-12 col-lg-6 mt-2">
       <Card hoverable className='job-card'>
         <div className='d-flex flex-row '>
           <div style={{width:'150px', height: '100px'}}>
           <img src={item.Company.Avatar ? (item.Company.Avatar.startsWith('http')? item.Company.Avatar: `${this.context.prefixLink}/${item.Company.Avatar}`): require('../../images/logo/logo-shinyama-grayscale.png') } width={"100%"} height={'100%'} style={{objectFit:"cover"}}/>

           </div>
           <div className='d-flex flex-column w-100 ml-2'>
           <div className='d-flex flex-row flex-wrap justify-content-between align-items-start'>
           <Link  to={`/job/${item.Id}`} className="text-decoration-none">
           <Typography className='h5 font-weight-bold'> {item.Title}</Typography>
           </Link>
           <Typography className='d-flex align-items-center text-app-primary' ><span>
           {cityList && cityList.length>0 && cityList.find(subitem=>subitem.TKey ===item.City) && cityList.find(subitem=>subitem.TKey ===item.City).TValue}
            </span> <i className='icon-Location ml-1'></i></Typography>
             
             </div>
 
        <Link to={`/company/${item.CompanyID}`} className="text-decoration-none">
             <Typography className='company'><i className='icon-Cursor-outline mr-1'></i>{item.Company.Name}</Typography></Link>
              <Typography className='d-flex align-items-center'><span style={{fontSize:'6px'}} className="mr-1 ">&#9899;</span> {moment(item.CreateAt).format('DD/MM/YYYY')} - {moment(item.DueDate).format('DD/MM/YYYY')} </Typography>
            
             <div className='d-flex flex-row justify-content-between align-items-center mt-2'>
             <div className='d-flex flex-row'>
               {item.Skills? JSON.parse(item.Skills).map((el, index)=>( <Tag key={`job-tag-${item.id}-${index}`} color="green" className='font-weight-bold'>
                
                {skillList && skillList.length>0 && skillList.find(item=>item.TKey ===el) && skillList.find(item=>item.TKey ===el).TValue}</Tag>)):''}
          
             </div>
             {getValidRole(this.context.user, [USER_ROLE.RECRUITER]) && 
         <Link to={`/candidate-recruiter?jobid=${item.Id}`}>   <Button className='d-flex align-items-center'><i className='icon-User-outline'></i> Ứng viên</Button></Link>
         }
             </div>
           </div>
         </div>
       </Card>
     </div>
     ))
   }
   getLoadingSkeleton = () => {
    return ['', '', '', ''].map((items,index) => (
      <div key={`loading-job-${index}`} className="col-xs-12 col-sm-12 col-md-12 col-lg-6 mt-2">
      <Card className='job-card'>
        <div className='d-flex flex-row '>
          {/* <img src={require('../../images/background/background-icon-1.png')} width={"30%"} height={'100px'} style={{objectFit:"cover"}}/> */}
          <Skeleton.Button active style={{width: '100px', height:'100px'}} />
          <div className='d-flex flex-column w-100 pl-2'>
          <div className='d-flex flex-row flex-wrap justify-content-between align-items-start'>
          <Skeleton.Input active className='w-75' />
          <Skeleton.Input active style={{width: '90px'}}  size='small' />
          <Skeleton active size="small"  className=" w-75 font-weight-bold" />
            
            </div>

          </div>
        </div>
      </Card>
    </div>))}


  render(){
    return (
      <div className="row mt-3">
      {this.props.loading
          ? this.getLoadingSkeleton()
          : this.getJobList(this.props.value)}
      </div>
  );
  }
  
}

JobListComponent.propTypes = {};
JobListComponent.contextType = AuthContext;

export default JobListComponent;
