/**
 *
 * CourseListComponent
 *
 */

import React from 'react';
// import PropTypes from 'prop-types';
// import styled from 'styled-components';

import { FormattedMessage } from 'react-intl';
import messages from './messages';
import './styles.scss';
import { Typography, Card, Skeleton, Empty } from 'antd';
import { Link } from 'react-router-dom';
import moment from 'moment';
import numeral from 'numeral';
import { KEY_VALUE } from '../../utils/api/constants';
import * as api from 'utils/api';
import AuthContext from '../../utils/auth';

class CourseListComponent extends React.Component {
  constructor(props){
    super(props);
    this.state= {
      feeTypeList: [],
    }
    api.postPagination( `v1/KeyValues`, null, null, `TGroup eq ${KEY_VALUE.FEETYPE}`, null ).then(res=>{
      this.setState ({feeTypeList: res.data.value})
    })
  
  }
  componentWillReceiveProps(nextProps){
    if (nextProps.value !== this.props.value) {}
  
  }
  getCourseList = items => {
    if (!items) return '';
    if (items.length==0 ) return<div style={{height:'35vh'}} className='w-100 d-flex align-items-center justify-content-center'><Empty description="Không có dữ liệu"/></div> 
    return items.map(item => (
      <Link
        key={`course-${item.Id}`}
        to={`/course/${item.Id}`}
        className="col-xs-12 col-sm-12 col-md-6 col-lg-3 mt-2"
      >
        <Card hoverable className="course-card">
          <div className="d-flex flex-column">
            <img
              src={item.Image ? (item.Image.startsWith('http')? item.Image: `${this.context.prefixLink}/${item.Image}`): require('../../images/logo/logo-shinyama-grayscale.png') }
              width={'100%'}
              height={'150px'}
              style={{ objectFit: 'cover' }}
            />
            <div className="p-2">
              <Typography className="h7 font-weight-bold mb-2">
                {item.Name}
              </Typography>
              <Typography
                style={{ fontSize: '12px' }}
                className="d-flex align-items-center text-app-primary"
              >
                <i
                  style={{ fontSize: '17px' }}
                  className="mr-1 icon-Sand-watch"
                />{' '}
                Ngày hết hạn:  {moment(item.DueDate).format('DD/MM/YYYY')}
              </Typography>
              <Typography
                style={{ fontSize: '12px' }}
                className="d-flex align-items-center text-app-primary"
              >
                <i
                  style={{ fontSize: '17px' }}
                  className="mr-1 icon-Location"
                />
                Địa điểm: {item.Location}
              </Typography>
              <Typography
                style={{ fontSize: '12px' }}
                className="d-flex align-items-center text-app-primary"
              >
                <i style={{ fontSize: '17px' }} className="mr-1 icon-Play" />{' '}
                Hình thức: {item.Type}
              </Typography>
              <Typography className="mt-3 text-app-primary font-weight-bold h5">
                {' '}
                {numeral(item.Fee).format('0,0 ')} {this.state.feeTypeList.find(el=>el.TKey==item.FeeType) &&this.state.feeTypeList.find(el=>el.TKey==item.FeeType).TValue}
              </Typography>
            </div>
          </div>
        </Card>
      </Link>
    ));
  };

  getLoadingSkeleton = () => {
    return ['', '', '', ''].map((items, index) => (
      <div  key={`loading-course-${index}`}  className="col-xs-12 col-sm-12 col-md-6 col-lg-3 mt-2">
        <Card className="course-card">
          <div className="d-flex flex-column">
           
             <Skeleton.Button active style={{width: '100%', height:'150px'}} />
            <div>
            
              <Skeleton.Input active  className="h7 w-100 font-weight-bold" />
              <Skeleton active size="small"  className=" w-75 font-weight-bold" />
            </div>
          </div>
        </Card>
      </div>
    ));
  };
  render() {
    return (
      <div className="row mt-3">
        {this.props.loading
          ? this.getLoadingSkeleton()
          : this.getCourseList(this.props.value)}
      </div>
    );
  }
}

CourseListComponent.propTypes = {};
CourseListComponent.contextType = AuthContext;


export default CourseListComponent;
