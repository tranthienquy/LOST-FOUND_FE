/**
 *
 * FileViewerComponent
 *
 */

import React from 'react';
// import PropTypes from 'prop-types';
// import styled from 'styled-components';

import { FormattedMessage } from 'react-intl';
import messages from './messages';
import axios from 'axios';
import { API_ENDPOINT } from '../../utils/api/constants';
import { TYPE_OF_PREVIEW } from './constants';

class FileViewerComponent extends React.Component {
  constructor(props){
    super(props);
    this.state= {
      base64: null,
      loading: false,
      type:null,
    }
  }
  componentWillMount(){
    if (this.props.value) 
    this.getValue(this.props.value )
  }
  componentWillReceiveProps= async (nextProps)=>{
    console.log(nextProps);
    if (nextProps.value !== this.props.value && nextProps.value) {
     this.getValue(nextProps.value )
    }
  }
  getValue = (value)=>{
    this.setState({loading: true, type:  
      TYPE_OF_PREVIEW.find(item => (value.Name && item.type ===value.Name.substr(value.Name.lastIndexOf('.')+1) )||  (value.Link && item.type ===value.Link.substr(value.Link.lastIndexOf('.')+1)))
      }); 
      console.log(value.Name.substr(value.Name.lastIndexOf('.')+1)) ;

    axios({
      url: `${API_ENDPOINT}/v1/Cvs/view/${value.Id} `,
      method: 'GET',
      responseType: 'arraybuffer'
    }).then((response) => {
     this.setState({base64:Buffer.from(response.data, 'binary').toString('base64'), loading: false});
    });
  }
  render() {
    console.log(this.props.value, this.state);
    const { type, loading, base64} = this.state
    if (!this.props.value) return;
    return (
      <div>
        {loading && "Đang tải"}
        {!loading && !type && "Không hỗ trợ xem ở định dạng này"}
        {!loading && type  && type.type==="pdf" &&
        <embed
       src={`${type.uri}${base64}`}
        style={{width:"100%", height:'100%', minHeight:'80vh'}}
        type="application/pdf"
      />
        }
         {!loading && type  && type.type==="png" &&
          <img width={'100%'}  src={`${type.uri}${base64}`}/>
         }
         {!loading && type  && type.type==="jpg" &&
          <img  width={'100%'}  src={`${type.uri}${base64}`}/>
         }
      </div>
    );
  }
}

FileViewerComponent.propTypes = {};

export default FileViewerComponent;
