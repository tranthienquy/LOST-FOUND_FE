/*
 * FileViewerComponent Messages
 *
 * This contains all the text for the FileViewerComponent component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.FileViewerComponent';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'This is the FileViewerComponent component!',
  },
});
