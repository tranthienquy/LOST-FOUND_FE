export const TYPE_OF_PREVIEW = [
    {
        type:'pdf',
        uri:'data:application/pdf;base64,'
    },
    {
        type:'jpg',
        uri:'data:image/jpeg;base64,'
    },
    {
        type:'png',
        uri:'data:image/png;base64,'
    }
]