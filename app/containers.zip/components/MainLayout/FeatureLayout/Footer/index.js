/**
 *
 * Footer
 *
 */

import React from 'react';
// import PropTypes from 'prop-types';
// import styled from 'styled-components';

import { FormattedMessage } from 'react-intl';
import messages from './messages';

class Footer extends React.Component {
  render(){
     return (
    <div className='master-footer mt-5'>
    </div>
  );
  }
 
}

Footer.propTypes = {};

export default Footer;
