import { USER_ROLE } from "../../../utils/constants";
import { ABC } from "./permission.const";

export const NAVIGATION_MENU = [
    {
        label: 'main',
        routerLink: '/',
        icon: '',
        items: [],
    },
    {
        label: 'job',
        routerLink: '/job',
        icon: '',
        items: [],
    },
    {
        label: 'training',
        routerLink: '/course',
        icon: '',
        items: [],
    },
    {
        label: 'candidate',
        routerLink: '/candidate',
        icon: '',
        items: [],
        permission: [USER_ROLE.PARTNER]
    },
    {
        label: 'candidate',
        routerLink: '/candidate-recruiter',
        icon: '',
        items: [],
        permission: [USER_ROLE.RECRUITER]
    },
    {
        label: 'candidate',
        routerLink: '/candidate-shinyama',
        icon: '',
        items: [],
        permission: [USER_ROLE.SHINYAMA]
    },
    {
        label: 'news',
        routerLink: '/news',
        icon: '',
        items: [],
    },
    {
        label: 'contact',
        routerLink: '/contact',
        icon: '',
        items: [],
    },
]