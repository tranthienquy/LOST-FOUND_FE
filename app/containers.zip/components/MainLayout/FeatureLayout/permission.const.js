export const TOKUTEI = 'Tokutei';
export const PARTNER = 'Partner';
export const RECRUITER = 'Recuiter';
export const SHINYAMA = 'Shinyama';
export const ITADMIN = 'It-admin';
