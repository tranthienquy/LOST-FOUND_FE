/**
 *
 * UserButton
 *
 */

import { Button, Dropdown, Menu } from 'antd';
import React from 'react';
import AuthContext from '../../utils/auth';

// import PropTypes from 'prop-types';
// import styled from 'styled-components';

import { FormattedMessage } from 'react-intl';
import messages from './messages';
import { Link } from 'react-router-dom';
import { USER_ROLE } from '../../utils/constants';

class UserButton extends React.Component {
  logOut = async() => {
     document.cookie = await null;
    location.replace('/');
  };
  handleMenuClick(e) {
  }
 ITEMS= [
   {
     to:'/profile',
     icon:'icon-Contacts-outline',
     label:'Cập nhật hồ sơ',
     role: [USER_ROLE.APPLICANT]
   },
   {
     to:'/profile-recruiter',
     icon:'icon-Contacts-outline',
     label:'Cập nhật hồ sơ cá nhân',
     role: [USER_ROLE.RECRUITER]
   },
   {
     to:'/profile-partner',
     icon:'icon-Contacts-outline',
     label:'Cập nhật hồ sơ cá nhân',
     role: [USER_ROLE.PARTNER]
   },
   {
     to:'/update-company',
     icon:'icon-Bag-outline',
     label:'Cập nhật hồ sơ công ty',
     role: [USER_ROLE.RECRUITER]
   },
  
   {
     to:'/update',
     icon:'icon-Palette-outline',
     label:'Công việc đã ứng tuyển',
     role: [USER_ROLE.APPLICANT]
   },
   {
    to:'/recruitment-request-partner',
    icon:'icon-Document-outline',
    label:'Yêu cầu tuyển dụng',
    role: [USER_ROLE.PARTNER]
   },
   {
    to:'/recruitment-request-recruiter',
    icon:'icon-Document-outline',
    label:'Yêu cầu tuyển dụng',
    role: [USER_ROLE.RECRUITER]
   },
   {
    to:'/recruitment-request-shinyama',
    icon:'icon-Document-outline',
    label:'Yêu cầu tuyển dụng',
    role: [ USER_ROLE.SHINYAMA,USER_ROLE.SHINYAMA_MANAGER]
   },  
   {
    to:'/category-management',
    icon:'icon-Book-outline',
    label:'Quản lý nhóm ngành',
    role: [ USER_ROLE.ADMIN]
   },
   {
    to:'/register-shinyama',
    icon:'icon-User-plus-outline',
    label:'Tạo tài khoản',
    role: [ USER_ROLE.ADMIN]
   },
 
   {
    to:'/user-management',
    icon:'icon-User-outline',
    label:'Quản lý người dùng',
    role: [ USER_ROLE.ADMIN]
   },
 ]
  menu = (
    <Menu onClick={this.handleMenuClick}>
      {this.ITEMS.map(item=>{
        if(
          item.role.filter((val) =>{ return this.context.user.Role.indexOf(val) != -1 }).length>0
        )
        {return (
      <Menu.Item>
        <Link
        key={`item-menu-${item.to}`}
          to={item.to}
          className="d-flex align-items-center"
        >
          <i
            className={`${item.icon} mr-2`}
            style={{ fontSize: '20px' }}
          />
         {item.label}
        </Link>
      </Menu.Item>)} else return  })
      } 



      <Menu.Item>
        <Link
          to={'/change-password'}
          className="d-flex align-items-center"
        >
          {' '}
          <i className="icon-Key-outline mr-2" style={{ fontSize: '20px' }} />
          Đổi mật khẩu
        </Link>
      </Menu.Item>
      <Menu.Item
        style={{ color: 'red' }}
        onClick={this.logOut}
      >
      <div 
        className="d-flex align-items-center"
>
        <i
          className="icon-Power-button-outline mr-2"
          style={{ fontSize: '20px' }}
        />
        Đăng xuất</div>
      </Menu.Item>
    </Menu>
  );
  render() {
    return (
      <Dropdown overlay={this.menu} placement="bottomRight">
        <Button type="primary">
          {this.context.user && (
           this.context.user.RepresentativeName || `${this.context.user.FirstName} ${this.context.user.LastName}`
          ) }
        </Button>
      </Dropdown>
    );
  }
}

UserButton.propTypes = {};
UserButton.contextType = AuthContext;

export default UserButton;
