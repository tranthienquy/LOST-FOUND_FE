/**
 *
 * CandidateListComponent
 *
 */

import React from 'react';
// import PropTypes from 'prop-types';
// import styled from 'styled-components';

import { FormattedMessage } from 'react-intl';
import messages from './messages';
import './styles.scss';
import { Typography, Card, Tag, Skeleton, Empty, Button } from 'antd';
import { Link } from 'react-router-dom';
import moment from 'moment';
import AuthContext from '../../utils/auth';
import * as api from 'utils/api';
import { KEY_VALUE } from '../../utils/api/constants';
import _ from 'lodash';

import { getValidRole } from '../../utils/permissionUtil';
import { USER_ROLE } from '../../utils/constants';
import { API_ENDPOINT } from '../../utils/api/constants';
class CandidateListComponent extends React.Component {

  constructor(props){
    super(props);
    this.state= {
      skillList: [],
      cityList: [],
    }
  }

  componentWillReceiveProps(nextProps){
    if (nextProps.value !== this.props.value) {
      console.log("aa");
      if(nextProps.value && nextProps.value.length>0){
        let skillArray = [];
        let cityArray = [];
        nextProps.value.forEach(element => {
          skillArray= skillArray.concat(JSON.parse(element.Skill))
          // cityArray.push(element.City)
        });
        let searchFilter = '';
        let searchCityFilter = '';
        _.uniq(skillArray).forEach(el => {
          searchFilter += `contains(tolower(TKey),tolower('${encodeURIComponent(
            el,
          )}')) or `;
        });
        _.uniq(cityArray).forEach(el => {
          searchCityFilter += `contains(tolower(TKey),tolower('${encodeURIComponent(
            el,
          )}')) or `;
        });
        searchFilter = searchFilter.slice(0, -3);
        searchCityFilter = searchCityFilter.slice(0, -3);
        api.postPagination( `v1/KeyValues`, null, null, `TGroup eq ${KEY_VALUE.SKILL} and `+ searchFilter, null ).then(res=>{
          this.setState ({skillList: res.data.value})
        })
        api.postPagination( `v1/KeyValues`, null, null, `TGroup eq ${KEY_VALUE.LOCATION} and `+ searchCityFilter, null ).then(res=>{
          this.setState ({cityList: res.data.value})
        })
      }
    }
  }

  getCandidateList =(items)=>{
    
    if (!items) return '';
    const {skillList  } = this.state;

    if (items.length==0 ) return<div style={{height:'35vh'}} className='w-100 d-flex align-items-center justify-content-center'><Empty description="Không có dữ liệu"/></div> 
    return  items.map(item=>(
       <div key={`candidate-${item.Id}`} className="col-xs-12 col-sm-12 col-md-12 col-lg-6 mt-2">
       <Card hoverable className='job-card'>
         <div className='d-flex flex-row '>
           <div style={{width:'150px', height: '100px'}}>
           <img src={item.AvtLink ? `${this.context.prefixLink}/${item.AvtLink}`: require('../../images/logo/logo-shinyama-grayscale.png') } width={"100%"} height={'100%'} style={{objectFit:"cover"}}/>
           </div>
           <div className='d-flex flex-column w-100 ml-2'>
           <div className='d-flex flex-row flex-wrap justify-content-between align-items-start'>
           <Link  to={`candidate/edit/${item.Id}`} className="text-decoration-none">
           <Typography className='h5 font-weight-bold'> {item.FirstName} {item.LastName}</Typography>
           </Link>
           {item.Cvs && item.Cvs.length>0 && ( 
           <Button onClick={()=>{window.open(
            `${API_ENDPOINT}/v1/Cvs/view/${item.Cvs[item.Cvs.length-1].Id}`,
          )}} className='d-flex align-items-center'><i className='icon-Document-outline'></i>Xem CV</Button>
            )}
           
             </div>
 
             <div className='d-flex flex-row flex-wrap'>
             <Typography className='company d-flex flex-row align-items-center mr-3 '><i className='icon-Envelope-outline mr-1'></i>{item.Account.Email}</Typography>
           </div>
             <div className='d-flex flex-row mt-2 flex-wrap'>
             {item.Skill? JSON.parse(item.Skill).map((el, index)=>( <Tag key={`job-tag-${item.id}-${index}`} color="green" className='mt-1 font-weight-bold'>
                
                {skillList && skillList.length>0 && skillList.find(item=>item.TKey ===el) && skillList.find(item=>item.TKey ===el).TValue}</Tag>)):''}
          
             </div>
           </div>
         </div>
       </Card>
     </div>
     ))
   }
   getLoadingSkeleton = () => {
    return ['', '', '', ''].map((items,index) => (
      <div key={`loading-job-${index}`} className="col-xs-12 col-sm-12 col-md-12 col-lg-6 mt-2">
      <Card className='job-card'>
        <div className='d-flex flex-row '>
          {/* <img src={require('../../images/background/background-icon-1.png')} width={"30%"} height={'100px'} style={{objectFit:"cover"}}/> */}
          <Skeleton.Button active style={{width: '100px', height:'100px'}} />
          <div className='d-flex flex-column w-100 pl-2'>
          <div className='d-flex flex-row flex-wrap justify-content-between align-items-start'>
          <Skeleton.Input active className='w-75' />
          <Skeleton.Input active style={{width: '90px'}}  size='small' />
          <Skeleton active size="small"  className=" w-75 font-weight-bold" />
            
            </div>

          </div>
        </div>
      </Card>
    </div>))}


  render(){
    return (
      <div className="row mt-3">
      {this.props.loading
          ? this.getLoadingSkeleton()
          : this.getCandidateList(this.props.value)}
      </div>
  );
  }
  
}

CandidateListComponent.propTypes = {};
CandidateListComponent.contextType = AuthContext;


export default CandidateListComponent;
