/**
 *
 * LangButton
 *
 */

import { Button, Dropdown, Menu } from 'antd';
import React from 'react';
import { languages } from './language.const';
import './styles.scss'

// import PropTypes from 'prop-types';
// import styled from 'styled-components';

class LangButton extends React.Component {
  getDefaultLocale = ()=>{
    let lang = localStorage.getItem('language') ? localStorage.getItem('language'):'vi';
    return languages.find(item=>item.locale === lang);
  }
  handleMenuClick(e) {
    localStorage.setItem('language',e.key);
    location.reload();

  }
  menu = (
    <Menu
      onClick={this.handleMenuClick}
    >
      {languages.map(item=>  <Menu.Item key={item.locale} defaultValue={item.locale}><img src={(item.img)} className="mr-2"/>{item.label}</Menu.Item>)}
    
    </Menu>
  );
  render() {
    return (
<div className='lang-button'>
      <Dropdown overlay={
        this.menu
          }>
          <Button className=' mr-1'>
            <img src={(this.getDefaultLocale().img)} className="mr-2"/>
            <b>{this.getDefaultLocale().locale.toUpperCase()}</b></Button>
          </Dropdown></div>
    );
  }
}

LangButton.propTypes = {};

export default LangButton;
