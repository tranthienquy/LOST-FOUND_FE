export const languages =[
    {
        locale: 'vi',
        label:'Việt Nam',
        img: require('../../images/icon/vietnam-flag.png')
    },
    {
        locale: 'en',
        label:'English',
        img:require('../../images/icon/united-kingdom-flag.png')
    },
    {
        locale: 'jp',
        label:'Japan',
        img:require('../../images/icon/japan-flag.png')
    },
]