// export const API_ENDPOINT = 'http://34.142.132.38:5000';
export const API_ENDPOINT = 'https://localhost:7042';

export const QUERY_TYPE = {
  contain: 'contain',
  equal: 'equal',
};
export const KEY_VALUE = {
  SKILL: 0,
  PROFESSION: 1,
  LOCATION: 2,
  FEETYPE:3,
  NATIONALITY: 4,
  CERTIFICATE: 5,
  DURATION_TYPE: 6,
  ACTION_TYPE: 7,
  RESULT_TYPE: 8,
};
