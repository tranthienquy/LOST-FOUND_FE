export const getValidRole = (user, role)=>{
    if (user && user.Role && 
      role.filter((val) =>{ return user.Role.indexOf(val) != -1 }).length>0
      ) return true;
      return false;
  }